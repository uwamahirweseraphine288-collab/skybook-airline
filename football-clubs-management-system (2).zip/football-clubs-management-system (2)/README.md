# Online Football Clubs Management System (FCMS)

Full-stack MERN app with complete CRUD for Players, Coaches, Matches, Attendance, and Finance plus JWT authentication.

## Tech Stack
- **Frontend:** React 18 + Vite + React Router + Axios + Tailwind (CDN)
- **Backend:** Node.js + Express + Mongoose
- **Database:** MongoDB
- **Auth:** JWT + bcryptjs

## Prerequisites
- Node.js 18+
- MongoDB running locally (or a connection string)

## Setup

### 1. Backend
```bash
cd backend
cp .env.example .env       # edit MONGO_URI / JWT_SECRET
npm install
npm run dev                # starts on http://localhost:5000
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev                # starts on http://localhost:5173
```

Vite proxies `/api/*` to `http://localhost:5000`.

## First Use
1. Open http://localhost:5173
2. Click **Register** and create an admin account
3. Use the navbar to manage Players, Coaches, Matches, Attendance, Finance

## API Endpoints
All `/api/*` endpoints (except auth) require `Authorization: Bearer <token>`.

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST   | /api/auth/register | Create account |
| POST   | /api/auth/login    | Login, returns JWT |
| GET/POST/PUT/DELETE | /api/players[/:id] | CRUD players |
| GET/POST/PUT/DELETE | /api/coaches[/:id] | CRUD coaches |
| GET/POST/PUT/DELETE | /api/matches[/:id] | CRUD matches |
| GET/POST/PUT/DELETE | /api/attendance[/:id] | CRUD attendance |
| GET/POST/PUT/DELETE | /api/finance[/:id] | CRUD finance |

## Folder Structure
```
backend/
  config/db.js
  controllers/{authController.js, crud.js}
  middleware/auth.js
  models/{User, Player, Coach, Match, Attendance, Finance}.js
  routes/{authRoutes, playerRoutes, coachRoutes, matchRoutes, attendanceRoutes, financeRoutes}.js
  server.js
frontend/
  src/
    components/{Navbar, ProtectedRoute, CrudPage}.jsx
    pages/{Login, Register, Dashboard, Players, Coaches, Matches, Attendance, Finance}.jsx
    services/{api.js, auth.js}
    App.jsx
    main.jsx
  index.html
  vite.config.js
```
