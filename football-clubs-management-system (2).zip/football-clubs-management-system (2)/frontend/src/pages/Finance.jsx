import CrudPage from '../components/CrudPage';
export default function Finance() {
  return <CrudPage title="Finance" endpoint="/finance" fields={[
    { name: 'type', label: 'Type', options: ['income', 'expense'], required: true },
    { name: 'category', label: 'Category' },
    { name: 'amount', label: 'Amount', type: 'number', required: true },
    { name: 'description', label: 'Description' },
    { name: 'date', label: 'Date', type: 'date' },
  ]} />;
}
