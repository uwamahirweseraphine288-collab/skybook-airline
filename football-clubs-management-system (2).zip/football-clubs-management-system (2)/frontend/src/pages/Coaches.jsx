import CrudPage from '../components/CrudPage';
export default function Coaches() {
  return <CrudPage title="Coaches" endpoint="/coaches" fields={[
    { name: 'name', label: 'Name', required: true },
    { name: 'specialty', label: 'Specialty' },
    { name: 'experienceYears', label: 'Experience (yrs)', type: 'number' },
    { name: 'nationality', label: 'Nationality' },
  ]} />;
}
