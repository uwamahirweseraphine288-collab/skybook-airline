import { useEffect, useState } from 'react';
import api from '../services/api';

const cards = [
  { key: 'players', label: 'Players', endpoint: '/players', color: 'bg-green-600' },
  { key: 'coaches', label: 'Coaches', endpoint: '/coaches', color: 'bg-blue-600' },
  { key: 'matches', label: 'Matches', endpoint: '/matches', color: 'bg-purple-600' },
  { key: 'attendance', label: 'Attendance', endpoint: '/attendance', color: 'bg-orange-600' },
  { key: 'finance', label: 'Finance Records', endpoint: '/finance', color: 'bg-red-600' },
];

export default function Dashboard() {
  const [counts, setCounts] = useState({});
  useEffect(() => {
    Promise.all(cards.map((c) => api.get(c.endpoint).then((r) => [c.key, r.data.length]).catch(() => [c.key, 0])))
      .then((entries) => setCounts(Object.fromEntries(entries)));
  }, []);
  return (
    <div className="max-w-6xl mx-auto p-4">
      <h1 className="text-2xl font-bold text-green-800 mb-4">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {cards.map((c) => (
          <div key={c.key} className={`${c.color} text-white p-6 rounded shadow`}>
            <div className="text-sm opacity-90">{c.label}</div>
            <div className="text-4xl font-bold mt-2">{counts[c.key] ?? '—'}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
