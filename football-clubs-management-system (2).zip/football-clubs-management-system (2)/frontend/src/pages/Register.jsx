import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { register } from '../services/auth';

export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'admin' });
  const [err, setErr] = useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try { await register(form); nav('/'); }
    catch (e) { setErr(e.response?.data?.message || e.message); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={submit} className="bg-white p-6 rounded shadow w-full max-w-sm space-y-3">
        <h1 className="text-2xl font-bold text-green-800">Create Account</h1>
        <input className="border w-full p-2 rounded" placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        <input className="border w-full p-2 rounded" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input className="border w-full p-2 rounded" type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
        <select className="border w-full p-2 rounded" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
          <option value="admin">Admin</option>
          <option value="coach">Coach</option>
          <option value="player">Player</option>
          <option value="accountant">Accountant</option>
        </select>
        {err && <div className="text-red-600 text-sm">{err}</div>}
        <button className="bg-green-700 text-white w-full py-2 rounded">Register</button>
        <div className="text-sm text-center">Have an account? <Link to="/login" className="text-green-700">Login</Link></div>
      </form>
    </div>
  );
}
