import CrudPage from '../components/CrudPage';
export default function Attendance() {
  return <CrudPage title="Attendance" endpoint="/attendance" fields={[
    { name: 'playerName', label: 'Player', required: true },
    { name: 'date', label: 'Date', type: 'date', required: true },
    { name: 'sessionType', label: 'Session', options: ['training', 'match'] },
    { name: 'status', label: 'Status', options: ['present', 'absent', 'late'] },
    { name: 'notes', label: 'Notes' },
  ]} />;
}
