import CrudPage from '../components/CrudPage';
export default function Matches() {
  return <CrudPage title="Matches" endpoint="/matches" fields={[
    { name: 'opponent', label: 'Opponent', required: true },
    { name: 'date', label: 'Date', type: 'date', required: true },
    { name: 'venue', label: 'Venue' },
    { name: 'homeScore', label: 'Home Score', type: 'number' },
    { name: 'awayScore', label: 'Away Score', type: 'number' },
    { name: 'status', label: 'Status', options: ['scheduled', 'completed', 'cancelled'] },
  ]} />;
}
