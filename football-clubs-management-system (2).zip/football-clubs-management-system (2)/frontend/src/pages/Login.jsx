import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { login } from '../services/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try { await login(email, password); nav('/'); }
    catch (e) { setErr(e.response?.data?.message || e.message); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={submit} className="bg-white p-6 rounded shadow w-full max-w-sm space-y-3">
        <h1 className="text-2xl font-bold text-green-800">FCMS Login</h1>
        <input className="border w-full p-2 rounded" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input className="border w-full p-2 rounded" type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        {err && <div className="text-red-600 text-sm">{err}</div>}
        <button className="bg-green-700 text-white w-full py-2 rounded">Login</button>
        <div className="text-sm text-center">No account? <Link to="/register" className="text-green-700">Register</Link></div>
      </form>
    </div>
  );
}
