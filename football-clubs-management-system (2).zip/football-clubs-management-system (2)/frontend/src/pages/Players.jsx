import CrudPage from '../components/CrudPage';
export default function Players() {
  return <CrudPage title="Players" endpoint="/players" fields={[
    { name: 'name', label: 'Name', required: true },
    { name: 'position', label: 'Position', options: ['Goalkeeper', 'Defender', 'Midfielder', 'Forward'] },
    { name: 'jerseyNumber', label: 'Jersey #', type: 'number' },
    { name: 'age', label: 'Age', type: 'number' },
    { name: 'nationality', label: 'Nationality' },
    { name: 'contractEnd', label: 'Contract End', type: 'date' },
  ]} />;
}
