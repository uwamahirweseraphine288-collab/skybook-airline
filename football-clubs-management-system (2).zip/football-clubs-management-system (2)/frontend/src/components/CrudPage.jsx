import { useEffect, useState } from 'react';
import api from '../services/api';

/**
 * Generic CRUD page.
 * Props:
 *  - title: page title
 *  - endpoint: API path (e.g. "/players")
 *  - fields: [{ name, label, type?, options?, required? }]
 */
export default function CrudPage({ title, endpoint, fields }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({});
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(endpoint);
      setItems(data);
    } catch (e) {
      setError(e.response?.data?.message || e.message);
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [endpoint]);

  const reset = () => { setForm({}); setEditingId(null); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (editingId) await api.put(`${endpoint}/${editingId}`, form);
      else await api.post(endpoint, form);
      reset();
      load();
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    }
  };

  const handleEdit = (item) => {
    const f = {};
    fields.forEach((x) => {
      let v = item[x.name];
      if (x.type === 'date' && v) v = new Date(v).toISOString().slice(0, 10);
      f[x.name] = v ?? '';
    });
    setForm(f);
    setEditingId(item._id);
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this record?')) return;
    await api.delete(`${endpoint}/${id}`);
    load();
  };

  return (
    <div className="max-w-6xl mx-auto p-4">
      <h1 className="text-2xl font-bold text-green-800 mb-4">{title}</h1>

      <form onSubmit={handleSubmit} className="bg-white p-4 rounded shadow mb-6 grid grid-cols-1 md:grid-cols-3 gap-3">
        {fields.map((f) => (
          <div key={f.name} className="flex flex-col">
            <label className="text-sm font-medium text-gray-700">{f.label}</label>
            {f.options ? (
              <select
                required={f.required}
                value={form[f.name] ?? ''}
                onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                className="border rounded px-2 py-1"
              >
                <option value="">Select...</option>
                {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            ) : (
              <input
                type={f.type || 'text'}
                required={f.required}
                value={form[f.name] ?? ''}
                onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                className="border rounded px-2 py-1"
              />
            )}
          </div>
        ))}
        <div className="md:col-span-3 flex gap-2">
          <button type="submit" className="bg-green-700 text-white px-4 py-2 rounded">
            {editingId ? 'Update' : 'Create'}
          </button>
          {editingId && (
            <button type="button" onClick={reset} className="bg-gray-300 px-4 py-2 rounded">Cancel</button>
          )}
        </div>
        {error && <div className="md:col-span-3 text-red-600 text-sm">{error}</div>}
      </form>

      <div className="bg-white rounded shadow overflow-x-auto">
        {loading ? (
          <div className="p-4">Loading...</div>
        ) : items.length === 0 ? (
          <div className="p-4 text-gray-500">No records yet.</div>
        ) : (
          <table className="min-w-full text-sm">
            <thead className="bg-gray-100">
              <tr>
                {fields.map((f) => <th key={f.name} className="text-left p-2">{f.label}</th>)}
                <th className="p-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it) => (
                <tr key={it._id} className="border-t">
                  {fields.map((f) => (
                    <td key={f.name} className="p-2">
                      {f.type === 'date' && it[f.name]
                        ? new Date(it[f.name]).toLocaleDateString()
                        : String(it[f.name] ?? '')}
                    </td>
                  ))}
                  <td className="p-2 flex gap-2">
                    <button onClick={() => handleEdit(it)} className="text-blue-600">Edit</button>
                    <button onClick={() => handleDelete(it._id)} className="text-red-600">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
