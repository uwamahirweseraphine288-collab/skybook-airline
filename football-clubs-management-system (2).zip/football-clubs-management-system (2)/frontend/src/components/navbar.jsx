import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="w-full bg-green-800 text-white px-6 py-4 flex items-center justify-between">
      {/* Logo */}
      <h1 className="text-2xl font-bold">FCMS</h1>

      {/* Links */}
      <div className="flex gap-6">
        <Link to="/" className="hover:text-gray-200">
          Dashboard
        </Link>

        <Link to="/players" className="hover:text-gray-200">
          Players
        </Link>

        <Link to="/coaches" className="hover:text-gray-200">
          Coaches
        </Link>

        <Link to="/matches" className="hover:text-gray-200">
          Matches
        </Link>

        <Link to="/attendance" className="hover:text-gray-200">
          Attendance
        </Link>

        <Link to="/finance" className="hover:text-gray-200">
          Finance
        </Link>
      </div>
    </nav>
  );
}