import api from './api';

export const login = async (email, password) => {
  const { data } = await api.post('/auth/login', { email, password });
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
  return data;
};

export const register = async (payload) => {
  const { data } = await api.post('/auth/register', payload);
  localStorage.setItem('token', data.token);
  localStorage.setItem('user', JSON.stringify(data.user));
  return data;
};

export const logout = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

export const currentUser = () => {
  try { return JSON.parse(localStorage.getItem('user')); } catch { return null; }
};

export const isAuthed = () => !!localStorage.getItem('token');
