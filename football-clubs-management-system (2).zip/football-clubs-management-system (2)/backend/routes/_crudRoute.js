const router = require('express').Router;
const { protect } = require('../middleware/auth');
const crud = require('../controllers/crud');

module.exports = (Model) => {
  const r = router();
  const c = crud(Model);
  r.use(protect);
  r.get('/', c.list);
  r.post('/', c.create);
  r.get('/:id', c.get);
  r.put('/:id', c.update);
  r.delete('/:id', c.remove);
  return r;
};
