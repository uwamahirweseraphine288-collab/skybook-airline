module.exports = require('./_crudRoute')(require('../models/Coach'));
