const mongoose = require('mongoose');
module.exports = mongoose.model('Match', new mongoose.Schema({
  opponent: { type: String, required: true },
  date: { type: Date, required: true },
  venue: String,
  homeScore: { type: Number, default: 0 },
  awayScore: { type: Number, default: 0 },
  status: { type: String, enum: ['scheduled', 'completed', 'cancelled'], default: 'scheduled' },
}, { timestamps: true }));
