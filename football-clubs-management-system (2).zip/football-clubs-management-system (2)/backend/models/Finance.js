const mongoose = require('mongoose');
module.exports = mongoose.model('Finance', new mongoose.Schema({
  type: { type: String, enum: ['income', 'expense'], required: true },
  category: String,
  amount: { type: Number, required: true },
  description: String,
  date: { type: Date, default: Date.now },
}, { timestamps: true }));
