const mongoose = require('mongoose');
module.exports = mongoose.model('Coach', new mongoose.Schema({
  name: { type: String, required: true },
  specialty: String,
  experienceYears: Number,
  nationality: String,
}, { timestamps: true }));
