const mongoose = require('mongoose');
module.exports = mongoose.model('Player', new mongoose.Schema({
  name: { type: String, required: true },
  position: String,
  jerseyNumber: Number,
  age: Number,
  nationality: String,
  contractEnd: Date,
}, { timestamps: true }));
