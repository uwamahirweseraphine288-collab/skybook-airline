const mongoose = require('mongoose');
module.exports = mongoose.model('Attendance', new mongoose.Schema({
  playerName: { type: String, required: true },
  date: { type: Date, required: true },
  sessionType: { type: String, enum: ['training', 'match'], default: 'training' },
  status: { type: String, enum: ['present', 'absent', 'late'], default: 'present' },
  notes: String,
}, { timestamps: true }));
