// Generic CRUD controller factory
module.exports = (Model) => ({
  list: async (_req, res, next) => {
    try { res.json(await Model.find().sort('-createdAt')); }
    catch (e) { next(e); }
  },
  get: async (req, res, next) => {
    try {
      const doc = await Model.findById(req.params.id);
      if (!doc) return res.status(404).json({ message: 'Not found' });
      res.json(doc);
    } catch (e) { next(e); }
  },
  create: async (req, res, next) => {
    try { res.status(201).json(await Model.create(req.body)); }
    catch (e) { next(e); }
  },
  update: async (req, res, next) => {
    try {
      const doc = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
      if (!doc) return res.status(404).json({ message: 'Not found' });
      res.json(doc);
    } catch (e) { next(e); }
  },
  remove: async (req, res, next) => {
    try {
      const doc = await Model.findByIdAndDelete(req.params.id);
      if (!doc) return res.status(404).json({ message: 'Not found' });
      res.json({ message: 'Deleted' });
    } catch (e) { next(e); }
  },
});
