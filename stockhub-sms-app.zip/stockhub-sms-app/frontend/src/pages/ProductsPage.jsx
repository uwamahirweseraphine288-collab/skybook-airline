import { useEffect, useState } from "react";
import api from "../api/client.js";
import { Package, Plus, Search, Edit, Trash2, RefreshCw, AlertCircle, CheckCircle } from "lucide-react";

const fields = [
  { key: "productCode", col: "product_code", label: "Product Code", icon: "" },
  { key: "productName", col: "product_name", label: "Product Name", icon: "" },
  { key: "category", col: "category", label: "Category", icon: "" },
  { key: "quantityInStock", col: "quantity_in_stock", label: "Quantity", type: "number", icon: "" },
  { key: "unitPrice", col: "unit_price", label: "Unit Price", type: "number", icon: "" },
  { key: "supplierName", col: "supplier_name", label: "Supplier", icon: "" },
  { key: "dateReceived", col: "date_received", label: "Date Received", type: "date", icon: "" },
];

const emptyForm = fields.reduce((acc, f) => ({ ...acc, [f.key]: "" }), {});

const validateProduct = (form) => {
  const errors = {};
  if (!form.productCode.trim()) errors.productCode = "Product code is required.";
  else if (form.productCode.trim().length < 2) errors.productCode = "Code must be at least 2 characters.";
  if (!form.productName.trim()) errors.productName = "Product name is required.";
  if (!form.category.trim()) errors.category = "Category is required.";
  if (form.quantityInStock === "" || form.quantityInStock === undefined) {
    errors.quantityInStock = "Quantity in stock is required.";
  } else if (Number(form.quantityInStock) < 0 || Number.isNaN(Number(form.quantityInStock))) {
    errors.quantityInStock = "Enter a valid quantity (0 or greater).";
  }
  if (form.unitPrice === "" || form.unitPrice === undefined) {
    errors.unitPrice = "Unit price is required.";
  } else if (Number(form.unitPrice) <= 0 || Number.isNaN(Number(form.unitPrice))) {
    errors.unitPrice = "Unit price must be greater than 0.";
  }
  if (!form.supplierName.trim()) errors.supplierName = "Supplier name is required.";
  if (!form.dateReceived) errors.dateReceived = "Date received is required.";
  return errors;
};

export default function ProductsPage() {
  const [form, setForm] = useState(emptyForm);
  const [rows, setRows] = useState([]);
  const [filteredRows, setFilteredRows] = useState([]);
  const [fieldErrors, setFieldErrors] = useState({});
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(true);

  const load = async () => {
    try {
      const { data } = await api.get("/products");
      setRows(data);
      setFilteredRows(data);
    } catch {
      setError("Failed to load records.");
      setTimeout(() => setError(""), 3000);
    }
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredRows(rows);
    } else {
      const filtered = rows.filter(row => 
        row.product_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.product_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.category?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.supplier_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredRows(filtered);
    }
  }, [searchTerm, rows]);

  const setField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setFieldErrors((prev) => ({ ...prev, [key]: "" }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    const errors = validateProduct(form);
    if (Object.keys(errors).length) {
      setFieldErrors(errors);
      return;
    }
    setLoading(true);
    try {
      await api.post("/products", form);
      setMessage("Product added successfully! ");
      setForm(emptyForm);
      setFieldErrors({});
      load();
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to save.");
      setTimeout(() => setError(""), 3000);
    } finally {
      setLoading(false);
    }
  };

  const getStockStatus = (quantity) => {
    if (quantity === 0) return { color: "red", text: "Out of Stock", icon: "" };
    if (quantity < 10) return { color: "orange", text: "Low Stock", icon: "" };
    if (quantity < 50) return { color: "yellow", text: "Moderate", icon: "" };
    return { color: "green", text: "In Stock", icon: "" };
  };

  const inputClass = (key) =>
    `mt-1 w-full rounded-lg border px-3 py-2 transition-all duration-200 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none ${
      fieldErrors[key] 
        ? "border-red-500 dark:border-red-500 bg-red-50 dark:bg-red-900/20" 
        : "border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
    }`;

  const stats = {
    total: rows.length,
    lowStock: rows.filter(r => r.quantity_in_stock < 10 && r.quantity_in_stock > 0).length,
    outOfStock: rows.filter(r => r.quantity_in_stock === 0).length,
    totalValue: rows.reduce((sum, r) => sum + (r.quantity_in_stock * r.unit_price), 0)
  };

  return (
    <div className="space-y-6 p-6 bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* Header Section */}
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-400 bg-clip-text text-transparent">
            Inventory Management
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">Manage your product catalog</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          {showForm ? "Hide Form" : "Add Product"}
        </button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-lg transform hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-blue-100 text-sm">Total Products</p>
              <p className="text-3xl font-bold mt-2">{stats.total}</p>
            </div>
            <Package className="w-8 h-8 text-blue-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-6 text-white shadow-lg transform hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-orange-100 text-sm">Low Stock</p>
              <p className="text-3xl font-bold mt-2">{stats.lowStock}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-orange-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl p-6 text-white shadow-lg transform hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-red-100 text-sm">Out of Stock</p>
              <p className="text-3xl font-bold mt-2">{stats.outOfStock}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-red-200" />
          </div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-6 text-white shadow-lg transform hover:scale-105 transition-all duration-300">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-green-100 text-sm">Inventory Value</p>
              <p className="text-3xl font-bold mt-2">${stats.totalValue.toLocaleString()}</p>
            </div>
            <Package className="w-8 h-8 text-green-200" />
          </div>
        </div>
      </div>

      {/* Add Product Form */}
      {showForm && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4">
            <h3 className="text-white font-semibold text-lg flex items-center gap-2">
              <Plus className="w-5 h-5" />
              Add New Product
            </h3>
          </div>
          <form onSubmit={submit} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {fields.map((f) => (
                <div key={f.key} className="space-y-1">
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    <span className="mr-2">{f.icon}</span>
                    {f.label}
                    <span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type={f.type || "text"}
                    className={inputClass(f.key)}
                    value={form[f.key]}
                    onChange={(e) =>
                      setField(f.key, f.key === "productCode" ? e.target.value.toUpperCase() : e.target.value)
                    }
                    placeholder={`Enter ${f.label.toLowerCase()}`}
                  />
                  {fieldErrors[f.key] && (
                    <p className="text-red-600 dark:text-red-400 text-xs mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      {fieldErrors[f.key]}
                    </p>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 flex items-center gap-4">
              <button 
                type="submit" 
                disabled={loading} 
                className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Add Product
                  </>
                )}
              </button>
              {message && (
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-900/20 px-3 py-2 rounded-lg">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm">{message}</span>
                </div>
              )}
              {error && (
                <div className="flex items-center gap-2 text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20 px-3 py-2 rounded-lg">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm">{error}</span>
                </div>
              )}
            </div>
          </form>
        </div>
      )}

      {/* Products Table */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex flex-wrap gap-4 justify-between items-center">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Product Catalog</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                Showing {filteredRows.length} of {rows.length} products
              </p>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              />
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 dark:bg-gray-700/50">
              <tr>
                {fields.map((f) => (
                  <th key={f.key} className="px-4 py-3 text-left text-gray-700 dark:text-gray-300 font-semibold">
                    {f.label}
                  </th>
                ))}
                <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={fields.length + 1} className="text-center py-12 text-gray-500 dark:text-gray-400">
                    <Package className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No products found</p>
                  </td>
                </tr>
              ) : (
                filteredRows.map((row, i) => {
                  const stockStatus = getStockStatus(row.quantity_in_stock);
                  return (
                    <tr key={i} className="border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                      {fields.map((f) => (
                        <td key={f.key} className="px-4 py-3 text-gray-900 dark:text-gray-300">
                          {f.key === "unitPrice" 
                            ? `$${Number(row[f.col]).toFixed(2)}`
                            : f.key === "quantityInStock"
                            ? row[f.col]
                            : String(row[f.col] ?? "-").slice(0, 40)
                          }
                        </td>
                      ))}
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                          stockStatus.color === "red" ? "bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300" :
                          stockStatus.color === "orange" ? "bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300" :
                          stockStatus.color === "yellow" ? "bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300" :
                          "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300"
                        }`}>
                          <span>{stockStatus.icon}</span>
                          {stockStatus.text}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}