# CWSMS Frontend

React + Vite + Tailwind CSS frontend for SmartPark Car Washing Sales Management System.

## Setup & Run

```bash
npm install
npm run dev
```

Opens at http://localhost:5173

Make sure the backend is running on port 8080 first.

## Pages
- /          Dashboard with summary stats
- /cars      Register cars
- /packages  Manage service packages
- /service-packages  Service records (full CRUD)
- /payments  Record payments and print bills
- /reports   Daily reports with print support
