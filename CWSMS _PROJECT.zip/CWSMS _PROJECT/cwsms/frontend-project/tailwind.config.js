/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: { DEFAULT: '#0ea5e9', dark: '#0284c7', light: '#e0f2fe' },
        sidebar: '#0f172a',
      }
    },
  },
  plugins: [],
}
