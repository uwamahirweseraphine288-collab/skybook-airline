// components/Layout.jsx - With Car Background
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../App'

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const navItems = [
    { path: '/dashboard', name: 'Dashboard', icon: '📊', color: 'from-blue-500 to-blue-600', bgColor: 'bg-blue-50', textColor: 'text-blue-600' },
    { path: '/employees', name: 'Employees', icon: '👥', color: 'from-green-500 to-green-600', bgColor: 'bg-green-50', textColor: 'text-green-600' },
    { path: '/cars', name: 'Cars', icon: '🚗', color: 'from-purple-500 to-purple-600', bgColor: 'bg-purple-50', textColor: 'text-purple-600' },
    { path: '/packages', name: 'Packages', icon: '📦', color: 'from-orange-500 to-orange-600', bgColor: 'bg-orange-50', textColor: 'text-orange-600' },
    { path: '/service-packages', name: 'Service Records', icon: '🔧', color: 'from-indigo-500 to-indigo-600', bgColor: 'bg-indigo-50', textColor: 'text-indigo-600' },
    { path: '/payments', name: 'Payments', icon: '💰', color: 'from-emerald-500 to-emerald-600', bgColor: 'bg-emerald-50', textColor: 'text-emerald-600' },
    { path: '/reports', name: 'Reports', icon: '📈', color: 'from-rose-500 to-rose-600', bgColor: 'bg-rose-50', textColor: 'text-rose-600' },
  ]

  return (
    <div className="flex h-screen relative">
      {/* Car Background Image */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black/70 to-black/50 z-10"></div>
        <img 
          src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?w=1600&h=900&fit=crop" 
          alt="Car Background"
          className="w-full h-full object-cover"
        />
        {/* Overlay text */}
        <div className="absolute bottom-10 right-10 z-20 text-white/50 text-sm">
          <p>Premium Car Wash Service</p>
        </div>
      </div>
      
      {/* Sidebar - with transparency */}
      <div className="w-72 bg-white/95 backdrop-blur-md shadow-2xl flex flex-col relative z-10">
        {/* Logo Section with Gradient */}
        <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-blue-600 to-indigo-600">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <span className="text-2xl">🚗</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">CWSMS</h1>
              <p className="text-xs text-blue-100 mt-0.5">Car Wash System</p>
            </div>
          </div>
        </div>
        
        {/* User Profile Card */}
        <div className="mx-4 mt-4 p-4 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
              <span className="text-white text-xl">👤</span>
            </div>
            <div className="flex-1">
              <p className="font-semibold text-white text-sm">{user?.username || 'Admin'}</p>
              <p className="text-xs text-blue-100">Administrator</p>
            </div>
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <nav className="flex-1 mt-6 px-4">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-4 px-2">MAIN MENU</p>
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 mb-2 rounded-xl transition-all duration-200 group ${
                location.pathname === item.path 
                  ? `bg-gradient-to-r ${item.color} text-white shadow-lg` 
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                location.pathname === item.path 
                  ? 'bg-white/20' 
                  : item.bgColor
              }`}>
                <span className={`text-lg ${location.pathname === item.path ? 'text-white' : item.textColor}`}>
                  {item.icon}
                </span>
              </div>
              <span className="font-medium text-sm flex-1">{item.name}</span>
              {location.pathname === item.path && (
                <span className="text-white/70 text-sm">→</span>
              )}
            </Link>
          ))}
        </nav>
        
        {/* Footer Section */}
        <div className="p-4 border-t border-gray-100 mt-auto">
          <div className="mb-3 p-3 bg-gradient-to-r from-amber-50 to-orange-50 rounded-xl border border-amber-100">
            <div className="flex items-center gap-2">
              <span className="text-lg">🎉</span>
              <div className="flex-1">
                <p className="text-xs font-semibold text-gray-700">Premium Plan</p>
                <p className="text-xs text-gray-500">Active subscription</p>
              </div>
              <button className="text-amber-600 text-sm font-medium">Upgrade</button>
            </div>
          </div>
          
          <button
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-4 py-3 bg-gradient-to-r from-red-500 to-rose-500 text-white rounded-xl hover:from-red-600 hover:to-rose-600 transition-all duration-200 shadow-md group"
          >
            <span className="text-lg">🚪</span>
            <span className="font-medium flex-1 text-left">Logout</span>
            <span className="text-sm opacity-0 group-hover:opacity-100 transition-opacity">→</span>
          </button>
          
          <p className="text-xs text-center text-gray-400 mt-4">Version 2.0.0</p>
        </div>
      </div>
      
      {/* Main Content Area with semi-transparent background */}
      <div className="flex-1 overflow-auto relative z-10">
        <div className="bg-white/30 backdrop-blur-sm min-h-full">
          {/* Top Navigation Bar */}
          <div className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10 px-6 py-4 flex justify-between items-center border-b border-white/20">
            <div>
              <h2 className="text-xl font-semibold text-gray-800">
                {navItems.find(item => item.path === location.pathname)?.name || 'Dashboard'}
              </h2>
              <p className="text-sm text-gray-500">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="pl-10 pr-4 py-2 bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
                />
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">🔍</span>
              </div>
              
              <button className="relative p-2 text-gray-500 hover:text-gray-700 hover:bg-white/50 rounded-xl transition-colors">
                <span className="text-xl">🔔</span>
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white"></span>
              </button>
              
              <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-white/50 rounded-xl transition-colors">
                <span className="text-xl">⚙️</span>
              </button>
            </div>
          </div>
          
          {/* Page Content */}
          <div className="relative">
            <Outlet />
          </div>
          
          {/* Footer */}
          <div className="text-center py-4 border-t border-gray-200 bg-white/50 backdrop-blur-sm">
            <p className="text-xs text-gray-500">© 2024 CWSMS - Car Wash Management System. All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  )
}