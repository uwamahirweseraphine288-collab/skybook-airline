// pages/ServicePackages.jsx - Enhanced Table Version
import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function ServicePackages() {
  const [records, setRecords] = useState([])
  const [cars, setCars] = useState([])
  const [packages, setPackages] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ 
    serviceDate: new Date().toISOString().split('T')[0], 
    plateNumber: '', 
    packageId: '' 
  })
  const [editId, setEditId] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPackage, setSelectedPackage] = useState('all')
  const [showForm, setShowForm] = useState(true)

  const load = async () => {
    try {
      const [r, c, p] = await Promise.all([
        api.get('/service-packages'), 
        api.get('/cars'), 
        api.get('/packages')
      ])
      setRecords(r.data); 
      setCars(c.data); 
      setPackages(p.data)
    } catch(e) {} 
    finally { setLoading(false) }
  }
  
  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); 
    setError(''); 
    setSuccess(''); 
    setSubmitting(true)
    try {
      await api.post('/service-packages', form)
      setSuccess('Service record created successfully!')
      setForm({ 
        serviceDate: new Date().toISOString().split('T')[0], 
        plateNumber: '', 
        packageId: '' 
      })
      load()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) { 
      setError(err.response?.data?.error || 'Failed to create service record')
      setTimeout(() => setError(''), 3000)
    }
    finally { setSubmitting(false) }
  }

  const handleUpdate = async (id) => {
    try {
      await api.patch(`/service-packages/${id}`, editForm)
      setEditId(null); 
      load()
      setSuccess('Record updated successfully!')
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) { 
      alert(err.response?.data?.error || 'Update failed') 
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this service record?')) return
    try { 
      await api.delete(`/service-packages/${id}`); 
      load()
      setSuccess('Record deleted successfully!')
      setTimeout(() => setSuccess(''), 3000)
    }
    catch (err) { 
      alert(err.response?.data?.error || 'Delete failed') 
    }
  }

  // Filter records
  const filteredRecords = records.filter(record => {
    const matchesSearch = 
      record.plateNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.driverName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.packageName?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPackage = selectedPackage === 'all' || record.packageId === selectedPackage
    return matchesSearch && matchesPackage
  })

  // Calculate stats
  const totalServices = records.length
  const totalRevenue = records.reduce((sum, r) => sum + (r.packagePrice || 0), 0)
  const uniqueCars = [...new Set(records.map(r => r.plateNumber))].length

  // Get selected package details
  const selectedPackageDetails = packages.find(p => p._id === form.packageId)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="p-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                  <span className="text-white text-2xl">🔧</span>
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-white">Service Records</h1>
                  <p className="text-blue-100 mt-1">Manage car wash service history</p>
                </div>
              </div>
              <button
                onClick={() => setShowForm(!showForm)}
                className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-all duration-200 flex items-center gap-2"
              >
                <span>{showForm ? '📋' : '➕'}</span>
                <span>{showForm ? 'Hide Form' : 'Show Form'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Total Services</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{totalServices}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🔧
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Total Revenue</p>
                <p className="text-3xl font-bold text-green-600 mt-1">{totalRevenue.toLocaleString()} RWF</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                💰
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Unique Cars</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{uniqueCars}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🚗
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Avg Service Price</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">
                  {totalServices > 0 ? Math.round(totalRevenue / totalServices).toLocaleString() : 0} RWF
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                📊
              </div>
            </div>
          </div>
        </div>

        {/* Form Section - Toggleable */}
        {showForm && (
          <div className="mb-8">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">➕</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-800">New Service Record</h3>
              </div>
              
              {error && (
                <div className="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-lg text-sm">
                  <div className="flex items-center gap-2">
                    <span>⚠️</span>
                    <span>{error}</span>
                  </div>
                </div>
              )}
              
              {success && (
                <div className="mb-4 p-3 bg-green-50 border-l-4 border-green-500 text-green-700 rounded-lg text-sm">
                  <div className="flex items-center gap-2">
                    <span>✅</span>
                    <span>{success}</span>
                  </div>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Service Date *</label>
                  <input 
                    type="date" 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.serviceDate} 
                    onChange={e=>setForm(f=>({...f,serviceDate:e.target.value}))} 
                    required 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Select Car *</label>
                  <select 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.plateNumber} 
                    onChange={e=>setForm(f=>({...f,plateNumber:e.target.value}))} 
                    required
                  >
                    <option value="">Select a car...</option>
                    {cars.map(c => (
                      <option key={c._id} value={c.plateNumber}>
                        {c.plateNumber} - {c.carType} ({c.driverName})
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Service Package *</label>
                  <select 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.packageId} 
                    onChange={e=>setForm(f=>({...f,packageId:e.target.value}))} 
                    required
                  >
                    <option value="">Select a package...</option>
                    {packages.map(p => (
                      <option key={p._id} value={p._id}>
                        {p.packageName} - {p.packagePrice?.toLocaleString()} RWF
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-end">
                  <button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-2 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 disabled:opacity-50 font-medium shadow-md"
                    disabled={submitting}
                  >
                    {submitting ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Saving...</span>
                      </div>
                    ) : (
                      'Create Record'
                    )}
                  </button>
                </div>
              </form>

              {/* Package Details Preview */}
              {selectedPackageDetails && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-xs text-blue-600 font-semibold mb-1">Package Details</p>
                  <p className="text-sm text-gray-700">{selectedPackageDetails.packageDescription}</p>
                  <p className="text-sm font-bold text-blue-600 mt-1">
                    Price: {selectedPackageDetails.packagePrice?.toLocaleString()} RWF
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Records Table */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
          {/* Table Header with Search */}
          <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">📋</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Service History</h3>
                <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">
                  {filteredRecords.length} records
                </span>
              </div>
              
              <div className="flex gap-3">
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">🔍</span>
                  <input
                    type="text"
                    placeholder="Search by plate, driver, package..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-64"
                  />
                </div>
                
                <select
                  value={selectedPackage}
                  onChange={(e) => setSelectedPackage(e.target.value)}
                  className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                >
                  <option value="all">All Packages</option>
                  {packages.map(p => (
                    <option key={p._id} value={p._id}>{p.packageName}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-2 text-gray-500">Loading records...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">#</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Date</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Plate Number</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Driver Name</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Package</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Description</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Price (RWF)</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-12 text-gray-400">
                        {searchTerm || selectedPackage !== 'all' ? 'No matching records found' : 'No service records yet'}
                      </td>
                    </tr>
                  ) : (
                    filteredRecords.map((r, index) => (
                      <tr key={r._id} className="hover:bg-gray-50 transition-colors group">
                        {editId === r._id ? (
                          // Edit Mode
                          <>
                            <td className="py-3 px-4 text-gray-500">{index + 1}</td>
                            <td className="py-3 px-4">
                              <input 
                                type="date" 
                                className="w-full px-2 py-1 bg-gray-50 border border-gray-200 rounded text-sm"
                                value={editForm.serviceDate} 
                                onChange={e=>setEditForm(f=>({...f,serviceDate:e.target.value}))} 
                              />
                            </td>
                            <td className="py-3 px-4">
                              <select 
                                className="w-full px-2 py-1 bg-gray-50 border border-gray-200 rounded text-sm"
                                value={editForm.plateNumber} 
                                onChange={e=>setEditForm(f=>({...f,plateNumber:e.target.value}))}
                              >
                                {cars.map(c=>(
                                  <option key={c._id} value={c.plateNumber}>{c.plateNumber}</option>
                                ))}
                              </select>
                            </td>
                            <td className="py-3 px-4 text-gray-400">—</td>
                            <td className="py-3 px-4" colSpan={2}>
                              <select 
                                className="w-full px-2 py-1 bg-gray-50 border border-gray-200 rounded text-sm"
                                value={editForm.packageId} 
                                onChange={e=>setEditForm(f=>({...f,packageId:e.target.value}))}
                              >
                                {packages.map(p=>(
                                  <option key={p._id} value={p._id}>{p.packageName}</option>
                                ))}
                              </select>
                            </td>
                            <td className="py-3 px-4 text-gray-400">—</td>
                            <td className="py-3 px-4 whitespace-nowrap">
                              <button 
                                onClick={()=>handleUpdate(r._id)} 
                                className="text-green-600 hover:text-green-800 font-medium mr-2"
                              >
                                💾 Save
                              </button>
                              <button 
                                onClick={()=>setEditId(null)} 
                                className="text-gray-500 hover:text-gray-700"
                              >
                                ❌ Cancel
                              </button>
                            </td>
                          </>
                        ) : (
                          // View Mode
                          <>
                            <td className="py-3 px-4 text-gray-500">{index + 1}</td>
                            <td className="py-3 px-4 text-gray-700 whitespace-nowrap">{r.serviceDate}</td>
                            <td className="py-3 px-4">
                              <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded-lg text-xs font-mono font-semibold">
                                {r.plateNumber}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-gray-700 whitespace-nowrap">{r.driverName}</td>
                            <td className="py-3 px-4">
                              <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap">
                                {r.packageName}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-gray-500 max-w-xs truncate">
                              {r.packageDescription}
                            </td>
                            <td className="py-3 px-4 font-semibold text-green-600 whitespace-nowrap">
                              {r.packagePrice?.toLocaleString()} RWF
                            </td>
                            <td className="py-3 px-4 whitespace-nowrap">
                              <button 
                                onClick={()=>{
                                  setEditId(r._id);
                                  setEditForm({
                                    serviceDate: r.serviceDate,
                                    plateNumber: r.plateNumber,
                                    packageId: r.packageId
                                  })
                                }} 
                                className="text-blue-600 hover:text-blue-800 mr-3"
                              >
                                ✏️ Edit
                              </button>
                              <button 
                                onClick={()=>handleDelete(r._id)} 
                                className="text-red-600 hover:text-red-800"
                              >
                                🗑️ Delete
                              </button>
                            </td>
                          </>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center pt-6 mt-6 border-t border-gray-200">
          <p className="text-xs text-gray-400">© 2024 CWSMS - Service Management System</p>
        </div>
      </div>
    </div>
  )
}