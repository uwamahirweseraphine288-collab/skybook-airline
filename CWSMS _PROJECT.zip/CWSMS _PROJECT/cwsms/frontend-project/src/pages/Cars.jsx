// pages/Cars.jsx - Attractive Professional Version
import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function Cars() {
  const [cars, setCars] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ plateNumber: '', carType: '', carSize: 'Medium', driverName: '', phoneNumber: '' })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedSize, setSelectedSize] = useState('all')

  const load = () => api.get('/cars').then(r => setCars(r.data)).catch(() => {}).finally(() => setLoading(false))
  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); setSuccess(''); setSubmitting(true)
    try {
      await api.post('/cars', form)
      setSuccess('Car registered successfully!')
      setForm({ plateNumber: '', carType: '', carSize: 'Medium', driverName: '', phoneNumber: '' })
      load()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err) { 
      setError(err.response?.data?.error || 'Failed to register car')
      setTimeout(() => setError(''), 3000)
    }
    finally { setSubmitting(false) }
  }

  // Filter cars based on search and size
  const filteredCars = cars.filter(car => {
    const matchesSearch = 
      car.plateNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      car.carType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      car.driverName?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSize = selectedSize === 'all' || car.carSize === selectedSize
    return matchesSearch && matchesSize
  })

  // Calculate stats
  const totalCars = cars.length
  const totalDrivers = [...new Set(cars.map(car => car.driverName))].length
  const sizeCount = {
    Small: cars.filter(c => c.carSize === 'Small').length,
    Medium: cars.filter(c => c.carSize === 'Medium').length,
    Large: cars.filter(c => c.carSize === 'Large').length
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="p-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <span className="text-white text-2xl">🚗</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">Cars Management</h1>
                <p className="text-blue-100 mt-1">Register and manage all vehicles</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Total Cars</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{totalCars}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🚗
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Total Drivers</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{totalDrivers}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                👤
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Small Cars</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{sizeCount.Small}</p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🚙
              </div>
            </div>
          </div>

          <div className="group bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">Large Cars</p>
                <p className="text-3xl font-bold text-gray-800 mt-1">{sizeCount.Large}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🚐
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Registration Form */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-6 sticky top-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <span className="text-xl">➕</span>
                </div>
                <h3 className="text-lg font-semibold text-gray-800">Register New Car</h3>
              </div>
              
              {error && (
                <div className="mb-4 p-3 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-lg text-sm">
                  <div className="flex items-center gap-2">
                    <span>⚠️</span>
                    <span>{error}</span>
                  </div>
                </div>
              )}
              
              {success && (
                <div className="mb-4 p-3 bg-green-50 border-l-4 border-green-500 text-green-700 rounded-lg text-sm">
                  <div className="flex items-center gap-2">
                    <span>✅</span>
                    <span>{success}</span>
                  </div>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Plate Number *</label>
                  <input 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.plateNumber} 
                    onChange={e=>setForm(f=>({...f,plateNumber:e.target.value}))} 
                    placeholder="e.g. RAB 123 A" 
                    required 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Car Type *</label>
                  <input 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.carType} 
                    onChange={e=>setForm(f=>({...f,carType:e.target.value}))} 
                    placeholder="e.g. Toyota Corolla" 
                    required 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Car Size *</label>
                  <select 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.carSize} 
                    onChange={e=>setForm(f=>({...f,carSize:e.target.value}))}
                  >
                    <option value="Small">🚙 Small</option>
                    <option value="Medium">🚗 Medium</option>
                    <option value="Large">🚐 Large</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Driver Name *</label>
                  <input 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.driverName} 
                    onChange={e=>setForm(f=>({...f,driverName:e.target.value}))} 
                    placeholder="Full name" 
                    required 
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
                  <input 
                    className="w-full px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
                    value={form.phoneNumber} 
                    onChange={e=>setForm(f=>({...f,phoneNumber:e.target.value}))} 
                    placeholder="07XXXXXXXX" 
                    required 
                  />
                </div>
                
                <button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 disabled:opacity-50 font-medium shadow-md"
                  disabled={submitting}
                >
                  {submitting ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Saving...</span>
                    </div>
                  ) : (
                    'Register Car'
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Cars Table */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
              {/* Table Header with Search */}
              <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-gray-50 to-white">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <span className="text-xl">📋</span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-800">Registered Cars ({filteredCars.length})</h3>
                  </div>
                  
                  <div className="flex gap-3">
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">🔍</span>
                      <input
                        type="text"
                        placeholder="Search cars..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm w-48"
                      />
                    </div>
                    
                    <select
                      value={selectedSize}
                      onChange={(e) => setSelectedSize(e.target.value)}
                      className="px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                    >
                      <option value="all">All Sizes</option>
                      <option value="Small">Small</option>
                      <option value="Medium">Medium</option>
                      <option value="Large">Large</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {loading ? (
                <div className="text-center py-12">
                  <div className="inline-block w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="mt-2 text-gray-500">Loading cars...</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">#</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Plate Number</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Car Type</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Size</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Driver</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-600 text-sm">Phone</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {filteredCars.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="text-center py-12 text-gray-400">
                            {searchTerm || selectedSize !== 'all' ? 'No matching cars found' : 'No cars registered yet'}
                          </td>
                        </tr>
                      ) : (
                        filteredCars.map((c, index) => (
                          <tr key={c._id} className="hover:bg-gray-50 transition-colors group">
                            <td className="py-3 px-4 text-gray-500 text-sm">{index + 1}</td>
                            <td className="py-3 px-4 font-mono font-semibold text-gray-800">
                              <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded-lg text-xs">
                                {c.plateNumber}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-gray-700">{c.carType}</td>
                            <td className="py-3 px-4">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                c.carSize === 'Small' ? 'bg-emerald-100 text-emerald-700' :
                                c.carSize === 'Medium' ? 'bg-blue-100 text-blue-700' :
                                'bg-purple-100 text-purple-700'
                              }`}>
                                {c.carSize === 'Small' && '🚙'} 
                                {c.carSize === 'Medium' && '🚗'} 
                                {c.carSize === 'Large' && '🚐'} {c.carSize}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-gray-700">{c.driverName}</td>
                            <td className="py-3 px-4 text-gray-600">{c.phoneNumber}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center pt-6 mt-6 border-t border-gray-200">
          <p className="text-xs text-gray-400">© 2024 CWSMS - Car Management System</p>
        </div>
      </div>
    </div>
  )
}