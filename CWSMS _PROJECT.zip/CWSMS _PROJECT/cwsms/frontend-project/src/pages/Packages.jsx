import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function Packages() {
  const [packages, setPackages] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ packageName: '', packageDescription: '', packagePrice: '' })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const load = () => api.get('/packages').then(r => setPackages(r.data)).catch(() => {}).finally(() => setLoading(false))
  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); setSuccess(''); setSubmitting(true)
    try {
      await api.post('/packages', { ...form, packagePrice: Number(form.packagePrice) })
      setSuccess('Package added successfully')
      setForm({ packageName: '', packageDescription: '', packagePrice: '' })
      load()
    } catch (err) { setError(err.response?.data?.error || 'Failed to add package') }
    finally { setSubmitting(false) }
  }

  return (
    <div className="p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Service Packages</h2>
        <p className="text-gray-500 mt-1">Manage car wash service packages</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card lg:col-span-1">
          <h3 className="font-semibold text-gray-800 mb-4">Add New Package</h3>
          {error   && <div className="mb-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">{error}</div>}
          {success && <div className="mb-3 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm">{success}</div>}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div><label className="label">Package Name</label><input className="input" value={form.packageName} onChange={e=>setForm(f=>({...f,packageName:e.target.value}))} placeholder="e.g. VIP wash" required /></div>
            <div><label className="label">Description</label><textarea className="input resize-none" rows={3} value={form.packageDescription} onChange={e=>setForm(f=>({...f,packageDescription:e.target.value}))} placeholder="What does this package include?" required /></div>
            <div><label className="label">Price (RWF)</label><input className="input" type="number" min={0} value={form.packagePrice} onChange={e=>setForm(f=>({...f,packagePrice:e.target.value}))} placeholder="e.g. 15000" required /></div>
            <button type="submit" className="btn-primary w-full" disabled={submitting}>{submitting ? 'Saving...' : 'Add Package'}</button>
          </form>
        </div>

        <div className="card lg:col-span-2">
          <h3 className="font-semibold text-gray-800 mb-4">Available Packages ({packages.length})</h3>
          {loading ? <div className="text-center py-8 text-gray-400">Loading...</div> : (
            <div className="space-y-3">
              {packages.length === 0 ? <p className="text-center py-8 text-gray-400">No packages yet</p> :
                packages.map(p => (
                  <div key={p._id} className="flex items-start justify-between p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-primary/30 transition-colors">
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-800">{p.packageName}</h4>
                      <p className="text-sm text-gray-500 mt-0.5">{p.packageDescription}</p>
                    </div>
                    <span className="text-primary font-bold text-lg ml-4 whitespace-nowrap">{p.packagePrice?.toLocaleString()} RWF</span>
                  </div>
                ))
              }
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
