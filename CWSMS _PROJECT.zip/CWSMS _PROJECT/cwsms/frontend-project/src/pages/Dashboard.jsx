// pages/Dashboard.jsx - Dark Theme Matching Login Page
import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../App'

export default function Dashboard() {
  const navigate = useNavigate()
  const { user } = useAuth()
  const [stats, setStats] = useState({
    totalEmployees: 0,
    avgSalary: 0,
    totalDepartments: 0,
    recentEmployees: []
  })
  const [loading, setLoading] = useState(true)
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    if (!user) {
      navigate('/login')
      return
    }
    fetchStats()
    
    // Update time every second
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [user])

  const fetchStats = async () => {
    try {
      const res = await fetch('http://localhost:5000/api/dashboard/stats')
      const data = await res.json()
      setStats(data)
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  // Format time
  const formattedTime = currentTime.toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit'
  })
  
  const formattedDate = currentTime.toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  })

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="p-8">
        
        {/* Header with Gradient */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-6 shadow-xl border border-gray-700">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <span className="text-white text-2xl">📊</span>
                  </div>
                  <div>
                    <h1 className="text-3xl font-bold text-white">Dashboard</h1>
                    <p className="text-gray-400 mt-1">Welcome back, {user.username}!</p>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white text-sm font-mono bg-gray-900/50 px-3 py-1 rounded-lg">
                  {formattedTime}
                </div>
                <div className="text-gray-400 text-xs mt-1">
                  {formattedDate}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Total Employees Card */}
          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Employees</p>
                {loading ? (
                  <div className="w-16 h-8 bg-gray-700 rounded animate-pulse mt-1"></div>
                ) : (
                  <p className="text-3xl font-bold text-white mt-1">{stats.totalEmployees}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                👥
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-700">
              <p className="text-xs text-gray-500">Updated just now</p>
            </div>
          </div>

          {/* Average Salary Card */}
          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-green-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Average Salary</p>
                {loading ? (
                  <div className="w-24 h-8 bg-gray-700 rounded animate-pulse mt-1"></div>
                ) : (
                  <p className="text-3xl font-bold text-white mt-1">${stats.avgSalary.toLocaleString()}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                💰
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-700">
              <p className="text-xs text-gray-500">Across all departments</p>
            </div>
          </div>

          {/* Departments Card */}
          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-purple-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Departments</p>
                {loading ? (
                  <div className="w-12 h-8 bg-gray-700 rounded animate-pulse mt-1"></div>
                ) : (
                  <p className="text-3xl font-bold text-white mt-1">{stats.totalDepartments}</p>
                )}
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🏢
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-gray-700">
              <p className="text-xs text-gray-500">Active departments</p>
            </div>
          </div>
        </div>

        {/* Recent Employees Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          
          {/* Recent Employees Card */}
          <div className="bg-gray-800 rounded-xl shadow-lg border border-gray-700 overflow-hidden">
            <div className="p-6 border-b border-gray-700 bg-gray-800/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <span className="text-xl">👥</span>
                  </div>
                  <h2 className="text-lg font-semibold text-white">Recent Hires</h2>
                </div>
                <button 
                  onClick={() => navigate('/employees')}
                  className="text-sm text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 transition-colors"
                >
                  View all →
                </button>
              </div>
            </div>
            
            <div className="divide-y divide-gray-700">
              {loading ? (
                // Loading skeletons
                [...Array(3)].map((_, i) => (
                  <div key={i} className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-gray-700 rounded-xl animate-pulse"></div>
                      <div className="flex-1">
                        <div className="w-32 h-4 bg-gray-700 rounded animate-pulse mb-2"></div>
                        <div className="w-48 h-3 bg-gray-700 rounded animate-pulse"></div>
                      </div>
                    </div>
                  </div>
                ))
              ) : stats.recentEmployees.length > 0 ? (
                stats.recentEmployees.map((emp, index) => (
                  <div key={emp._id} className="p-5 hover:bg-gray-700/50 transition-colors group cursor-pointer">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center text-white font-semibold text-sm shadow-lg">
                        {emp.name?.charAt(0) || '?'}
                      </div>
                      <div className="flex-1">
                        <p className="font-semibold text-white">{emp.name}</p>
                        <p className="text-sm text-gray-400">{emp.position}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-gray-500">📧 {emp.email}</span>
                          <span className="text-xs text-gray-600">•</span>
                          <span className="text-xs text-gray-500">🏢 {emp.department}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-semibold text-green-400">${emp.salary?.toLocaleString()}</p>
                        <p className="text-xs text-gray-500 mt-1">#{index + 1}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-gray-500">
                  <span className="text-4xl block mb-2">👋</span>
                  <p>No employees added yet</p>
                  <button 
                    onClick={() => navigate('/employees')}
                    className="mt-2 text-blue-400 hover:text-blue-300 text-sm"
                  >
                    Add your first employee →
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Performance Summary & Quick Stats */}
          <div className="space-y-6">
            {/* Performance Summary */}
            <div className="bg-gray-800 rounded-xl shadow-lg border border-gray-700 p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <span className="text-xl">📊</span>
                </div>
                <h2 className="text-lg font-semibold text-white">Performance Summary</h2>
              </div>
              
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-400 text-sm">Employee Satisfaction</span>
                    <span className="text-white text-sm font-semibold">88%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-green-500 rounded-full h-2" style={{ width: '88%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-400 text-sm">Attendance Rate</span>
                    <span className="text-white text-sm font-semibold">94%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-blue-500 rounded-full h-2" style={{ width: '94%' }}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-gray-400 text-sm">Retention Rate</span>
                    <span className="text-white text-sm font-semibold">92%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-purple-500 rounded-full h-2" style={{ width: '92%' }}></div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl shadow-lg p-6">
              <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <span>⭐</span>
                Company Overview
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center">
                  <p className="text-white/80 text-sm">Total Revenue</p>
                  <p className="text-white text-2xl font-bold">$0</p>
                </div>
                <div className="text-center">
                  <p className="text-white/80 text-sm">Active Cars</p>
                  <p className="text-white text-2xl font-bold">0</p>
                </div>
                <div className="text-center">
                  <p className="text-white/80 text-sm">Packages</p>
                  <p className="text-white text-2xl font-bold">0</p>
                </div>
                <div className="text-center">
                  <p className="text-white/80 text-sm">Services</p>
                  <p className="text-white text-2xl font-bold">0</p>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gray-800 rounded-xl shadow-lg border border-gray-700 p-6">
              <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <span>⚡</span>
                Quick Actions
              </h2>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => navigate('/employees')}
                  className="bg-gray-700 hover:bg-gray-600 rounded-lg p-3 text-center transition-all duration-200 group"
                >
                  <span className="text-2xl block mb-1 group-hover:scale-110 transition-transform">👥</span>
                  <span className="text-sm text-gray-300">Employees</span>
                </button>
                <button 
                  onClick={() => navigate('/cars')}
                  className="bg-gray-700 hover:bg-gray-600 rounded-lg p-3 text-center transition-all duration-200 group"
                >
                  <span className="text-2xl block mb-1 group-hover:scale-110 transition-transform">🚗</span>
                  <span className="text-sm text-gray-300">Cars</span>
                </button>
                <button 
                  onClick={() => navigate('/packages')}
                  className="bg-gray-700 hover:bg-gray-600 rounded-lg p-3 text-center transition-all duration-200 group"
                >
                  <span className="text-2xl block mb-1 group-hover:scale-110 transition-transform">📦</span>
                  <span className="text-sm text-gray-300">Packages</span>
                </button>
                <button 
                  onClick={() => navigate('/payments')}
                  className="bg-gray-700 hover:bg-gray-600 rounded-lg p-3 text-center transition-all duration-200 group"
                >
                  <span className="text-2xl block mb-1 group-hover:scale-110 transition-transform">💰</span>
                  <span className="text-sm text-gray-300">Payments</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center pt-6 border-t border-gray-800">
          <p className="text-xs text-gray-500">© 2024 CWSMS - Car Wash Management System. All rights reserved.</p>
        </div>
      </div>
    </div>
  )
}