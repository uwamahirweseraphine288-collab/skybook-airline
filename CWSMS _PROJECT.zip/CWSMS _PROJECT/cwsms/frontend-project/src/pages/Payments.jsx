import { useState, useEffect } from 'react'
import api from '../api/axios'

function BillModal({ bill, onClose }) {
  const printBill = () => window.print()
  if (!bill) return null
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full" id="bill-content">
        <div className="p-6 border-b border-gray-100 text-center">
          <h2 className="text-xl font-bold text-gray-900">{bill.company}</h2>
          <p className="text-sm text-gray-500">{bill.location}</p>
          <p className="text-xs text-gray-400 mt-1">Receipt #{String(bill.receiptNumber).slice(-8).toUpperCase()}</p>
        </div>
        <div className="p-6 space-y-3">
          <div className="flex justify-between text-sm"><span className="text-gray-500">Driver</span><span className="font-medium">{bill.driverName}</span></div>
          <div className="flex justify-between text-sm"><span className="text-gray-500">Plate Number</span><span className="font-mono font-semibold">{bill.plateNumber}</span></div>
          <div className="flex justify-between text-sm"><span className="text-gray-500">Service</span><span className="font-medium">{bill.packageName}</span></div>
          <div className="flex justify-between text-sm"><span className="text-gray-500">Description</span><span className="text-right max-w-[60%]">{bill.packageDescription}</span></div>
          <div className="flex justify-between text-sm"><span className="text-gray-500">Package Price</span><span>{bill.packagePrice?.toLocaleString()} RWF</span></div>
          <div className="flex justify-between text-sm"><span className="text-gray-500">Payment Date</span><span>{bill.paymentDate}</span></div>
          <div className="border-t border-gray-100 pt-3 flex justify-between font-bold text-lg">
            <span>Amount Paid</span>
            <span className="text-green-600">{bill.amountPaid?.toLocaleString()} RWF</span>
          </div>
        </div>
        <div className="p-4 flex gap-3 border-t border-gray-100">
          <button onClick={printBill} className="btn-primary flex-1">Print Bill</button>
          <button onClick={onClose} className="btn-secondary flex-1">Close</button>
        </div>
      </div>
    </div>
  )
}

export default function Payments() {
  const [payments, setPayments] = useState([])
  const [serviceRecords, setServiceRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({ amountPaid: '', paymentDate: new Date().toISOString().split('T')[0], plateNumber: '', serviceId: '' })
  const [bill, setBill] = useState(null)
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const load = async () => {
    try {
      const [p, s] = await Promise.all([api.get('/payments'), api.get('/service-packages')])
      setPayments(p.data); setServiceRecords(s.data)
    } catch(e) {} finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  const selectedService = serviceRecords.find(s => s._id === form.serviceId)

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); setSubmitting(true)
    try {
      const payload = { ...form, amountPaid: Number(form.amountPaid) }
      const res = await api.post('/payments', payload)
      setBill(res.data.bill)
      setForm({ amountPaid: '', paymentDate: new Date().toISOString().split('T')[0], plateNumber: '', serviceId: '' })
      load()
    } catch (err) { setError(err.response?.data?.error || 'Failed to record payment') }
    finally { setSubmitting(false) }
  }

  return (
    <div className="p-8">
      <BillModal bill={bill} onClose={() => setBill(null)} />
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900">Payments</h2>
        <p className="text-gray-500 mt-1">Record payments and generate receipts</p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card lg:col-span-1">
          <h3 className="font-semibold text-gray-800 mb-4">Record Payment</h3>
          {error && <div className="mb-3 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">{error}</div>}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="label">Link to Service Record (optional)</label>
              <select className="input" value={form.serviceId} onChange={e=>{
                const s = serviceRecords.find(x=>x._id===e.target.value)
                setForm(f=>({...f,serviceId:e.target.value,plateNumber:s?.plateNumber||f.plateNumber,amountPaid:s?.packagePrice||f.amountPaid}))
              }}>
                <option value="">Select service record...</option>
                {serviceRecords.map(s=><option key={s._id} value={s._id}>{s.serviceDate} — {s.plateNumber} ({s.packageName})</option>)}
              </select>
            </div>
            {selectedService && (
              <div className="p-3 bg-sky-50 rounded-lg text-sm">
                <p className="font-medium text-sky-800">{selectedService.packageName}</p>
                <p className="text-sky-600">{selectedService.packageDescription}</p>
                <p className="text-sky-700 font-semibold mt-1">Price: {selectedService.packagePrice?.toLocaleString()} RWF</p>
              </div>
            )}
            <div><label className="label">Plate Number</label><input className="input" value={form.plateNumber} onChange={e=>setForm(f=>({...f,plateNumber:e.target.value}))} placeholder="RAB 123 A" required /></div>
            <div><label className="label">Amount Paid (RWF)</label><input className="input" type="number" min={0} value={form.amountPaid} onChange={e=>setForm(f=>({...f,amountPaid:e.target.value}))} required /></div>
            <div><label className="label">Payment Date</label><input className="input" type="date" value={form.paymentDate} onChange={e=>setForm(f=>({...f,paymentDate:e.target.value}))} required /></div>
            <button type="submit" className="btn-primary w-full" disabled={submitting}>{submitting ? 'Processing...' : 'Record Payment & Get Bill'}</button>
          </form>
        </div>

        <div className="card lg:col-span-2">
          <h3 className="font-semibold text-gray-800 mb-4">Payment History ({payments.length})</h3>
          {loading ? <div className="text-center py-8 text-gray-400">Loading...</div> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr><th className="table-th">Date</th><th className="table-th">Plate</th><th className="table-th">Driver</th><th className="table-th">Package</th><th className="table-th">Amount Paid</th></tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {payments.length === 0 ? <tr><td colSpan={5} className="text-center py-8 text-gray-400">No payments yet</td></tr> :
                    payments.map(p => (
                      <tr key={p._id} className="hover:bg-gray-50">
                        <td className="table-td">{p.paymentDate}</td>
                        <td className="table-td font-mono font-semibold">{p.plateNumber}</td>
                        <td className="table-td">{p.driverName}</td>
                        <td className="table-td"><span className="badge-green">{p.packageName || '—'}</span></td>
                        <td className="table-td font-bold text-green-600">{p.amountPaid?.toLocaleString()} RWF</td>
                      </tr>
                    ))
                  }
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
