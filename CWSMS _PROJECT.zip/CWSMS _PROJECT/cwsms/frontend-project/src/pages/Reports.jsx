import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function Reports() {
  const [report, setReport] = useState([])
  const [date, setDate] = useState('')
  const [loading, setLoading] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const params = date ? { date } : {}
      const res = await api.get('/reports/daily', { params })
      setReport(res.data)
    } catch(e) {}
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const totalRevenue = report.reduce((sum, r) => sum + (r.amountPaid || 0), 0)

  const handlePrint = () => window.print()

  return (
    <div className="p-8">
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Daily Reports</h2>
          <p className="text-gray-500 mt-1">Plate number, package, amount paid and payment date</p>
        </div>
        <button onClick={handlePrint} className="btn-secondary flex items-center gap-2 self-start">
          <span>🖨</span> Print Report
        </button>
      </div>

      <div className="card mb-6">
        <div className="flex flex-col sm:flex-row gap-4 items-end">
          <div className="flex-1">
            <label className="label">Filter by Date</label>
            <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
          <div className="flex gap-2">
            <button onClick={load} className="btn-primary">Apply Filter</button>
            <button onClick={() => { setDate(''); setTimeout(load, 0) }} className="btn-secondary">Clear</button>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-6 print:mb-4">
          <div>
            <h3 className="font-semibold text-gray-800 text-lg">SmartPark Car Wash — Daily Report</h3>
            <p className="text-sm text-gray-500">{date ? `Date: ${date}` : 'All records'} — {report.length} record(s)</p>
          </div>
          {report.length > 0 && (
            <div className="text-right">
              <p className="text-sm text-gray-500">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600">{totalRevenue.toLocaleString()} RWF</p>
            </div>
          )}
        </div>

        {loading ? <div className="text-center py-8 text-gray-400">Loading...</div> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="table-th">#</th>
                  <th className="table-th">Plate Number</th>
                  <th className="table-th">Driver Name</th>
                  <th className="table-th">Package Name</th>
                  <th className="table-th">Package Description</th>
                  <th className="table-th">Amount Paid</th>
                  <th className="table-th">Payment Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {report.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-12 text-gray-400">No records found{date ? ` for ${date}` : ''}</td></tr>
                ) : (
                  report.map((r, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="table-td text-gray-400">{i + 1}</td>
                      <td className="table-td font-mono font-semibold">{r.plateNumber}</td>
                      <td className="table-td">{r.driverName}</td>
                      <td className="table-td"><span className="badge-blue">{r.packageName}</span></td>
                      <td className="table-td text-gray-500">{r.packageDescription}</td>
                      <td className="table-td font-bold text-green-600">{r.amountPaid?.toLocaleString()} RWF</td>
                      <td className="table-td">{r.paymentDate}</td>
                    </tr>
                  ))
                )}
              </tbody>
              {report.length > 0 && (
                <tfoot className="bg-gray-50 border-t-2 border-gray-200">
                  <tr>
                    <td colSpan={5} className="table-td font-bold text-gray-700">TOTAL</td>
                    <td className="table-td font-bold text-green-600 text-base">{totalRevenue.toLocaleString()} RWF</td>
                    <td className="table-td"></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
