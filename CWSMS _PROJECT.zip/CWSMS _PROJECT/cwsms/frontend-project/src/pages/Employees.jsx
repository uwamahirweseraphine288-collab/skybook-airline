// pages/Employees.jsx - Dark Theme Attractive Version
import { useState, useEffect } from 'react'
import axios from 'axios'

export default function Employees() {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState({
    name: '',
    email: '',
    position: '',
    department: '',
    salary: ''
  })
  const [editId, setEditId] = useState(null)
  const [editForm, setEditForm] = useState({})
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedDepartment, setSelectedDepartment] = useState('all')

  // Fetch employees
  const loadEmployees = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/employees')
      setEmployees(response.data)
      setError('')
    } catch (error) {
      console.error('Error fetching employees:', error)
      setError('Failed to load employees')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadEmployees()
  }, [])

  // Handle form input change
  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    })
  }

  // Add employee
  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    setSubmitting(true)

    try {
      const response = await axios.post('http://localhost:5000/api/employees', {
        name: form.name,
        email: form.email,
        position: form.position,
        department: form.department,
        salary: Number(form.salary)
      })
      
      if (response.data) {
        setSuccess('Employee added successfully!')
        setForm({ name: '', email: '', position: '', department: '', salary: '' })
        loadEmployees()
        
        setTimeout(() => setSuccess(''), 3000)
      }
    } catch (error) {
      console.error('Error adding employee:', error)
      setError(error.response?.data?.message || 'Failed to add employee')
      setTimeout(() => setError(''), 3000)
    } finally {
      setSubmitting(false)
    }
  }

  // Update employee
  const handleUpdate = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/employees/${id}`, {
        name: editForm.name,
        email: editForm.email,
        position: editForm.position,
        department: editForm.department,
        salary: Number(editForm.salary)
      })
      setEditId(null)
      loadEmployees()
      setSuccess('Employee updated successfully!')
      setTimeout(() => setSuccess(''), 3000)
    } catch (error) {
      console.error('Error updating employee:', error)
      setError(error.response?.data?.message || 'Failed to update employee')
      setTimeout(() => setError(''), 3000)
    }
  }

  // Delete employee
  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this employee?')) return
    
    try {
      await axios.delete(`http://localhost:5000/api/employees/${id}`)
      loadEmployees()
      setSuccess('Employee deleted successfully!')
      setTimeout(() => setSuccess(''), 3000)
    } catch (error) {
      console.error('Error deleting employee:', error)
      setError(error.response?.data?.message || 'Failed to delete employee')
      setTimeout(() => setError(''), 3000)
    }
  }

  // Get unique departments for filter
  const departments = ['all', ...new Set(employees.map(emp => emp.department).filter(Boolean))]

  // Filter employees based on search and department
  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = 
      emp.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.position?.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesDepartment = selectedDepartment === 'all' || emp.department === selectedDepartment
    return matchesSearch && matchesDepartment
  })

  // Calculate stats
  const totalEmployees = employees.length
  const totalSalary = employees.reduce((sum, emp) => sum + (emp.salary || 0), 0)
  const avgSalary = totalEmployees > 0 ? totalSalary / totalEmployees : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="p-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-6 shadow-xl border border-gray-700">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white text-2xl">👥</span>
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">Employees</h1>
                <p className="text-gray-400 mt-1">Manage your workforce efficiently</p>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Employees</p>
                <p className="text-3xl font-bold text-white mt-1">{totalEmployees}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                👥
              </div>
            </div>
          </div>

          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-green-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Average Salary</p>
                <p className="text-3xl font-bold text-white mt-1">${Math.round(avgSalary).toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                💰
              </div>
            </div>
          </div>

          <div className="group bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-700 hover:border-purple-500 transition-all duration-300 hover:-translate-y-1">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Departments</p>
                <p className="text-3xl font-bold text-white mt-1">{Math.max(0, departments.length - 1)}</p>
              </div>
              <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                🏢
              </div>
            </div>
          </div>
        </div>

        {/* Add Employee Form */}
        <div className="bg-gray-800 rounded-xl shadow-lg border border-gray-700 p-6 mb-8">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <span className="text-xl">➕</span> Add New Employee
          </h3>
          
          {error && (
            <div className="mb-4 p-3 bg-red-900/50 border-l-4 border-red-500 text-red-200 rounded-lg text-sm">
              <div className="flex items-center gap-2">
                <span>⚠️</span>
                <span>{error}</span>
              </div>
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-900/50 border-l-4 border-green-500 text-green-200 rounded-lg text-sm">
              <div className="flex items-center gap-2">
                <span>✅</span>
                <span>{success}</span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div>
              <label className="block text-gray-300 mb-2 font-medium text-sm">Full Name *</label>
              <input
                type="text"
                name="name"
                value={form.name}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                placeholder="John Doe"
                required
              />
            </div>
            
            <div>
              <label className="block text-gray-300 mb-2 font-medium text-sm">Email *</label>
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                placeholder="john@example.com"
                required
              />
            </div>
            
            <div>
              <label className="block text-gray-300 mb-2 font-medium text-sm">Position *</label>
              <input
                type="text"
                name="position"
                value={form.position}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                placeholder="Software Engineer"
                required
              />
            </div>
            
            <div>
              <label className="block text-gray-300 mb-2 font-medium text-sm">Department *</label>
              <input
                type="text"
                name="department"
                value={form.department}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                placeholder="Engineering"
                required
              />
            </div>
            
            <div>
              <label className="block text-gray-300 mb-2 font-medium text-sm">Salary ($) *</label>
              <input
                type="number"
                name="salary"
                value={form.salary}
                onChange={handleChange}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                placeholder="50000"
                required
              />
            </div>
            
            <div className="md:col-span-2 lg:col-span-5">
              <button
                type="submit"
                disabled={submitting}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-2 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 font-medium"
              >
                {submitting ? 'Adding...' : 'Add Employee'}
              </button>
            </div>
          </form>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">🔍</span>
              <input
                type="text"
                placeholder="Search by name, email or position..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-500"
              />
            </div>
          </div>
          
          <select
            value={selectedDepartment}
            onChange={(e) => setSelectedDepartment(e.target.value)}
            className="px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
          >
            {departments.map(dept => (
              <option key={dept} value={dept}>
                {dept === 'all' ? 'All Departments' : dept}
              </option>
            ))}
          </select>
        </div>

        {/* Employees Table */}
        <div className="bg-gray-800 rounded-xl shadow-lg border border-gray-700 overflow-hidden">
          <div className="p-6 border-b border-gray-700 bg-gray-800/50">
            <h3 className="font-semibold text-white">Employee List ({filteredEmployees.length})</h3>
          </div>
          
          {loading ? (
            <div className="text-center py-12 text-gray-500">
              <div className="inline-block w-8 h-8 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-2">Loading employees...</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-700/50 border-b border-gray-700">
                  <tr>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">#</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Name</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Email</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Position</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Department</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Salary</th>
                    <th className="text-left py-3 px-4 font-semibold text-gray-300 text-sm">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-12 text-gray-500">
                        No employees found
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.map((emp, index) => (
                      <tr key={emp._id} className="hover:bg-gray-700/50 transition-colors">
                        {editId === emp._id ? (
                          <>
                            <td className="py-3 px-4 text-gray-400">{index + 1}</td>
                            <td className="py-3 px-4">
                              <input
                                type="text"
                                value={editForm.name || ''}
                                onChange={(e) => setEditForm({...editForm, name: e.target.value})}
                                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white"
                              />
                            </td>
                            <td className="py-3 px-4">
                              <input
                                type="email"
                                value={editForm.email || ''}
                                onChange={(e) => setEditForm({...editForm, email: e.target.value})}
                                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white"
                              />
                            </td>
                            <td className="py-3 px-4">
                              <input
                                type="text"
                                value={editForm.position || ''}
                                onChange={(e) => setEditForm({...editForm, position: e.target.value})}
                                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white"
                              />
                            </td>
                            <td className="py-3 px-4">
                              <input
                                type="text"
                                value={editForm.department || ''}
                                onChange={(e) => setEditForm({...editForm, department: e.target.value})}
                                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white"
                              />
                            </td>
                            <td className="py-3 px-4">
                              <input
                                type="number"
                                value={editForm.salary || ''}
                                onChange={(e) => setEditForm({...editForm, salary: e.target.value})}
                                className="w-full px-2 py-1 bg-gray-700 border border-gray-600 rounded text-white"
                              />
                            </td>
                            <td className="py-3 px-4">
                              <button
                                onClick={() => handleUpdate(emp._id)}
                                className="text-green-400 hover:text-green-300 font-medium mr-2"
                              >
                                💾 Save
                              </button>
                              <button
                                onClick={() => setEditId(null)}
                                className="text-gray-400 hover:text-gray-300"
                              >
                                ❌ Cancel
                              </button>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="py-3 px-4 text-gray-500">{index + 1}</td>
                            <td className="py-3 px-4 font-medium text-white">{emp.name}</td>
                            <td className="py-3 px-4 text-gray-400">{emp.email}</td>
                            <td className="py-3 px-4 text-gray-300">{emp.position}</td>
                            <td className="py-3 px-4">
                              <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full text-xs font-medium">
                                {emp.department}
                              </span>
                            </td>
                            <td className="py-3 px-4 font-semibold text-green-400">
                              ${emp.salary?.toLocaleString()}
                            </td>
                            <td className="py-3 px-4">
                              <button
                                onClick={() => {
                                  setEditId(emp._id)
                                  setEditForm({
                                    name: emp.name,
                                    email: emp.email,
                                    position: emp.position,
                                    department: emp.department,
                                    salary: emp.salary
                                  })
                                }}
                                className="text-blue-400 hover:text-blue-300 mr-3"
                              >
                                ✏️ Edit
                              </button>
                              <button
                                onClick={() => handleDelete(emp._id)}
                                className="text-red-400 hover:text-red-300"
                              >
                                🗑️ Delete
                              </button>
                            </td>
                          </>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center pt-6 mt-6 border-t border-gray-800">
          <p className="text-xs text-gray-500">© 2024 CWSMS - Employee Management System</p>
        </div>
      </div>
    </div>
  )
}