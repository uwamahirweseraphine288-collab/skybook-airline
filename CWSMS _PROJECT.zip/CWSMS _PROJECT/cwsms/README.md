# SmartPark CWSMS
Car Washing Sales Management System

## Structure
- backend-project/  — Express.js + MongoDB API (port 8080)
- frontend-project/ — React + Vite + Tailwind CSS UI (port 5173)

## Quick Start

### 1. Start MongoDB
Make sure MongoDB is running on your machine.

### 2. Backend
```bash
cd backend-project
npm install
npm run dev
```

### 3. Frontend
```bash
cd frontend-project
npm install
npm run dev
```

### 4. Open the app
Go to http://localhost:5173
Login: admin / admin123

## Features
- Session-based login
- Cars: register cars (insert only)
- Packages: manage wash packages (insert only)
- Service Records: full CRUD (insert, edit, delete, view)
- Payments: record payments + auto-generate printable bill/receipt
- Reports: daily report filtered by date (PlateNumber, PackageName, Description, AmountPaid, PaymentDate)
- Dashboard: summary stats

## Pre-seeded Packages
| Package | Description | Price |
|---------|-------------|-------|
| Basic wash | Exterior hand wash | 5,000 RWF |
| Classic wash | Interior hand wash | 10,000 RWF |
| Premium wash | Exterior and Interior hand wash | 20,000 RWF |
