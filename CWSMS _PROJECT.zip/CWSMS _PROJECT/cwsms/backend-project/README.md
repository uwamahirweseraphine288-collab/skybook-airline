# CWSMS Backend

Express.js + MongoDB backend for SmartPark Car Washing Sales Management System.

## Setup & Run

```bash
npm install
npm run dev     # development with auto-restart
npm start       # production
```

Requires a .env file — copy from .env.example.

## Default Login
Username: admin  |  Password: admin123

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/logout | Logout |
| GET | /api/auth/me | Current session |
| GET/POST | /api/cars | List / add car |
| GET/POST | /api/packages | List / add package |
| GET/POST | /api/service-packages | List / create record |
| PATCH/DELETE | /api/service-packages/:id | Update / delete record |
| GET/POST | /api/payments | List / record payment (returns bill) |
| GET | /api/reports/daily?date=YYYY-MM-DD | Daily report |
| GET | /api/reports/summary | Dashboard stats |
