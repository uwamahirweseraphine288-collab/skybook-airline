const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/CWSMS';
    await mongoose.connect(uri);
    console.log('MongoDB connected to CWSMS database');
    await seedData();
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    process.exit(1);
  }
};

async function seedData() {
  const User = require('../models/User');
  const Package = require('../models/Package');

  const adminExists = await User.findOne({ username: 'admin' });
  if (!adminExists) {
    await User.create({ username: 'admin', password: 'admin123' });
    console.log('Default admin user created (admin / admin123)');
  }

  const pkgCount = await Package.countDocuments();
  if (pkgCount === 0) {
    await Package.insertMany([
      { packageName: 'Basic wash',   packageDescription: 'Exterior hand wash',              packagePrice: 5000  },
      { packageName: 'Classic wash', packageDescription: 'Interior hand wash',              packagePrice: 10000 },
      { packageName: 'Premium wash', packageDescription: 'Exterior and Interior hand wash', packagePrice: 20000 },
    ]);
    console.log('Default packages seeded');
  }
}

module.exports = connectDB;
