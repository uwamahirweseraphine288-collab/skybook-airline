const express = require('express');
const router = express.Router();
const Car = require('../models/Car');
const { requireAuth } = require('../middleware/auth');

router.get('/cars', requireAuth, async (req, res) => {
  try {
    const cars = await Car.find().sort({ createdAt: -1 });
    res.json(cars);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/cars', requireAuth, async (req, res) => {
  try {
    const { plateNumber, carType, carSize, driverName, phoneNumber } = req.body;
    if (!plateNumber || !carType || !carSize || !driverName || !phoneNumber)
      return res.status(400).json({ error: 'All fields are required' });
    const existing = await Car.findOne({ plateNumber: plateNumber.toUpperCase() });
    if (existing) return res.status(400).json({ error: 'Plate number already registered' });
    const car = await Car.create({ plateNumber, carType, carSize, driverName, phoneNumber });
    res.status(201).json(car);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/cars/:plateNumber', requireAuth, async (req, res) => {
  try {
    const car = await Car.findOne({ plateNumber: req.params.plateNumber.toUpperCase() });
    if (!car) return res.status(404).json({ error: 'Car not found' });
    res.json(car);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
