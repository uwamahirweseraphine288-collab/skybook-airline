const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const ServicePackage = require('../models/ServicePackage');
const Package = require('../models/Package');
const Car = require('../models/Car');
const { requireAuth } = require('../middleware/auth');

router.get('/payments', requireAuth, async (req, res) => {
  try {
    const payments = await Payment.find().sort({ createdAt: -1 });
    const enriched = await Promise.all(payments.map(async (p) => {
      const car = await Car.findOne({ plateNumber: p.plateNumber });
      let pkg = null;
      if (p.serviceId) {
        const sp = await ServicePackage.findById(p.serviceId);
        if (sp) pkg = await Package.findById(sp.packageId);
      }
      return {
        _id: p._id,
        amountPaid: p.amountPaid,
        paymentDate: p.paymentDate,
        plateNumber: p.plateNumber,
        serviceId: p.serviceId,
        driverName: car?.driverName || '',
        packageName: pkg?.packageName || '',
        packageDescription: pkg?.packageDescription || '',
        packagePrice: pkg?.packagePrice || 0,
      };
    }));
    res.json(enriched);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/payments', requireAuth, async (req, res) => {
  try {
    const { amountPaid, paymentDate, plateNumber, serviceId } = req.body;
    if (!amountPaid || !paymentDate || !plateNumber)
      return res.status(400).json({ error: 'All fields are required' });
    const payment = await Payment.create({ amountPaid, paymentDate, plateNumber: plateNumber.toUpperCase(), serviceId });

    // Build bill
    const car = await Car.findOne({ plateNumber: plateNumber.toUpperCase() });
    let sp = null, pkg = null;
    if (serviceId) {
      sp = await ServicePackage.findById(serviceId);
      if (sp) pkg = await Package.findById(sp.packageId);
    }
    res.status(201).json({
      _id: payment._id,
      amountPaid: payment.amountPaid,
      paymentDate: payment.paymentDate,
      plateNumber: payment.plateNumber,
      serviceId: payment.serviceId,
      driverName: car?.driverName || '',
      phoneNumber: car?.phoneNumber || '',
      packageName: pkg?.packageName || '',
      packageDescription: pkg?.packageDescription || '',
      packagePrice: pkg?.packagePrice || 0,
      bill: {
        receiptNumber: payment._id,
        driverName: car?.driverName || '',
        plateNumber: payment.plateNumber,
        packageName: pkg?.packageName || '',
        packageDescription: pkg?.packageDescription || '',
        packagePrice: pkg?.packagePrice || 0,
        amountPaid: payment.amountPaid,
        paymentDate: payment.paymentDate,
        company: 'SmartPark Car Wash',
        location: 'Rubavu District, Western Province, Rwanda',
      },
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/payments/:id', requireAuth, async (req, res) => {
  try {
    const p = await Payment.findById(req.params.id);
    if (!p) return res.status(404).json({ error: 'Payment not found' });
    res.json(p);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
