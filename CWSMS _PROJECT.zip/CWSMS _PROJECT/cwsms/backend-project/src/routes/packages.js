const express = require('express');
const router = express.Router();
const Package = require('../models/Package');
const { requireAuth } = require('../middleware/auth');

router.get('/packages', requireAuth, async (req, res) => {
  try {
    res.json(await Package.find().sort({ packagePrice: 1 }));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/packages', requireAuth, async (req, res) => {
  try {
    const { packageName, packageDescription, packagePrice } = req.body;
    if (!packageName || !packageDescription || packagePrice == null)
      return res.status(400).json({ error: 'All fields are required' });
    const pkg = await Package.create({ packageName, packageDescription, packagePrice });
    res.status(201).json(pkg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/packages/:id', requireAuth, async (req, res) => {
  try {
    const pkg = await Package.findById(req.params.id);
    if (!pkg) return res.status(404).json({ error: 'Package not found' });
    res.json(pkg);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
