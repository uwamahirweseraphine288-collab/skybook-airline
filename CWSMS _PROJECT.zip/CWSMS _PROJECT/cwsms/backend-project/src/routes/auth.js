const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: 'Username and password required' });
    const user = await User.findOne({ username });
    if (!user || user.password !== password)
      return res.status(401).json({ error: 'Invalid username or password' });
    req.session.userId = user._id.toString();
    req.session.username = user.username;
    res.json({ id: user._id, username: user.username });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/auth/logout', (req, res) => {
  req.session.destroy(() => res.json({ message: 'Logged out' }));
});

router.get('/auth/me', async (req, res) => {
  try {
    if (!req.session.userId)
      return res.status(401).json({ error: 'Not authenticated' });
    const user = await User.findById(req.session.userId);
    if (!user) return res.status(401).json({ error: 'User not found' });
    res.json({ id: user._id, username: user.username });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
