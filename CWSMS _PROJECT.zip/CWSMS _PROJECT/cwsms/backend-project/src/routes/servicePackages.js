const express = require('express');
const router = express.Router();
const ServicePackage = require('../models/ServicePackage');
const Package = require('../models/Package');
const Car = require('../models/Car');
const { requireAuth } = require('../middleware/auth');

async function enrich(sp) {
  const pkg = await Package.findById(sp.packageId);
  const car = await Car.findOne({ plateNumber: sp.plateNumber });
  return {
    _id: sp._id,
    serviceDate: sp.serviceDate,
    plateNumber: sp.plateNumber,
    packageId: sp.packageId,
    packageName: pkg?.packageName || '',
    packageDescription: pkg?.packageDescription || '',
    packagePrice: pkg?.packagePrice || 0,
    driverName: car?.driverName || '',
    phoneNumber: car?.phoneNumber || '',
    carType: car?.carType || '',
    createdAt: sp.createdAt,
  };
}

router.get('/service-packages', requireAuth, async (req, res) => {
  try {
    const list = await ServicePackage.find().sort({ createdAt: -1 });
    res.json(await Promise.all(list.map(enrich)));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/service-packages', requireAuth, async (req, res) => {
  try {
    const { serviceDate, plateNumber, packageId } = req.body;
    if (!serviceDate || !plateNumber || !packageId)
      return res.status(400).json({ error: 'All fields are required' });
    const sp = await ServicePackage.create({ serviceDate, plateNumber: plateNumber.toUpperCase(), packageId });
    res.status(201).json(await enrich(sp));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/service-packages/:id', requireAuth, async (req, res) => {
  try {
    const sp = await ServicePackage.findById(req.params.id);
    if (!sp) return res.status(404).json({ error: 'Service record not found' });
    res.json(await enrich(sp));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.patch('/service-packages/:id', requireAuth, async (req, res) => {
  try {
    const { serviceDate, plateNumber, packageId } = req.body;
    const sp = await ServicePackage.findByIdAndUpdate(
      req.params.id,
      { ...(serviceDate && { serviceDate }), ...(plateNumber && { plateNumber: plateNumber.toUpperCase() }), ...(packageId && { packageId }) },
      { new: true }
    );
    if (!sp) return res.status(404).json({ error: 'Service record not found' });
    res.json(await enrich(sp));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.delete('/service-packages/:id', requireAuth, async (req, res) => {
  try {
    const sp = await ServicePackage.findByIdAndDelete(req.params.id);
    if (!sp) return res.status(404).json({ error: 'Service record not found' });
    res.status(204).send();
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
