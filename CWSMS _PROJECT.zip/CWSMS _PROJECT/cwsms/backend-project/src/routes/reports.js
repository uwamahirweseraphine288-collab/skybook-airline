const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');
const ServicePackage = require('../models/ServicePackage');
const Package = require('../models/Package');
const Car = require('../models/Car');
const { requireAuth } = require('../middleware/auth');

// Daily report: PlateNumber, PackageName, PackageDescription, AmountPaid, PaymentDate
router.get('/reports/daily', requireAuth, async (req, res) => {
  try {
    const filter = {};
    if (req.query.date) filter.paymentDate = req.query.date;
    const payments = await Payment.find(filter).sort({ paymentDate: -1 });

    const result = await Promise.all(payments.map(async (p) => {
      let pkg = null;
      if (p.serviceId) {
        const sp = await ServicePackage.findById(p.serviceId);
        if (sp) pkg = await Package.findById(sp.packageId);
      }
      const car = await Car.findOne({ plateNumber: p.plateNumber });
      return {
        plateNumber: p.plateNumber,
        driverName: car?.driverName || '',
        packageName: pkg?.packageName || '',
        packageDescription: pkg?.packageDescription || '',
        amountPaid: p.amountPaid,
        paymentDate: p.paymentDate,
      };
    }));
    res.json(result);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// Summary stats
router.get('/reports/summary', requireAuth, async (req, res) => {
  try {
    const [totalCars, totalPackages, totalServices, paymentAgg] = await Promise.all([
      Car.countDocuments(),
      Package.countDocuments(),
      ServicePackage.countDocuments(),
      Payment.aggregate([{ $group: { _id: null, count: { $sum: 1 }, total: { $sum: '$amountPaid' } } }]),
    ]);
    res.json({
      totalCars,
      totalPackages,
      totalServices,
      totalPayments: paymentAgg[0]?.count || 0,
      totalRevenue: paymentAgg[0]?.total || 0,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
