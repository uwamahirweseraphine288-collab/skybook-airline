// server.js - Complete working version
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/CWSMS')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.log('❌ MongoDB error:', err));

// ========== SCHEMAS ==========
const userSchema = new mongoose.Schema({ 
  username: String, 
  password: String 
});
const User = mongoose.model('User', userSchema);

const employeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  position: { type: String, required: true },
  department: { type: String, required: true },
  salary: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now }
});
const Employee = mongoose.model('Employee', employeeSchema);

const carSchema = new mongoose.Schema({
  plateNumber: String, 
  carType: String, 
  carSize: String, 
  driverName: String, 
  phoneNumber: String
});
const Car = mongoose.model('Car', carSchema);

const packageSchema = new mongoose.Schema({
  packageName: String, 
  packageDescription: String, 
  packagePrice: Number
});
const Package = mongoose.model('Package', packageSchema);

const servicePackageSchema = new mongoose.Schema({
  serviceDate: String, 
  plateNumber: String, 
  driverName: String, 
  packageId: String, 
  packageName: String, 
  packageDescription: String, 
  packagePrice: Number
});
const ServicePackage = mongoose.model('ServicePackage', servicePackageSchema);

const paymentSchema = new mongoose.Schema({
  amountPaid: Number, 
  paymentDate: String, 
  plateNumber: String, 
  driverName: String, 
  packageName: String, 
  packageDescription: String, 
  packagePrice: Number
});
const Payment = mongoose.model('Payment', paymentSchema);

// ========== AUTH ==========
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || user.password !== password) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    res.json({ success: true, user: { id: user._id, username: user.username } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// ========== EMPLOYEE CRUD ==========
// Get all employees
app.get('/api/employees', async (req, res) => {
  try {
    const employees = await Employee.find().sort({ createdAt: -1 });
    console.log(`Sending ${employees.length} employees`);
    res.json(employees);
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});

// Get single employee
app.get('/api/employees/:id', async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json(employee);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
});

// Add employee
app.post('/api/employees', async (req, res) => {
  try {
    const { name, email, position, department, salary } = req.body;
    
    console.log('Received employee data:', req.body);
    
    // Validation
    if (!name || !email || !position || !department || !salary) {
      return res.status(400).json({ error: 'All fields are required' });
    }
    
    // Check if email exists
    const existing = await Employee.findOne({ email });
    if (existing) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    
    const employee = new Employee({
      name,
      email,
      position,
      department,
      salary: Number(salary)
    });
    
    const saved = await employee.save();
    console.log('Employee saved:', saved);
    res.status(201).json(saved);
  } catch (error) {
    console.error('Error adding employee:', error);
    res.status(500).json({ error: 'Failed to add employee' });
  }
});

// Update employee
app.put('/api/employees/:id', async (req, res) => {
  try {
    const { name, email, position, department, salary } = req.body;
    
    const updated = await Employee.findByIdAndUpdate(
      req.params.id,
      { name, email, position, department, salary: Number(salary) },
      { new: true }
    );
    
    if (!updated) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update employee' });
  }
});

// Delete employee
app.delete('/api/employees/:id', async (req, res) => {
  try {
    const deleted = await Employee.findByIdAndDelete(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: 'Employee not found' });
    }
    res.json({ message: 'Employee deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete employee' });
  }
});

// ========== DASHBOARD STATS ==========
app.get('/api/dashboard/stats', async (req, res) => {
  try {
    const employees = await Employee.find();
    const totalEmployees = employees.length;
    const avgSalary = totalEmployees > 0 
      ? employees.reduce((sum, e) => sum + (e.salary || 0), 0) / totalEmployees 
      : 0;
    const departments = [...new Set(employees.map(e => e.department))];
    const recentEmployees = employees.slice(-5);
    
    res.json({
      totalEmployees,
      avgSalary: Math.round(avgSalary),
      totalDepartments: departments.length,
      recentEmployees
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    res.status(500).json({ error: 'Failed to get stats' });
  }
});

// ========== CARS ==========
app.get('/api/cars', async (req, res) => {
  try {
    const cars = await Car.find();
    res.json(cars);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch cars' });
  }
});

app.post('/api/cars', async (req, res) => {
  try {
    const car = new Car(req.body);
    await car.save();
    res.json(car);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add car' });
  }
});

// ========== PACKAGES ==========
app.get('/api/packages', async (req, res) => {
  try {
    const packages = await Package.find();
    res.json(packages);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch packages' });
  }
});

app.post('/api/packages', async (req, res) => {
  try {
    const pkg = new Package(req.body);
    await pkg.save();
    res.json(pkg);
  } catch (error) {
    res.status(500).json({ error: 'Failed to add package' });
  }
});

// ========== SERVICE PACKAGES ==========
app.get('/api/service-packages', async (req, res) => {
  try {
    const records = await ServicePackage.find();
    res.json(records);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch service records' });
  }
});

app.post('/api/service-packages', async (req, res) => {
  try {
    const { serviceDate, plateNumber, packageId } = req.body;
    const car = await Car.findOne({ plateNumber });
    const pkg = await Package.findById(packageId);
    const record = new ServicePackage({
      serviceDate, 
      plateNumber, 
      driverName: car?.driverName,
      packageId, 
      packageName: pkg?.packageName, 
      packageDescription: pkg?.packageDescription, 
      packagePrice: pkg?.packagePrice
    });
    await record.save();
    res.json(record);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create service record' });
  }
});

app.patch('/api/service-packages/:id', async (req, res) => {
  try {
    const { serviceDate, plateNumber, packageId } = req.body;
    const car = await Car.findOne({ plateNumber });
    const pkg = await Package.findById(packageId);
    await ServicePackage.findByIdAndUpdate(req.params.id, {
      serviceDate, 
      plateNumber, 
      driverName: car?.driverName,
      packageId, 
      packageName: pkg?.packageName, 
      packageDescription: pkg?.packageDescription, 
      packagePrice: pkg?.packagePrice
    });
    res.json({ message: 'Updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update' });
  }
});

app.delete('/api/service-packages/:id', async (req, res) => {
  try {
    await ServicePackage.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete' });
  }
});

// ========== PAYMENTS ==========
app.get('/api/payments', async (req, res) => {
  try {
    const payments = await Payment.find();
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch payments' });
  }
});

app.post('/api/payments', async (req, res) => {
  try {
    const { amountPaid, paymentDate, plateNumber, serviceId } = req.body;
    let driverName, packageName, packageDescription, packagePrice;
    
    if (serviceId) {
      const service = await ServicePackage.findById(serviceId);
      driverName = service?.driverName;
      packageName = service?.packageName;
      packageDescription = service?.packageDescription;
      packagePrice = service?.packagePrice;
    } else {
      const car = await Car.findOne({ plateNumber });
      driverName = car?.driverName;
    }
    
    const payment = new Payment({ 
      amountPaid, 
      paymentDate, 
      plateNumber, 
      driverName, 
      packageName, 
      packageDescription, 
      packagePrice 
    });
    await payment.save();
    res.json({ 
      payment, 
      bill: { 
        company: 'CWSMS', 
        location: 'Kigali, Rwanda', 
        receiptNumber: payment._id, 
        driverName, 
        plateNumber, 
        packageName, 
        packageDescription, 
        packagePrice, 
        amountPaid, 
        paymentDate 
      } 
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to record payment' });
  }
});

// ========== REPORTS ==========
app.get('/api/reports/daily', async (req, res) => {
  try {
    const { date } = req.query;
    const filter = date ? { paymentDate: date } : {};
    const payments = await Payment.find(filter);
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch reports' });
  }
});

// ========== INITIALIZE DATABASE ==========
async function init() {
  try {
    // Create admin
    const admin = await User.findOne({ username: 'admin' });
    if (!admin) {
      await User.create({ username: 'admin', password: 'admin123' });
      console.log('✅ Admin created: admin / admin123');
    }
    
    // Create sample employees
    const employeeCount = await Employee.countDocuments();
    if (employeeCount === 0) {
      const sampleEmployees = [
        { name: 'John Doe', email: 'john@example.com', position: 'Manager', department: 'Operations', salary: 75000 },
        { name: 'Jane Smith', email: 'jane@example.com', position: 'Supervisor', department: 'Sales', salary: 55000 },
        { name: 'Bob Wilson', email: 'bob@example.com', position: 'Staff', department: 'Sales', salary: 40000 },
        { name: 'Alice Brown', email: 'alice@example.com', position: 'Cashier', department: 'Front Desk', salary: 35000 },
        { name: 'Charlie Davis', email: 'charlie@example.com', position: 'Technician', department: 'Service', salary: 45000 }
      ];
      await Employee.insertMany(sampleEmployees);
      console.log('✅ Added 5 sample employees');
    }
  } catch (error) {
    console.error('Init error:', error);
  }
}

// ========== START SERVER ==========
const PORT = 5000;
mongoose.connection.once('open', async () => {
  console.log('✅ Database connected');
  await init();
  app.listen(PORT, () => {
    console.log(`\n🚀 Server running on http://localhost:${PORT}`);
    console.log('\n📋 Test the API:');
    console.log(`   GET  http://localhost:${PORT}/api/employees`);
    console.log(`   POST http://localhost:${PORT}/api/auth/login`);
    console.log('\n🔐 Login: admin / admin123\n');
  });
});