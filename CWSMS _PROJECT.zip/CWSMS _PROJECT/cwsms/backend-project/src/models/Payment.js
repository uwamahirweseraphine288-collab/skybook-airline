const mongoose = require('mongoose');
const paymentSchema = new mongoose.Schema({
  amountPaid:   { type: Number, required: true },
  paymentDate:  { type: String, required: true },
  plateNumber:  { type: String, required: true },
  serviceId:    { type: mongoose.Schema.Types.ObjectId, ref: 'ServicePackage' },
}, { timestamps: true });
module.exports = mongoose.model('Payment', paymentSchema);
