const mongoose = require('mongoose');
const packageSchema = new mongoose.Schema({
  packageName:        { type: String, required: true },
  packageDescription: { type: String, required: true },
  packagePrice:       { type: Number, required: true },
}, { timestamps: true });
module.exports = mongoose.model('Package', packageSchema);
