const mongoose = require('mongoose');
const carSchema = new mongoose.Schema({
  plateNumber: { type: String, required: true, unique: true, uppercase: true },
  carType:     { type: String, required: true },
  carSize:     { type: String, required: true, enum: ['Small', 'Medium', 'Large'] },
  driverName:  { type: String, required: true },
  phoneNumber: { type: String, required: true },
}, { timestamps: true });
module.exports = mongoose.model('Car', carSchema);
