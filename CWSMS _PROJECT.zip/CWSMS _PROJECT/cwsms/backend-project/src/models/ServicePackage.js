const mongoose = require('mongoose');
const servicePackageSchema = new mongoose.Schema({
  serviceDate:  { type: String, required: true },
  plateNumber:  { type: String, required: true },
  packageId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Package', required: true },
}, { timestamps: true });
module.exports = mongoose.model('ServicePackage', servicePackageSchema);
