# Human Resource Management System (HRMS)

A full-stack HRMS built with React + Tailwind CSS (Frontend) and Node.js + Express (Backend).

## Features
- Modern UI with Tailwind CSS
- Login Page
- Dashboard with statistics
- Employee Management (CRUD)
- Leave Management
- Payroll System
- Reports & Analytics
- Responsive Design

## Setup

### Backend
```bash
cd backend
npm install
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

**Note**: You may need to install `react-router-dom` in frontend:
```bash
cd frontend
npm install react-router-dom
```

Backend connects to MongoDB (update MONGO_URI in .env).

Happy Coding! 🚀
