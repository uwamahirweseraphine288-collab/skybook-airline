import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState } from 'react';

import Navbar from './components/Navbar';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Employees from './pages/Employees';
import Leave from './pages/Leave';
import Payroll from './pages/Payroll';
import Reports from './pages/Reports';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // LOGOUT FUNCTION
  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">

        <Routes>

          {/* LOGIN ROUTE */}
          <Route
            path="/login"
            element={<Login setIsLoggedIn={setIsLoggedIn} />}
          />

          {/* PROTECTED ROUTES */}
          <Route
            path="/*"
            element={
              isLoggedIn ? (
                <div className="flex">

                  {/* PASS LOGOUT TO NAVBAR */}
                  <Navbar onLogout={handleLogout} />

                  <div className="flex-1 ml-64 p-8">
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/employees" element={<Employees />} />
                      <Route path="/leave" element={<Leave />} />
                      <Route path="/payroll" element={<Payroll />} />
                      <Route path="/reports" element={<Reports />} />
                      <Route path="*" element={<Navigate to="/" />} />
                    </Routes>
                  </div>

                </div>
              ) : (
                <Navigate to="/login" />
              )
            }
          />

        </Routes>
      </div>
    </Router>
  );
}

export default App;