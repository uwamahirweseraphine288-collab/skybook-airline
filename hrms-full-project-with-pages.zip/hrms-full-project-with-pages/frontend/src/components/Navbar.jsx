import { Link, useLocation } from 'react-router-dom';

const Navbar = ({ onLogout }) => {
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: '' },
    { path: '/employees', label: 'Employees', icon: '👥' },
    { path: '/leave', label: 'Leave', icon: '' },
    { path: '/payroll', label: 'Payroll', icon: '' },
    { path: '/reports', label: 'Reports', icon: '' },
  ];

  return (
    <div className="w-64 h-screen fixed bg-gradient-to-b from-white to-gray-50 border-r shadow-lg flex flex-col">

      {/* HEADER */}
      <div className="p-6 border-b bg-white">
        <h1 className="text-3xl font-extrabold text-indigo-600 tracking-wide">
          HRMS
        </h1>
        <p className="text-sm text-gray-500 mt-1">
          SmartTech Ltd
        </p>
      </div>

      {/* NAV LINKS */}
      <div className="flex-1 p-4 space-y-2">

        {navItems.map((item) => {
          const isActive = location.pathname === item.path;

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 relative group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-gray-700 hover:bg-indigo-50 hover:text-indigo-600'
              }`}
            >

              {/* ACTIVE INDICATOR BAR */}
              {isActive && (
                <span className="absolute left-0 top-2 bottom-2 w-1 bg-white rounded-r-full"></span>
              )}

              <span className="text-xl">{item.icon}</span>
              <span className="font-medium">{item.label}</span>

              {/* HOVER EFFECT */}
              {!isActive && (
                <span className="absolute left-0 top-0 w-0 h-full bg-indigo-50 rounded-xl group-hover:w-full transition-all duration-300 -z-10"></span>
              )}

            </Link>
          );
        })}

      </div>

      {/* FOOTER USER PANEL */}
      <div className="p-4 border-t bg-white">

        {/* USER CARD */}
        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl mb-4">
          <div className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold">
            AH
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-800">
              Admin User
            </p>
            <p className="text-xs text-gray-500">
              HR Manager
            </p>
          </div>
        </div>

        {/* LOGOUT BUTTON */}
        <button
          onClick={onLogout}
          className="w-full bg-red-500 hover:bg-red-600 text-white py-2.5 rounded-xl font-medium transition-all shadow-sm"
        >
          Logout
        </button>

      </div>

    </div>
  );
};

export default Navbar;