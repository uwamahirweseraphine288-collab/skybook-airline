import { 
  Users, 
  Calendar, 
  DollarSign, 
  Clock, 
  Activity,
  TrendingUp,
  ChevronRight,
  Bell,
  UserPlus,
  FileText,
  CheckCircle,
  Megaphone,
  Briefcase,
  Award
} from 'lucide-react';

const Dashboard = () => {
  const stats = [
    { 
      title: 'Total Employees', 
      value: '248', 
      change: '+12 this month', 
      trend: '+5.2%',
      icon: Users, 
      color: 'from-slate-600 to-slate-700',
      lightColor: 'bg-slate-800',
      iconColor: 'text-slate-400',
      borderColor: 'border-slate-700'
    },
    { 
      title: 'On Leave Today', 
      value: '18', 
      change: '7.2% of workforce', 
      trend: '-2%',
      icon: Calendar, 
      color: 'from-blue-600 to-blue-700',
      lightColor: 'bg-blue-900/20',
      iconColor: 'text-blue-400',
      borderColor: 'border-blue-800'
    },
    { 
      title: 'Average Salary', 
      value: '$4,892', 
      change: '+2.4% from last month', 
      trend: '+$112',
      icon: DollarSign, 
      color: 'from-emerald-600 to-emerald-700',
      lightColor: 'bg-emerald-900/20',
      iconColor: 'text-emerald-400',
      borderColor: 'border-emerald-800'
    },
    { 
      title: 'Pending Requests', 
      value: '14', 
      change: '4 urgent', 
      trend: '+3',
      icon: Clock, 
      color: 'from-amber-600 to-amber-700',
      lightColor: 'bg-amber-900/20',
      iconColor: 'text-amber-400',
      borderColor: 'border-amber-800'
    },
  ];

  const recentActivities = [
    { user: 'Emily Chen', action: 'submitted timesheet', time: '5 minutes ago', avatar: 'EC', type: 'submission' },
    { user: 'Michael Brown', action: 'requested leave', time: '1 hour ago', avatar: 'MB', type: 'request' },
    { user: 'Sarah Wilson', action: 'updated profile', time: '3 hours ago', avatar: 'SW', type: 'update' },
    { user: 'David Kumar', action: 'completed training', time: '5 hours ago', avatar: 'DK', type: 'completion' },
    { user: 'Lisa Anderson', action: 'joined the team', time: '1 day ago', avatar: 'LA', type: 'join' },
  ];

  const upcomingLeaves = [
    { name: 'Sarah Chen', date: 'May 28', days: 3, type: 'Annual Leave', department: 'Marketing', priority: 'normal' },
    { name: 'Michael Roberts', date: 'May 30', days: 5, type: 'Vacation', department: 'Engineering', priority: 'high' },
    { name: 'Aisha Patel', date: 'June 2', days: 2, type: 'Sick Leave', department: 'Sales', priority: 'urgent' },
    { name: 'James Wilson', date: 'June 5', days: 4, type: 'Annual Leave', department: 'Design', priority: 'normal' },
  ];

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'urgent': return 'bg-red-900/30 text-red-400 border-red-800';
      case 'high': return 'bg-orange-900/30 text-orange-400 border-orange-800';
      default: return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* HEADER SECTION */}
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center shadow-lg">
                  <Briefcase className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl sm:text-3xl font-semibold text-white tracking-tight">
                    Dashboard
                  </h1>
                </div>
              </div>
              <p className="text-slate-400 text-sm ml-13">
                Welcome back, Admin
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-slate-800 px-4 py-2 rounded-lg shadow-sm border border-slate-700">
                <div className="flex items-center gap-2 text-slate-300">
                  <Calendar className="w-4 h-4 text-slate-500" />
                  <span className="text-sm font-medium">{new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
                </div>
              </div>
              <button className="relative bg-slate-800 p-2 rounded-lg shadow-sm border border-slate-700 hover:bg-slate-700 transition-colors">
                <Bell className="w-4 h-4 text-slate-400" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full ring-2 ring-slate-800"></span>
              </button>
            </div>
          </div>

          {/* Quick Stats Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
            {[
              { label: 'Active Today', value: '156', icon: Activity },
              { label: 'New Hires', value: '8', icon: UserPlus },
              { label: 'Birthdays', value: '3', icon: Award },
              { label: 'Anniversaries', value: '5', icon: Award }
            ].map((item, i) => (
              <div key={i} className="bg-slate-800 rounded-lg p-3 shadow-sm border border-slate-700 hover:border-slate-600 transition-colors">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-400 mb-1">{item.label}</p>
                    <p className="text-xl font-semibold text-white">{item.value}</p>
                  </div>
                  <item.icon className="w-4 h-4 text-slate-500" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* STATS CARDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="bg-slate-800 rounded-lg p-5 shadow-sm border border-slate-700 hover:border-slate-600 hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`p-2.5 rounded-lg ${stat.lightColor} bg-opacity-20`}>
                  <stat.icon className={`w-5 h-5 ${stat.iconColor}`} />
                </div>
                <span className="text-xs font-medium text-emerald-400 bg-emerald-900/30 px-2 py-0.5 rounded">
                  {stat.trend}
                </span>
              </div>
              
              <div className="space-y-1">
                <p className="text-slate-400 text-xs font-medium uppercase tracking-wide">{stat.title}</p>
                <p className="text-2xl font-semibold text-white">{stat.value}</p>
                <p className="text-xs text-slate-500">{stat.change}</p>
              </div>
            </div>
          ))}
        </div>

        {/* MAIN CONTENT AREA */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          
          {/* RECENT ACTIVITY - Left Column */}
          <div className="bg-slate-800 rounded-lg shadow-sm border border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-slate-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wide">Recent Activity</h2>
                </div>
                <button className="text-xs text-slate-400 hover:text-slate-300 font-medium flex items-center gap-1 transition-colors">
                  View all <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
            
            <div className="divide-y divide-slate-700">
              {recentActivities.map((activity, i) => (
                <div key={i} className="px-5 py-3 hover:bg-slate-700/50 transition-colors">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-slate-700 rounded-lg flex items-center justify-center text-slate-300 font-medium text-xs">
                      {activity.avatar}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-slate-200">
                        <span className="font-medium">{activity.user}</span>
                        <span className="text-slate-400"> {activity.action}</span>
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <p className="text-xs text-slate-500">{activity.time}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* UPCOMING LEAVES - Right Column */}
          <div className="bg-slate-800 rounded-lg shadow-sm border border-slate-700 overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-700">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  <h2 className="text-sm font-semibold text-white uppercase tracking-wide">Upcoming Leaves</h2>
                </div>
                <span className="text-xs text-slate-400 bg-slate-700 px-2 py-0.5 rounded">
                  {upcomingLeaves.length} pending
                </span>
              </div>
            </div>
            
            <div className="divide-y divide-slate-700">
              {upcomingLeaves.map((leave, i) => (
                <div key={i} className="px-5 py-3 hover:bg-slate-700/50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-slate-700 rounded-lg flex items-center justify-center text-slate-300 font-medium text-xs">
                        {leave.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">{leave.name}</p>
                        <p className="text-xs text-slate-400">{leave.department}</p>
                      </div>
                    </div>
                    <div className={`text-xs font-medium px-2 py-0.5 rounded border ${getPriorityColor(leave.priority)}`}>
                      {leave.priority}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2 ml-11">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-400">{leave.type}</span>
                      <span className="text-xs text-slate-600">•</span>
                      <span className="text-xs text-slate-400">{leave.days} days</span>
                    </div>
                    <div className="text-xs font-medium text-slate-300">
                      {leave.date}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="px-5 py-3 bg-slate-700/30 border-t border-slate-700">
              <button className="w-full text-center text-xs font-medium text-slate-400 hover:text-slate-300 transition-colors">
                Manage Leave Requests →
              </button>
            </div>
          </div>
        </div>

        {/* QUICK ACTIONS SECTION */}
        <div className="bg-slate-800 rounded-lg p-5 shadow-sm border border-slate-700">
          <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3">Quick Actions</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Add Employee', icon: UserPlus },
              { label: 'Generate Report', icon: FileText },
              { label: 'Approve Leaves', icon: CheckCircle },
              { label: 'Send Announcement', icon: Megaphone },
            ].map((action, i) => (
              <button
                key={i}
                className="group flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-700 transition-colors border border-slate-700 hover:border-slate-600"
              >
                <action.icon className="w-4 h-4 text-slate-400 group-hover:text-slate-300" />
                <span className="text-sm text-slate-300 group-hover:text-white">
                  {action.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* FOOTER NOTE */}
        <div className="mt-6 text-center">
          <p className="text-xs text-slate-500">© 2026 SmartTech HRMS. All rights reserved.</p>
        </div>

      </div>
    </div>
  );
};

export default Dashboard;