const Reports = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Reports & Analytics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-8 rounded-3xl">
          <h3 className="font-semibold mb-4">Employee Distribution</h3>
          <div className="h-80 flex items-center justify-center bg-gray-100 rounded-2xl">
            <p className="text-gray-500">📊 Pie Chart - Department Breakdown</p>
          </div>
        </div>
        
        <div className="bg-white p-8 rounded-3xl">
          <h3 className="font-semibold mb-4">Attendance Overview</h3>
          <div className="space-y-8 mt-6">
            <div>
              <div className="flex justify-between mb-2">
                <span>IT Department</span>
                <span className="font-medium">96%</span>
              </div>
              <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-3 bg-indigo-500 rounded-full w-[96%]"></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span>Finance</span>
                <span className="font-medium">89%</span>
              </div>
              <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-3 bg-indigo-500 rounded-full w-[89%]"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
