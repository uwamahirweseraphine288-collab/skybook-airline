import { useEffect, useState } from "react";
import axios from "axios";

function Leave() {

  const [leaves, setLeaves] = useState([]);

  const [formData, setFormData] = useState({
    employeeName: "",
    leaveType: "",
    startDate: "",
    endDate: "",
    reason: ""
  });

  // Fetch Leaves
  const fetchLeaves = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/leaves");
      setLeaves(res.data);

    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchLeaves();
  }, []);

  // Handle Change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Submit Leave
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {

      await axios.post(
        "http://localhost:5000/api/leaves",
        formData
      );

      alert("Leave Added");

      setFormData({
        employeeName: "",
        leaveType: "",
        startDate: "",
        endDate: "",
        reason: ""
      });

      fetchLeaves();

    } catch (error) {
      console.log(error);
    }
  };

  // Delete Leave
  const deleteLeave = async (id) => {
    try {

      await axios.delete(
        `http://localhost:5000/api/leaves/${id}`
      );

      fetchLeaves();

    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">
        Leave Management
      </h1>

      {/* Form */}
      <form
        onSubmit={handleSubmit}
        className="space-y-4 mb-10"
      >

        <input
          type="text"
          name="employeeName"
          placeholder="Employee Name"
          value={formData.employeeName}
          onChange={handleChange}
          className="border p-2 w-full"
        />

        <input
          type="text"
          name="leaveType"
          placeholder="Leave Type"
          value={formData.leaveType}
          onChange={handleChange}
          className="border p-2 w-full"
        />

        <input
          type="date"
          name="startDate"
          value={formData.startDate}
          onChange={handleChange}
          className="border p-2 w-full"
        />

        <input
          type="date"
          name="endDate"
          value={formData.endDate}
          onChange={handleChange}
          className="border p-2 w-full"
        />

        <textarea
          name="reason"
          placeholder="Reason"
          value={formData.reason}
          onChange={handleChange}
          className="border p-2 w-full"
        />

        <button
          type="submit"
          className="bg-green-500 text-white px-4 py-2"
        >
          Add Leave
        </button>

      </form>

      {/* Leave List */}
      <div className="grid gap-4">

        {leaves.map((leave) => (
          <div
            key={leave._id}
            className="border p-4 rounded"
          >

            <h2 className="font-bold">
              {leave.employeeName}
            </h2>

            <p>{leave.leaveType}</p>
            <p>{leave.startDate}</p>
            <p>{leave.endDate}</p>
            <p>{leave.reason}</p>

            <button
              onClick={() => deleteLeave(leave._id)}
              className="bg-red-500 text-white px-3 py-1 mt-3"
            >
              Delete
            </button>

          </div>
        ))}

      </div>
    </div>
  );
}

export default Leave;