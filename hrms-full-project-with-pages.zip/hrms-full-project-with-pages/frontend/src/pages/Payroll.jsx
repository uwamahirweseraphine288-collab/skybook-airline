import { useEffect, useState } from "react";
import axios from "axios";

const Payroll = () => {

  const [payrolls, setPayrolls] = useState([]);

  const [formData, setFormData] = useState({
    employeeName: "",
    department: "",
    basicSalary: "",
    allowances: "",
    deductions: "",
    netPay: ""
  });

  // Fetch Payrolls
  const fetchPayrolls = async () => {
    try {

      const res = await axios.get(
        "http://localhost:5000/api/payrolls"
      );

      setPayrolls(res.data);

    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    fetchPayrolls();
  }, []);

  // Handle Input Change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Submit Payroll
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {

      await axios.post(
        "http://localhost:5000/api/payrolls",
        formData
      );

      alert("Payroll Added");

      setFormData({
        employeeName: "",
        department: "",
        basicSalary: "",
        allowances: "",
        deductions: "",
        netPay: ""
      });

      fetchPayrolls();

    } catch (error) {
      console.log(error);
    }
  };

  // Delete Payroll
  const deletePayroll = async (id) => {
    try {

      await axios.delete(
        `http://localhost:5000/api/payrolls/${id}`
      );

      fetchPayrolls();

    } catch (error) {
      console.log(error);
    }
  };

  return (
   <div>
  {/* Header */}
  <div className="flex justify-between items-center mb-8">
    <div>
      <h3 className="text-3xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
        Payroll Management
      </h3>
      <p className="text-gray-500 mt-1">Manage employee salary and compensation</p>
    </div>
  </div>

  {/* Form */}
  <form
    onSubmit={handleSubmit}
    className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 mb-8 space-y-5"
  >
    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Employee Name
        </label>
        <input
          type="text"
          name="employeeName"
          placeholder="Enter employee name"
          value={formData.employeeName}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Department
        </label>
        <select
          name="department"
          value={formData.department}
          onChange={handleChange}
          className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
        >
          <option value="">Select Department</option>
          <option value="Engineering">Engineering</option>
          <option value="Sales">Sales</option>
          <option value="Marketing">Marketing</option>
          <option value="HR">Human Resources</option>
          <option value="Finance">Finance</option>
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Basic Salary
        </label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
          <input
            type="number"
            name="basicSalary"
            placeholder="0.00"
            value={formData.basicSalary}
            onChange={handleChange}
            className="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Allowances
        </label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
          <input
            type="number"
            name="allowances"
            placeholder="0.00"
            value={formData.allowances}
            onChange={handleChange}
            className="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Deductions
        </label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
          <input
            type="number"
            name="deductions"
            placeholder="0.00"
            value={formData.deductions}
            onChange={handleChange}
            className="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Net Pay
        </label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">$</span>
          <input
            type="number"
            name="netPay"
            placeholder="0.00"
            value={formData.netPay}
            onChange={handleChange}
            className="w-full pl-8 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 bg-gray-50 hover:bg-white"
          />
        </div>
      </div>
    </div>

    <div className="flex gap-3 pt-4">
      <button
        type="submit"
        className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white px-6 py-3 rounded-xl hover:from-indigo-700 hover:to-indigo-800 transition-all duration-200 font-medium shadow-md hover:shadow-lg"
      >
        Add Payroll Record
      </button>
      <button
        type="reset"
        onClick={() => {
          setFormData({
            employeeName: '',
            department: '',
            basicSalary: '',
            allowances: '',
            deductions: '',
            netPay: ''
          });
        }}
        className="bg-gray-100 text-gray-700 px-6 py-3 rounded-xl hover:bg-gray-200 transition-all duration-200 font-medium"
      >
        Clear Form
      </button>
    </div>
  </form>

      {/* Payroll Table */}
      <div className="bg-white rounded-3xl p-8 overflow-x-auto">

        <table className="w-full">

          <thead>
            <tr className="border-b">
              <th className="text-left py-5">Employee</th>
              <th className="text-left py-5">Department</th>
              <th className="text-left py-5">Basic Salary</th>
              <th className="text-left py-5">Allowances</th>
              <th className="text-left py-5">Deductions</th>
              <th className="text-left py-5">Net Pay</th>
              <th className="text-left py-5">Action</th>
            </tr>
          </thead>

          <tbody>

            {payrolls.map((emp) => (

              <tr
                key={emp._id}
                className="border-b hover:bg-gray-50"
              >

                <td className="py-6 font-medium">
                  {emp.employeeName}
                </td>

                <td className="py-6">
                  {emp.department}
                </td>

                <td className="py-6">
                  ${emp.basicSalary}
                </td>

                <td className="py-6 text-emerald-600">
                  +${emp.allowances}
                </td>

                <td className="py-6 text-red-600">
                  -${emp.deductions}
                </td>

                <td className="py-6 font-semibold">
                  ${emp.netPay}
                </td>

                <td className="py-6">

                  <button
                    onClick={() => deletePayroll(emp._id)}
                    className="bg-red-500 text-white px-3 py-1 rounded"
                  >
                    Delete
                  </button>

                </td>

              </tr>

            ))}

          </tbody>

        </table>

      </div>

    </div>
  );
};

export default Payroll;