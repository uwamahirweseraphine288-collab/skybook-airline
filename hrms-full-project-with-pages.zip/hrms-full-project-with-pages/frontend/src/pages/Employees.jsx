import { useEffect, useState } from "react";
import axios from "axios";

function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    position: "",
    department: "",
    salary: "",
  });

  // Fetch Employees
  const fetchEmployees = async () => {
    try {
      setLoading(true);

      const response = await axios.get(
        "http://localhost:5000/api/employees"
      );

      setEmployees(response.data);
    } catch (error) {
      console.log("Fetch Error:", error);

      alert("Failed to fetch employees");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  // Handle Input Change
  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  // Add Employee
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const employeeData = {
        name: formData.name.trim(),
        email: formData.email.trim(),
        position: formData.position.trim(),
        department: formData.department.trim(),
        salary: Number(formData.salary),
      };

      console.log("Sending:", employeeData);

      const response = await axios.post(
        "http://localhost:5000/api/employees",
        employeeData
      );

      console.log("Response:", response.data);

      // Add new employee instantly
      setEmployees((prev) => [...prev, response.data]);

      // Reset Form
      setFormData({
        name: "",
        email: "",
        position: "",
        department: "",
        salary: "",
      });

      alert("Employee Added Successfully");
    } catch (error) {
      console.log("Add Employee Error:", error);

      if (error.response) {
        alert(error.response.data.error || "Server Error");
      } else {
        alert("Cannot connect to backend server");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-6xl mx-auto">
        
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-800">
            Employee Management
          </h1>

          <p className="text-gray-500">
            Manage all employees in your HRMS
          </p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">
            Add New Employee
          </h2>

          <form
            onSubmit={handleSubmit}
            className="grid grid-cols-1 md:grid-cols-2 gap-4"
          >
            <input
              type="text"
              name="name"
              placeholder="Employee Name"
              value={formData.name}
              onChange={handleChange}
              className="border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />

            <input
              type="email"
              name="email"
              placeholder="Employee Email"
              value={formData.email}
              onChange={handleChange}
              className="border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />

            <input
              type="text"
              name="position"
              placeholder="Position"
              value={formData.position}
              onChange={handleChange}
              className="border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />

            <input
              type="text"
              name="department"
              placeholder="Department"
              value={formData.department}
              onChange={handleChange}
              className="border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />

            <input
              type="number"
              name="salary"
              placeholder="Salary"
              value={formData.salary}
              onChange={handleChange}
              className="border p-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />

            <button
              type="submit"
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-3 font-semibold transition"
            >
              {loading ? "Adding..." : "Add Employee"}
            </button>
          </form>
        </div>

        {/* Employee Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="text-xl font-semibold">
              Employees ({employees.length})
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="text-left p-4">Name</th>
                  <th className="text-left p-4">Email</th>
                  <th className="text-left p-4">Position</th>
                  <th className="text-left p-4">Department</th>
                  <th className="text-left p-4">Salary</th>
                </tr>
              </thead>

              <tbody>
                {employees.length > 0 ? (
                  employees.map((employee) => (
                    <tr
                      key={employee._id}
                      className="border-t hover:bg-gray-50"
                    >
                      <td className="p-4">{employee.name}</td>

                      <td className="p-4">{employee.email}</td>

                      <td className="p-4">{employee.position}</td>

                      <td className="p-4">{employee.department}</td>

                      <td className="p-4">
                        $
                        {employee.salary
                          ? employee.salary.toLocaleString()
                          : 0}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan="5"
                      className="text-center p-8 text-gray-500"
                    >
                      No employees found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Employees;