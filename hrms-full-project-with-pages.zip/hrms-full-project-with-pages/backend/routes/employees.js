const express = require("express");
const router = express.Router();

const Employee = require("../models/Employee");

// GET employees
router.get("/", async (req, res) => {
  try {
    const employees = await Employee.find();

    res.json(employees);
  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
});

// ADD employee
router.post("/", async (req, res) => {
  try {
    const employee = new Employee(req.body);

    await employee.save();

    res.status(201).json(employee);
  } catch (error) {
    console.log(error);

    res.status(500).json({
      error: error.message,
    });
  }
});

module.exports = router;