const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
const PORT = 5000;

// ================== MIDDLEWARE ==================

app.use(cors());
app.use(express.json());

// ================== MONGODB CONNECTION ==================

mongoose
  .connect("mongodb://127.0.0.1:27017/hrms")
  .then(() => {
    console.log("✅ MongoDB Connected");
  })
  .catch((err) => {
    console.log("❌ MongoDB Connection Error:", err.message);
  });

/* =====================================================
   EMPLOYEE MODEL + CRUD
===================================================== */

const employeeSchema = new mongoose.Schema(
  {
    name: String,
    email: String,
    position: String,
    department: String,
    salary: Number,
  },
  { timestamps: true }
);

const Employee = mongoose.model("Employee", employeeSchema);

// GET
app.get("/api/employees", async (req, res) => {
  const data = await Employee.find().sort({ createdAt: -1 });
  res.json(data);
});

// CREATE
app.post("/api/employees", async (req, res) => {
  try {
    const employee = new Employee(req.body);
    const saved = await employee.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE
app.put("/api/employees/:id", async (req, res) => {
  const updated = await Employee.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );
  res.json(updated);
});

// DELETE
app.delete("/api/employees/:id", async (req, res) => {
  await Employee.findByIdAndDelete(req.params.id);
  res.json({ message: "Employee deleted" });
});

/* =====================================================
   PAYROLL MODEL + CRUD
===================================================== */

const payrollSchema = new mongoose.Schema(
  {
    employeeName: String,
    basicSalary: Number,
    allowances: Number,
    deductions: Number,
    netSalary: Number,
    month: String,
  },
  { timestamps: true }
);

const Payroll = mongoose.model("Payroll", payrollSchema);

// GET
app.get("/api/payroll", async (req, res) => {
  const data = await Payroll.find().sort({ createdAt: -1 });
  res.json(data);
});

// CREATE
app.post("/api/payroll", async (req, res) => {
  try {
    const { employeeName, basicSalary, allowances, deductions, month } =
      req.body;

    const netSalary =
      Number(basicSalary) +
      Number(allowances || 0) -
      Number(deductions || 0);

    const payroll = new Payroll({
      employeeName,
      basicSalary,
      allowances,
      deductions,
      netSalary,
      month,
    });

    const saved = await payroll.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE
app.put("/api/payroll/:id", async (req, res) => {
  const { employeeName, basicSalary, allowances, deductions, month } =
    req.body;

  const netSalary =
    Number(basicSalary) +
    Number(allowances || 0) -
    Number(deductions || 0);

  const updated = await Payroll.findByIdAndUpdate(
    req.params.id,
    {
      employeeName,
      basicSalary,
      allowances,
      deductions,
      netSalary,
      month,
    },
    { new: true }
  );

  res.json(updated);
});

// DELETE
app.delete("/api/payroll/:id", async (req, res) => {
  await Payroll.findByIdAndDelete(req.params.id);
  res.json({ message: "Payroll deleted" });
});

/* =====================================================
   DASHBOARD STATS
===================================================== */

app.get("/api/dashboard/stats", async (req, res) => {
  const employees = await Employee.find();

  const totalEmployees = employees.length;

  const avgSalary =
    totalEmployees > 0
      ? employees.reduce((sum, emp) => sum + emp.salary, 0) /
        totalEmployees
      : 0;

  const departments = [...new Set(employees.map((e) => e.department))];

  res.json({
    totalEmployees,
    avgSalary: Math.round(avgSalary),
    totalDepartments: departments.length,
    recentEmployees: employees.slice(0, 5),
  });
});

/* =====================================================
   SERVER START
===================================================== */

app.listen(PORT, () => {
  console.log(`🚀 Server Running On Port ${PORT}`);
  console.log("📌 Employees API:");
  console.log("GET / POST / PUT / DELETE /api/employees");

  console.log("📌 Payroll API:");
  console.log("GET / POST / PUT / DELETE /api/payroll");

  console.log("📊 GET /api/dashboard/stats");
});