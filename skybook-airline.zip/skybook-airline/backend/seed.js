const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/skybook';

// Establish schemas inline to avoid dependency path issues
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['passenger', 'admin'], default: 'passenger' },
  createdAt: { type: Date, default: Date.now }
});

const FlightSchema = new mongoose.Schema({
  flightNumber: { type: String, required: true, unique: true },
  airline: { type: String, required: true },
  origin: { type: String, required: true },
  destination: { type: String, required: true },
  departureTime: { type: Date, required: true },
  arrivalTime: { type: Date, required: true },
  price: { type: Number, required: true },
  totalSeats: { type: Number, required: true },
  availableSeats: { type: Number, required: true },
  status: { type: String, enum: ['Scheduled', 'Delayed', 'Cancelled', 'Completed'], default: 'Scheduled' },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Flight = mongoose.model('Flight', FlightSchema);

async function seed() {
  console.log('Connecting to MongoDB...');
  await mongoose.connect(MONGO_URI);
  console.log('Connected. Clearing existing catalogs...');
  
  await User.deleteMany({});
  await Flight.deleteMany({});

  const adminPassword = await bcrypt.hash('adminpassword', 10);
  const passengerPassword = await bcrypt.hash('userpassword', 10);

  // Initialize Admin + Passenger
  await User.create([
    {
      name: 'System Admin',
      email: 'admin@skybook.com',
      password: adminPassword,
      role: 'admin'
    },
    {
      name: 'Charlotte Miller',
      email: 'user@skybook.com',
      password: passengerPassword,
      role: 'passenger'
    }
  ]);
  console.log('Admin & user seeded successfully.');

  // Pre-seed optimal flight schedules
  await Flight.create([
    {
      flightNumber: 'SB-101',
      airline: 'SkyBook Queenliner',
      origin: 'JFK',
      destination: 'LAX',
      departureTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days out
      arrivalTime: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000 + 4 * 60 * 60 * 1000),
      price: 320,
      totalSeats: 150,
      availableSeats: 148,
      status: 'Scheduled'
    },
    {
      flightNumber: 'SB-202',
      airline: 'SkyBook TransAtlantic Jet',
      origin: 'LHR',
      destination: 'DXB',
      departureTime: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000),
      arrivalTime: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000 + 8 * 60 * 60 * 1000),
      price: 680,
      totalSeats: 200,
      availableSeats: 194,
      status: 'Scheduled'
    },
    {
      flightNumber: 'SB-303',
      airline: 'SkyBook Blue Connect',
      origin: 'CDG',
      destination: 'HND',
      departureTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      arrivalTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000 + 11 * 60 * 60 * 1005),
      price: 940,
      totalSeats: 180,
      availableSeats: 180,
      status: 'Delayed'
    },
    {
      flightNumber: 'SB-404',
      airline: 'SkyBook Southern Express',
      origin: 'SIN',
      destination: 'SYD',
      departureTime: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000),
      arrivalTime: new Date(Date.now() + 8 * 24 * 60 * 60 * 1000 + 7 * 60 * 60 * 1000),
      price: 490,
      totalSeats: 160,
      availableSeats: 160,
      status: 'Scheduled'
    }
  ]);
  
  console.log('Aircraft fleet schedules successfully seeded!');
  mongoose.connection.close();
  console.log('Database connection disconnected cleanly.');
}

seed().catch(err => {
  console.error('Seeding halted with failure:', err);
  process.exit(1);
});
