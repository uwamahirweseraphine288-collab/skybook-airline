const express = require('express');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'skybook_super_secret_aeroclock';

app.use(cors());
app.use(express.json());

// ==========================================
// 🗄️ DATABASE MODELS DEFINITIONS
// ==========================================
const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['passenger', 'admin'], default: 'passenger' },
  createdAt: { type: Date, default: Date.now }
});

const FlightSchema = new mongoose.Schema({
  flightNumber: { type: String, required: true, unique: true },
  airline: { type: String, required: true },
  origin: { type: String, required: true },
  destination: { type: String, required: true },
  departureTime: { type: Date, required: true },
  arrivalTime: { type: Date, required: true },
  price: { type: Number, required: true },
  totalSeats: { type: Number, required: true },
  availableSeats: { type: Number, required: true },
  status: { type: String, enum: ['Scheduled', 'Delayed', 'Cancelled', 'Completed'], default: 'Scheduled' },
  createdAt: { type: Date, default: Date.now }
});

const BookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  flight: { type: mongoose.Schema.Types.ObjectId, ref: 'Flight', required: true },
  passengerName: { type: String, required: true },
  passengerAge: { type: Number, required: true },
  passengerPassport: { type: String, required: true },
  seatNumber: { type: String, required: true },
  price: { type: Number, required: true },
  paymentStatus: { type: String, enum: ['Pending', 'Paid'], default: 'Pending' },
  status: { type: String, enum: ['Booked', 'Cancelled'], default: 'Booked' },
  createdAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Flight = mongoose.model('Flight', FlightSchema);
const Booking = mongoose.model('Booking', BookingSchema);

// ==========================================
// 🛡️ SECURITY VERIFICATION MIDDLEWARES
// ==========================================
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required.' });
  }

  const token = authHeader.split(' ')[1];
  jwt.verify(token, JWT_SECRET, (err, verifiedUser) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired session credentials.' });
    }
    req.user = verifiedUser;
    next();
  });
};

const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Access Denied: Supervisor clearance required.' });
  }
  next();
};

// ==========================================
// 👤 SECURITY SESSIONS (REGISTER & LOGIN)
// ==========================================
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email, and password registration details are required.' });
  }

  const normalizedEmail = email.trim().toLowerCase();

  try {
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      return res.status(400).json({ message: 'Email already mapped to an active passenger profile.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const userRole = role === 'admin' ? 'admin' : 'passenger';

    const newUser = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      role: userRole,
    });

    const token = jwt.sign({ id: newUser._id, role: newUser.role }, JWT_SECRET, { expiresIn: '24h' });
    return res.status(211).json({
      token,
      user: { id: newUser._id.toString(), name: newUser.name, email: newUser.email, role: newUser.role }
    });
  } catch (err) {
    res.status(500).json({ message: 'Internal pipeline error registering profile.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Enter both account login email and verification password.' });
  }

  const normalizedEmail = email.trim().toLowerCase();

  try {
    const uRecord = await User.findOne({ email: normalizedEmail });
    if (!uRecord || !(await bcrypt.compare(password, uRecord.password))) {
      return res.status(401).json({ message: 'Invalid verification parameters.' });
    }

    const token = jwt.sign({ id: uRecord._id, role: uRecord.role }, JWT_SECRET, { expiresIn: '24h' });
    return res.json({
      token,
      user: { id: uRecord._id.toString(), name: uRecord.name, email: uRecord.email, role: uRecord.role }
    });
  } catch (err) {
    res.status(500).json({ message: 'Session login authentication failure.' });
  }
});

// ==========================================
// ✈ FLIGHT SCHEDULE DATA SYSTEM endpoints
// ==========================================
app.get('/api/flights', async (req, res) => {
  const { origin, destination } = req.query;
  try {
    let query = {};
    if (origin) query.origin = origin.toUpperCase();
    if (destination) query.destination = destination.toUpperCase();
    
    const list = await Flight.find(query);
    return res.json(list.map(f => ({
      id: f._id.toString(),
      flightNumber: f.flightNumber,
      airline: f.airline,
      origin: f.origin,
      destination: f.destination,
      departureTime: f.departureTime,
      arrivalTime: f.arrivalTime,
      price: f.price,
      totalSeats: f.totalSeats,
      availableSeats: f.availableSeats,
      status: f.status
    })));
  } catch (err) {
    res.status(500).json({ message: 'Directory fetch pipeline interrupted.' });
  }
});

app.post('/api/flights', authenticateJWT, requireAdmin, async (req, res) => {
  const { flightNumber, airline, origin, destination, departureTime, arrivalTime, price, totalSeats } = req.body;

  try {
    const fNum = flightNumber.trim().toUpperCase();
    const existing = await Flight.findOne({ flightNumber: fNum });
    if (existing) return res.status(400).json({ message: 'Flight Code is already schedule listed.' });

    const newFl = await Flight.create({
      flightNumber: fNum,
      airline,
      origin: origin.toUpperCase(),
      destination: destination.toUpperCase(),
      departureTime,
      arrivalTime,
      price,
      totalSeats,
      availableSeats: totalSeats,
      status: 'Scheduled'
    });

    return res.status(201).json(newFl);
  } catch (err) {
    res.status(500).json({ message: 'Failed to record connection schedule.' });
  }
});

app.put('/api/flights/:id', authenticateJWT, requireAdmin, async (req, res) => {
  const { id } = req.params;
  const { flightNumber, airline, origin, destination, departureTime, arrivalTime, price, status } = req.body;

  try {
    const updated = await Flight.findByIdAndUpdate(id, {
      flightNumber,
      airline,
      origin,
      destination,
      departureTime,
      arrivalTime,
      price,
      status
    }, { new: true });
    
    if (!updated) return res.status(404).json({ message: 'Flight resource reference not found.' });
    return res.json(updated);
  } catch {
    res.status(500).json({ message: 'Database amendment script failed.' });
  }
});

app.delete('/api/flights/:id', authenticateJWT, requireAdmin, async (req, res) => {
  const { id } = req.params;
  try {
    const removed = await Flight.findByIdAndDelete(id);
    if (!removed) return res.status(404).json({ message: 'Resource not found' });
    await Booking.deleteMany({ flight: id });
    return res.json({ message: 'Flight schedule connection removed successfully.' });
  } catch {
    res.status(500).json({ message: 'Procedural cancel block.' });
  }
});

// ==========================================
// 🎫 CUSTOMER TICKETS BOOKINGS ENDPOINTS
// ==========================================
app.post('/api/bookings', authenticateJWT, async (req, res) => {
  const { flightId, passengerName, passengerAge, passengerPassport, seatNumber } = req.body;
  const userId = req.user.id;

  try {
    const flObj = await Flight.findById(flightId);
    if (!flObj) return res.status(404).json({ message: 'Flight is not listed.' });
    if (flObj.availableSeats <= 0) return res.status(400).json({ message: 'Flight is sold out.' });

    flObj.availableSeats = Math.max(0, flObj.availableSeats - 1);
    await flObj.save();

    const newBk = await Booking.create({
      user: userId,
      flight: flightId,
      passengerName,
      passengerAge,
      passengerPassport,
      seatNumber,
      price: flObj.price,
      paymentStatus: 'Pending',
      status: 'Booked'
    });

    return res.status(201).json(newBk);
  } catch (err) {
    res.status(500).json({ message: 'Failed to write booking schema.' });
  }
});

app.get('/api/bookings', authenticateJWT, async (req, res) => {
  const userId = req.user.id;
  const isAdmin = req.user.role === 'admin';

  try {
    const query = isAdmin ? {} : { user: userId };
    const bkList = await Booking.find(query)
      .populate('user', 'name email role')
      .populate('flight');
      
    res.json(bkList);
  } catch {
    res.status(500).json({ message: 'Pipeline failure reading booking catalogs.' });
  }
});

app.put('/api/bookings/:id/cancel', authenticateJWT, async (req, res) => {
  const { id } = req.params;
  const userId = req.user.id;
  const isAdmin = req.user.role === 'admin';

  try {
    const bObj = await Booking.findById(id);
    if (!bObj) return res.status(404).json({ message: 'Booking reference not found.' });

    if (!isAdmin && bObj.user.toString() !== userId) {
      return res.status(403).json({ message: 'Access Denied: ID parameters mismatched.' });
    }

    bObj.status = 'Cancelled';
    await bObj.save();

    const flObj = await Flight.findById(bObj.flight);
    if (flObj) {
      flObj.availableSeats = Math.min(flObj.totalSeats, flObj.availableSeats + 1);
      await flObj.save();
    }

    return res.json(bObj);
  } catch {
    res.status(500).json({ message: 'Cancellation script error.' });
  }
});

app.post('/api/bookings/:id/pay', authenticateJWT, async (req, res) => {
  const { id } = req.params;
  try {
    const bObj = await Booking.findById(id);
    if (!bObj) return res.status(404).json({ message: 'Booking not found.' });
    bObj.paymentStatus = 'Paid';
    await bObj.save();
    return res.json(bObj);
  } catch {
    res.status(500).json({ message: 'Checkout transaction error.' });
  }
});

// ==========================================
// 📊 ADMINISTRATIVE STATS API MIDDLEWARES
// ==========================================
app.get('/api/admin/dashboard', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const uCount = await User.countDocuments();
    const bCount = await Booking.countDocuments();
    const paidBookings = await Booking.find({ paymentStatus: 'Paid' });
    const revTotal = paidBookings.reduce((sum, b) => sum + b.price, 0);

    const activeFlightsList = await Flight.find();
    const reports = [];

    for (const flight of activeFlightsList) {
      const flightBookings = await Booking.find({ flight: flight._id, status: 'Booked' });
      const revenue = flightBookings.reduce((sum, b) => sum + b.price, 0);
      const bookedCount = flightBookings.length;
      const occupancy = flight.totalSeats > 0 ? Math.round((bookedCount / flight.totalSeats) * 100) : 0;

      reports.push({
        flightNumber: flight.flightNumber,
        route: `${flight.origin}➔${flight.destination}`,
        occupancy,
        seatsBooked: bookedCount,
        seatsTotal: flight.totalSeats,
        revenue
      });
    }

    return res.json({
      totalUsers: uCount,
      totalBookings: bCount,
      totalRevenue: revTotal,
      flightsReport: reports
    });
  } catch (err) {
    res.status(500).json({ message: 'Stats compiling failed.' });
  }
});

app.get('/api/admin/users', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const list = await User.find({}, { password: 0 });
    return res.json(list);
  } catch {
    res.status(500).json({ message: 'Failed to browse database directory.' });
  }
});

app.get('/api/admin/bookings', authenticateJWT, requireAdmin, async (req, res) => {
  try {
    const bkList = await Booking.find().populate('user', 'name email role').populate('flight');
    res.json(bkList);
  } catch {
    res.status(500).json({ message: 'Database read failed.' });
  }
});

// Activate server connection
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/skybook')
  .then(() => {
    app.listen(PORT, () => {
      console.log(`SkyBook Airline Airline Standalone Backend running on port ${PORT}`);
    });
  })
  .catch(err => {
    console.error('Core MongoDB synchronization failed. Node halted:', err);
  });
