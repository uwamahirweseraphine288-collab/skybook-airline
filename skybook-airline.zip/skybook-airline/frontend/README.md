# ✈️ SkyBook Airline Reservation System - Frontend

This is the lightweight, fast, and feature-rich React frontend application for the **SkyBook Airline Reservation System**, structured using custom standard `.jsx` layouts and powered by Vite and Tailwind CSS.

## 🚀 Quick Start Guide

### 16.1 Dependencies Installation
First, navigate to the `frontend` folder and install all NPM dependencies:
```bash
cd frontend
npm install
```

### 16.2 Environment Settings
Configure your connection to the back-end services. Create a `.env` file in the `frontend` directory by duplicating the template:
```bash
cp .env.example .env
```
Inside `.env`, verify or modify your API gateway domain:
```env
VITE_API_URL=http://localhost:5000
```

### 16.3 Run the Development Server
Bring up the React development workspace locally:
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) inside your browser to start booking flights.

## 🛠️ Main Stack Choices
*   **Vite**: The modern, incredibly fast frontend building tool.
*   **React (v18)**: Single Page Application component layer.
*   **Tailwind CSS**: Rapid UI styling utilizing utility classes.
*   **Lucide React**: Crisp and modern vector SVG icons.
*   **Axios**: Custom API clients with centralized token request interceptors.

## 📁 File Structure
```text
frontend/
├── src/
│   ├── App.jsx         # Single-view fully interactive Application core
│   ├── index.css       # Global styles with Tailwind CSS directives
│   └── main.jsx        # App mounting and entrypoint
├── .env.example        # Environment variable blueprint
├── .gitignore          # Version control directory filters
├── package.json        # Main configuration and workspace boundaries
├── vite.config.js      # Development server proxy filters
└── README.md           # This document
```
