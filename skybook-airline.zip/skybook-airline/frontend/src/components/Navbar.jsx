import React from 'react';
import { Plane, LogOut, User as UserIcon, Calendar, BarChart3, Settings, ShieldAlert, BookOpen } from 'lucide-react';
import { authApi } from '../utils/api.js';

export default function Navbar({ currentUser, onLogout, currentTab, setCurrentTab }) {
  return (
    <header className="sticky top-0 z-50 bg-slate-900 text-white shadow-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentTab('home')}>
            <div className="bg-sky-500 p-2 rounded-xl text-slate-950 shadow-lg shadow-sky-500/20">
              <Plane className="h-6 w-6 transform -rotate-45" />
            </div>
            <div>
              <span className="font-sans font-bold text-xl tracking-tight text-white">
                Sky<span className="text-sky-400">Book</span>
              </span>
              <span className="block text-[9px] font-mono tracking-widest text-sky-300 uppercase leading-none">
                Aviation System
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex space-x-1">
            <button
              onClick={() => setCurrentTab('home')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                currentTab === 'home' || currentTab === 'search-results' || currentTab === 'book'
                  ? 'bg-sky-500/10 text-sky-400 font-semibold'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              Search Flights
            </button>

            {currentUser && currentUser.role === 'passenger' && (
              <button
                onClick={() => setCurrentTab('my-bookings')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'my-bookings' || currentTab === 'payment'
                    ? 'bg-sky-500/10 text-sky-400 font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Calendar className="h-4 w-4" />
                <span>My Bookings</span>
              </button>
            )}

            {currentUser && currentUser.role === 'admin' && (
              <>
                <button
                  onClick={() => setCurrentTab('admin-dashboard')}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    currentTab.startsWith('admin')
                      ? 'bg-sky-500/10 text-sky-400 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <BarChart3 className="h-4 w-4" />
                  <span>Admin Panel</span>
                </button>
              </>
            )}
          </nav>

          {/* Real-time Auth Controls */}
          <div className="flex items-center space-x-3">
            {currentUser ? (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setCurrentTab('profile')}
                  className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800/50 hover:bg-slate-800 transition-all ${
                    currentTab === 'profile' ? 'border-sky-500 ring-2 ring-sky-500/20' : ''
                  }`}
                >
                  <div className="h-6 w-6 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center text-xs font-bold font-mono">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="hidden sm:inline text-xs font-medium text-slate-200">
                    {currentUser.name}
                  </span>
                  {currentUser.role === 'admin' && (
                    <span className="bg-sky-900/50 text-sky-300 text-[10px] uppercase tracking-wider font-semibold px-1 rounded border border-sky-700">
                      Admin
                    </span>
                  )}
                </button>

                <button
                  onClick={onLogout}
                  className="flex items-center space-x-1.5 px-3 py-2 text-slate-400 hover:text-rose-400 text-xs font-medium hover:bg-rose-500/10 rounded-lg transition-colors border border-transparent hover:border-rose-500/20 pointer-events-auto"
                  title="Logout Session"
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden md:inline">Sign Out</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2.5">
                <button
                  onClick={() => setCurrentTab('login')}
                  className="px-4 py-2 text-sm font-medium text-slate-300 hover:text-white transition-colors"
                >
                  Sign In
                </button>
                <button
                  onClick={() => setCurrentTab('register')}
                  className="px-4 py-2 text-sm font-medium bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-lg font-semibold shadow-lg shadow-sky-500/25 transition-all active:scale-95"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
