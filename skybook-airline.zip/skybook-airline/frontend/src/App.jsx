import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar.jsx';
import Home from './pages/Home.jsx';
import SearchResults from './pages/SearchResults.jsx';
import BookFlight from './pages/BookFlight.jsx';
import Payment from './pages/Payment.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import MyBookings from './pages/MyBookings.jsx';
import Profile from './pages/Profile.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import { authApi } from './utils/api.js';
import { Plane, Compass, Heart, AlertCircle } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentTab, setCurrentTab] = useState('home');
  const [searchParams, setSearchParams] = useState(null);
  const [selectedFlight, setSelectedFlight] = useState(null);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    // Read cached login sessions on startup
    const user = authApi.getCurrentUser();
    if (user) {
      setCurrentUser(user);
    }

    // Auto-logout event listener when 401 or 403 authorization failures occur
    const handleAuthError = () => {
      setCurrentUser(null);
      setCurrentTab('login');
    };

    window.addEventListener('skybook_auth_error', handleAuthError);
    return () => {
      window.removeEventListener('skybook_auth_error', handleAuthError);
    };
  }, []);

  const handleLogout = () => {
    authApi.logout();
    setCurrentUser(null);
    setCurrentTab('home');
  };

  const handleSearchTrigger = (params) => {
    setSearchParams(params);
    setCurrentTab('search-results');
  };

  const handleSelectFlightTrigger = (flight) => {
    if (!currentUser) {
      alert("Aviation credentials required. Redirecting you to sign in.");
      setCurrentTab('login');
      return;
    }
    // Strict role guidance: Admins should not book flights under admin permissions
    if (currentUser.role === 'admin') {
      alert("System Administrator profiles are locked out of flight booking. Register a Passenger profile for ticket checkout.");
      return;
    }
    setSelectedFlight(flight);
    setCurrentTab('book');
  };

  const handleBookingSuccessTrigger = (booking) => {
    setSelectedBooking(booking);
    setCurrentTab('payment');
  };

  const handlePaymentSuccessTrigger = () => {
    setRefreshTrigger(prev => prev + 1);
    setCurrentTab('my-bookings');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between">
      {/* Primary header navbar */}
      <Navbar 
          currentUser={currentUser} 
          onLogout={handleLogout} 
          currentTab={currentTab} 
          setCurrentTab={(tab) => {
            // If accessing admin pages, check credentials
            if (tab === 'admin-dashboard' && (!currentUser || currentUser.role !== 'admin')) {
              alert("Access Denied: Administrative credentials required.");
              return;
            }
            if (tab === 'my-bookings' && (!currentUser || currentUser.role !== 'passenger')) {
              alert("Aviation credentials required. Please register or sign in.");
              setCurrentTab('login');
              return;
            }
            setCurrentTab(tab);
          }}
      />

      {/* Main app block container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full">
        {currentTab === 'home' && (
          <Home onSearch={handleSearchTrigger} />
        )}

        {currentTab === 'search-results' && (
          <SearchResults 
            searchParams={searchParams} 
            onSelectFlight={handleSelectFlightTrigger} 
            onBack={() => setCurrentTab('home')} 
          />
        )}

        {currentTab === 'book' && selectedFlight && (
          <BookFlight 
            selectedFlight={selectedFlight} 
            onBookingSuccess={handleBookingSuccessTrigger} 
            onBack={() => setCurrentTab('search-results')} 
          />
        )}

        {currentTab === 'payment' && selectedBooking && (
          <Payment 
            booking={selectedBooking} 
            onPaymentSuccess={handlePaymentSuccessTrigger} 
            onBack={() => setCurrentTab('my-bookings')} 
          />
        )}

        {currentTab === 'login' && (
          <Login 
            onLoginSuccess={(usr) => {
              setCurrentUser(usr);
              setCurrentTab(usr.role === 'admin' ? 'admin-dashboard' : 'home');
            }} 
            onNavigateToRegister={() => setCurrentTab('register')} 
          />
        )}

        {currentTab === 'register' && (
          <Register 
            onRegisterSuccess={(usr) => {
              setCurrentUser(usr);
              setCurrentTab(usr.role === 'admin' ? 'admin-dashboard' : 'home');
            }} 
            onNavigateToLogin={() => setCurrentTab('login')} 
          />
        )}

        {currentTab === 'my-bookings' && (
          <MyBookings 
            onPayForBooking={(b) => {
              setSelectedBooking(b);
              setCurrentTab('payment');
            }}
            onRefreshTrigger={refreshTrigger}
          />
        )}

        {currentTab === 'profile' && currentUser && (
          <Profile currentUser={currentUser} />
        )}

        {currentTab === 'admin-dashboard' && (
          <AdminDashboard 
            onRefreshTrigger={() => setRefreshTrigger(prev => prev + 1)} 
          />
        )}
      </main>

      {/* Business aerospace footer display */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 py-12 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
            
            {/* Column 1: Fleet specifications */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Plane className="h-5 w-5 text-sky-400 transform -rotate-45" />
                <span className="font-sans font-bold text-base text-white tracking-tight">
                  SkyBook Airline
                </span>
              </div>
              <p className="text-slate-500 leading-relaxed max-w-xs font-normal">
                Connecting passengers to elite flight decks globally. Operating direct, safe non-stop schedules safely inside international aviation standards.
              </p>
            </div>

            {/* Column 2: Escrows disclosures */}
            <div className="space-y-3 font-normal">
              <span className="block text-[10px] uppercase font-bold text-slate-300 tracking-wider font-sans">
                🔒 Escrows Disclosure
              </span>
              <p className="text-slate-500 leading-normal">
                All mock credit card and passport details submitted are processed inside sandbox storage states, adhering to certified test safety regulations.
              </p>
            </div>

            {/* Column 3: Telemetry metrics */}
            <div className="space-y-3 font-normal text-slate-500">
              <span className="block text-[10px] uppercase font-bold text-slate-300 tracking-wider font-mono">
                🛰 Avionics Status
              </span>
              <div className="space-y-1 font-mono">
                <div className="flex justify-between">
                  <span>Server Node Status:</span>
                  <span className="text-sky-400 font-bold">ONLINE</span>
                </div>
                <div className="flex justify-between">
                  <span>Secure Escrows:</span>
                  <span className="text-sky-400 font-bold">READY</span>
                </div>
                <div className="flex justify-between">
                  <span>UTC Avionics Clock:</span>
                  <span className="font-semibold text-slate-300">2026-05-29 UTC</span>
                </div>
              </div>
            </div>

          </div>

          <div className="border-t border-slate-800 pt-6 mt-8 text-center flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-600">
            <span className="font-semibold text-[11px]">
              &copy; 2026 SkyBook Aviation Reservation Networks. All passenger rights reserved.
            </span>
            <div className="flex items-center gap-1">
              <span>Made with love for aviation schedules</span>
              <Heart className="h-3.5 w-3.5 fill-rose-600/20 text-rose-500" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
