import React, { useState } from 'react';
import { Mail, Lock, ShieldAlert, ArrowRight, UserCheck, Plane } from 'lucide-react';
import { authApi } from '../utils/api.js';
import { motion } from 'motion/react';

export default function Login({ onLoginSuccess, onNavigateToRegister }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorL, setErrorL] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorL('Please provide both registration email and password credentials.');
      return;
    }
    setErrorL('');
    setLoading(true);
    try {
      const data = await authApi.login(email.trim(), password);
      onLoginSuccess(data.user);
    } catch (err) {
      console.error(err);
      setErrorL(err.response?.data?.message || 'Login failed. Invalid account credentials.');
    } finally {
      setLoading(false);
    }
  };

  // Quick tests credentials autofillers
  const prefill = (role) => {
    if (role === 'admin') {
      setEmail('admin@skybook.com');
      setPassword('adminpassword');
    } else {
      setEmail('user@skybook.com');
      setPassword('userpassword');
    }
  };

  return (
    <div className="max-w-md mx-auto my-12">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl shadow-slate-100/50 space-y-6"
      >
        {/* Brand header */}
        <div className="text-center space-y-2">
          <div className="mx-auto bg-sky-500 text-slate-950 p-2.5 rounded-xl w-fit shadow-md">
            <Plane className="h-5 w-5 transform -rotate-45" />
          </div>
          <h2 className="text-xl font-bold font-sans text-slate-900">Sign In to SkyBook</h2>
          <p className="text-xs text-slate-400">Unlock scheduling, direct flight listings, and ticketing alerts.</p>
        </div>

        {errorL && (
          <div className="bg-rose-50 border border-rose-100 text-rose-700 text-xs p-3.5 rounded-xl flex items-start gap-2.5">
            <ShieldAlert className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
            <p className="leading-relaxed">{errorL}</p>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          {/* Email input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="passenger@skybook.com"
                className="block w-full pl-9 pr-3 py-2 text-sm bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-909 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          {/* Password input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
                Access Password
              </label>
            </div>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Lock className="h-4 w-4" />
              </span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="block w-full pl-9 pr-3 py-2 text-sm bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-909 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-slate-900 hover:bg-slate-805 text-white font-bold py-2.5 rounded-xl text-sm transition-all shadow shadow-slate-900/10 hover:shadow-lg hover:shadow-slate-900/10 font-sans active:scale-[0.98] inline-flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>{loading ? 'Authenticating Credentials...' : 'Sign In'}</span>
            {!loading && <ArrowRight className="h-3.5 w-3.5" />}
          </button>
        </form>

        {/* Quick Testing Badges */}
        <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-xl space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-slate-500 flex items-center gap-1">
              <UserCheck className="h-3.5 w-3.5 text-sky-500" />
              <span>Developer Quick Autologin</span>
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 font-sans font-semibold">
            <button
              onClick={() => prefill('passenger')}
              className="px-2.5 py-1.5 text-[11px] text-slate-700 bg-white border border-slate-200 rounded-lg hover:border-sky-400 transition-colors flex items-center justify-center gap-1 shadow-sm active:bg-slate-55 cursor-pointer"
            >
              <span>👤 Passenger Account</span>
            </button>
            <button
              onClick={() => prefill('admin')}
              className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:border-sky-400 transition-colors flex items-center justify-center gap-1 shadow-sm active:bg-slate-55 cursor-pointer"
            >
              <span>🔑 Admin Console</span>
            </button>
          </div>
        </div>

        {/* Action Toggle */}
        <div className="border-t border-slate-100 pt-4 text-center">
          <p className="text-xs text-slate-500">
            Don't have an aviation registration?{' '}
            <button
              onClick={onNavigateToRegister}
              className="font-semibold text-sky-600 hover:text-sky-700 hover:underline inline-flex items-center gap-0.5 cursor-pointer"
            >
              Register Here
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
