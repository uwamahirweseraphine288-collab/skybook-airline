import React, { useState, useEffect } from 'react';
import { authApi, bookingsApi } from '../utils/api.js';
import { UserCheck, ShieldCheck, Mail, Calendar, Eye, Activity, Award } from 'lucide-react';
import { motion } from 'motion/react';

export default function Profile({ currentUser }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const list = await bookingsApi.getMyBookings();
        setBookings(list);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    if (currentUser.role === 'passenger') {
      loadStats();
    } else {
      setLoading(false);
    }
  }, [currentUser]);

  // Derive simple facts
  const bookingCount = bookings.filter(b => b.status === 'Booked').length;
  const historyCount = bookings.length;
  const preferredTier = bookingCount >= 3 ? 'Elite Gold Platinum' : bookingCount >= 1 ? 'Frequent Flyer Silver' : 'Standard Guest Pass';

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-20 font-sans">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-xl font-bold text-slate-905">My Passenger Profile</h1>
        <p className="text-xs text-slate-500 font-medium">Verify credentials, browse travel tiers, and review security escrow parameters.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-stretch">
        {/* Left Card: Main identity */}
        <div className="md:col-span-5 bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-sky-500" />
          
          <div className="space-y-4">
            <div className="h-16 w-16 bg-sky-100/80 text-sky-700 font-extrabold text-2xl mx-auto rounded-full flex items-center justify-center font-mono">
              {currentUser.name.charAt(0).toUpperCase()}
            </div>

            <div>
              <h2 className="text-lg font-bold text-slate-800">{currentUser.name}</h2>
              <p className="text-xs text-slate-400 font-mono mt-0.5 uppercase tracking-wider font-semibold">{currentUser.role.toUpperCase()} PROFILE</p>
            </div>

            <div className="inline-flex items-center space-x-1.5 bg-sky-50 text-sky-800 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase font-mono border border-sky-100">
              <Award className="h-3 w-3" />
              <span>{preferredTier}</span>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-4 mt-6 text-left space-y-2.5 text-xs text-slate-500 font-normal">
            <div className="flex items-center space-x-2">
              <Mail className="h-4 w-4 text-slate-400 shrink-0" />
              <span className="font-medium truncate">{currentUser.email}</span>
            </div>
            <div className="flex items-center space-x-2 text-slate-600">
              <UserCheck className="h-4 w-4 text-slate-400 shrink-0" />
              <span className="font-medium">ID Verified Credentials</span>
            </div>
          </div>
        </div>

        {/* Right Card: Statistics and rules */}
        <div className="md:col-span-7 bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <span className="block border-b border-slate-100 pb-2 text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">
              ✈ Airline Mileage Tallies
            </span>

            {currentUser.role === 'passenger' ? (
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl text-center">
                  <span className="block text-[10px] uppercase text-slate-400 font-mono font-bold">Flights Confirmed</span>
                  <span className="text-3xl font-black text-slate-900 font-sans mt-1 block font-mono">
                    {loading ? '...' : bookingCount}
                  </span>
                </div>
                <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl text-center">
                  <span className="block text-[10px] uppercase text-slate-400 font-mono font-bold">Life-Time Logged</span>
                  <span className="text-3xl font-black text-slate-900 font-sans mt-1 block font-mono">
                    {loading ? '...' : historyCount}
                  </span>
                </div>
              </div>
            ) : (
              <div className="bg-slate-50 border border-slate-150 p-4 rounded-xl text-center">
                <span className="block text-xs text-slate-500 font-medium font-normal">Administrator privileges are active. Flights are fully managed on the Admin Panel page.</span>
              </div>
            )}
          </div>

          {/* Secure Trust Stamp */}
          <div className="bg-sky-50 border border-sky-100 p-4 rounded-xl flex items-start space-x-3.5">
            <ShieldCheck className="h-6 w-6 text-sky-600 shrink-0 mt-0.5" />
            <div>
              <span className="block text-xs font-bold text-sky-950 uppercase tracking-wider font-mono">
                Verified Identity Guard
              </span>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed font-normal">
                SkyBook holds ISO 27001 data safety certificates. Passport numbers are protected inside transit escrows, and session keys automatically terminate every 24 hours.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
