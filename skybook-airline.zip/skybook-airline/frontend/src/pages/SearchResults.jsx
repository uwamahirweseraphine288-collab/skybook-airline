import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, ShieldCheck, Filter, Plane, ArrowRight, CornerDownRight } from 'lucide-react';
import { flightsApi } from '../utils/api.js';
import { motion } from 'motion/react';

export default function SearchResults({ searchParams, onSelectFlight, onBack }) {
  const [flights, setFlights] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errorFl, setErrorFl] = useState('');

  // Filtering criteria
  const [maxPrice, setMaxPrice] = useState(2000);
  const [selectedAirline, setSelectedAirline] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  useEffect(() => {
    async function fetchFlights() {
      setLoading(true);
      setErrorFl('');
      try {
        const queryParams = searchParams ? {
          origin: searchParams.origin,
          destination: searchParams.destination,
          date: searchParams.date
        } : undefined;

        const data = await flightsApi.getAll(queryParams);
        setFlights(data);
        
        // Dynamically set absolute max price filter if flights exist
        if (data.length > 0) {
          const max = Math.max(...data.map(f => f.price));
          setMaxPrice(max);
        }
      } catch (err) {
        console.error("Failed to load flights:", err);
        setErrorFl("Encountered connection difficulties searching flights. Displaying complete flight listings.");
        // Fallback: list all flights
        try {
          const data = await flightsApi.getAll();
          setFlights(data);
        } catch {}
      } finally {
        setLoading(false);
      }
    }

    fetchFlights();
  }, [searchParams]);

  // Derive list of unique airlines for filtering drop-down elements
  const airlines = ['all', ...Array.from(new Set(flights.map(f => f.airline)))];

  // Apply visual and price filters
  const filteredFlights = flights.filter(f => {
    const matchPrice = f.price <= maxPrice;
    const matchAirline = selectedAirline === 'all' || f.airline === selectedAirline;
    const matchStatus = selectedStatus === 'all' || f.status === selectedStatus;
    return matchPrice && matchAirline && matchStatus;
  });

  const formatTime = (isoString) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' - ' + d.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Header and Back controller */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors border border-slate-200"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-xl font-bold font-sans text-slate-900 flex items-center gap-2">
              <span>Flight Options Found</span>
              <span className="text-xs bg-sky-100 text-sky-800 font-mono py-0.5 px-2 rounded-full font-bold">
                {filteredFlights.length} Available
              </span>
            </h1>
            {searchParams ? (
              <p className="text-xs text-slate-500 font-medium font-mono mt-0.5 uppercase tracking-wider flex items-center gap-1.5">
                <span>{searchParams.origin}</span>
                <ArrowRight className="h-3 w-3 stroke-[3]" />
                <span>{searchParams.destination}</span>
                <span className="text-slate-300">|</span>
                <span>{searchParams.date}</span>
              </p>
            ) : (
              <p className="text-xs text-slate-500">Displaying complete flight connections catalog.</p>
            )}
          </div>
        </div>
      </div>

      {/* Grid container for filters and listings */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Filter Toolbar Card Sidebar */}
        <div className="lg:col-span-1 bg-white p-5 rounded-xl border border-slate-200 h-fit space-y-6 shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <span className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
              <Filter className="h-4 w-4 text-sky-500" />
              <span>Filter Catalog</span>
            </span>
            <button 
              onClick={() => {
                setSelectedAirline('all');
                setSelectedStatus('all');
                if (flights.length > 0) setMaxPrice(Math.max(...flights.map(f => f.price)));
              }}
              className="text-[10px] text-sky-500 hover:text-sky-600 font-bold uppercase tracking-wider"
            >
              Reset All
            </button>
          </div>

          {/* Pricing slider */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Maximum Fare: <span className="text-sky-600 font-extrabold text-sm ml-1">${maxPrice}</span>
            </label>
            <input 
              type="range"
              min={100}
              max={2500}
              step={50}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg appearance-none"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-400">
              <span>$100</span>
              <span>$2500</span>
            </div>
          </div>

          {/* Airline Selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Airline Provider
            </label>
            <select
              value={selectedAirline}
              onChange={(e) => setSelectedAirline(e.target.value)}
              className="block w-full rounded-lg border border-slate-200 py-1.5 px-2 text-xs font-medium text-slate-700 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white"
            >
              {airlines.map(air => (
                <option key={`air-opt-${air}`} value={air}>
                  {air === 'all' ? 'All Providers Available' : air}
                </option>
              ))}
            </select>
          </div>

          {/* Flight Status Select */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Flight Status
            </label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="block w-full rounded-lg border border-slate-200 py-1.5 px-2 text-xs font-medium text-slate-700 bg-slate-50/50 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white"
            >
              <option value="all">All Flight Conditions</option>
              <option value="Scheduled">Scheduled</option>
              <option value="Delayed">Delayed</option>
              <option value="Cancelled">Cancelled</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          {/* Secure Trust Stamp */}
          <div className="bg-sky-50/50 border border-sky-100 p-3 rounded-lg flex items-start gap-2.5">
            <ShieldCheck className="h-5 w-5 text-sky-600 mt-0.5 shrink-0" />
            <div>
              <span className="block text-[10px] font-bold text-sky-950 uppercase tracking-widest leading-none mb-1 font-mono">
                Verified Provider
              </span>
              <p className="text-[10px] text-slate-500 leading-normal">
                All pricing contains taxes, baggage weights, and airline insurance protocols. No hidden additions.
              </p>
            </div>
          </div>
        </div>

        {/* Flight Listings Panel */}
        <div className="lg:col-span-3 space-y-4">
          {loading ? (
            <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-4 shadow-sm">
              <div className="animate-spin inline-block h-8 w-8 border-4 border-sky-500 border-t-transparent rounded-full" />
              <p className="text-slate-500 text-sm font-medium">Scanning optimal airline connections for your schedule...</p>
            </div>
          ) : errorFl && filteredFlights.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-3 shadow-sm">
              <Plane className="h-10 w-10 text-slate-300 mx-auto transform -rotate-45" />
              <p className="text-slate-800 text-sm font-bold">No Connecting Flights Available</p>
              <p className="text-slate-500 text-xs max-w-sm mx-auto leading-relaxed">
                We did not find any matching flight listings currently scheduled. Change search parameters or click "Reset All" filters.
              </p>
            </div>
          ) : filteredFlights.length === 0 ? (
            <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-3 shadow-sm">
              <Plane className="h-10 w-10 text-slate-300 mx-auto transform -rotate-45" />
              <p className="text-slate-800 text-sm font-bold">No Flights Match Current Filters</p>
              <p className="text-slate-500 text-xs max-w-sm mx-auto leading-relaxed">
                Try adjusting the price slider or selecting another airline provider.
              </p>
            </div>
          ) : (
            filteredFlights.map((flight, index) => {
              const depTime = formatTime(flight.departureTime);
              const arrTime = formatTime(flight.arrivalTime);
              
              return (
                <motion.div
                  key={flight.id || flight._id || `flight-item-${index}`}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: (index % 5) * 0.05 }}
                  className="bg-white rounded-xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6 hover:border-slate-300 relative group"
                >
                  {/* Left: General Flight specs */}
                  <div className="flex-1 space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="bg-slate-100 p-2 rounded-lg text-slate-700">
                        <Plane className="h-4 w-4 transform -rotate-45 text-sky-600" />
                      </div>
                      <div>
                        <span className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider">
                          {flight.flightNumber}
                        </span>
                        <h3 className="text-sm font-bold text-slate-800 font-sans">
                          {flight.airline}
                        </h3>
                      </div>

                      {/* Status Badging */}
                      <span className={`text-[10px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                        flight.status === 'Scheduled' ? 'bg-sky-50 text-sky-700 border-sky-200' :
                        flight.status === 'Delayed' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                        flight.status === 'Cancelled' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                        'bg-emerald-50 text-emerald-700 border-emerald-200'
                      }`}>
                        {flight.status}
                      </span>
                    </div>

                    {/* Timeline connection overview */}
                    <div className="grid grid-cols-11 items-center max-w-xl">
                      {/* Origin Airport */}
                      <div className="col-span-4">
                        <span className="block text-lg font-extrabold text-slate-900 leading-none">
                          {flight.origin}
                        </span>
                        <span className="block text-[11px] text-slate-500 font-mono mt-1">
                          {depTime}
                        </span>
                      </div>

                      {/* Arrow divider */}
                      <div className="col-span-3 flex flex-col items-center justify-center text-center px-1">
                        <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-wider mb-1">
                          Non-Stop
                        </span>
                        <div className="w-full h-0.5 bg-slate-200 relative">
                          <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-sky-500" />
                        </div>
                        <span className="text-[8px] font-mono text-slate-400 mt-1 flex items-center justify-center gap-0.5">
                          <Clock className="h-2.5 w-2.5 text-slate-400" />
                          <span>Direct</span>
                        </span>
                      </div>

                      {/* Destination Airport */}
                      <div className="col-span-4 text-right">
                        <span className="block text-lg font-extrabold text-slate-900 leading-none">
                          {flight.destination}
                        </span>
                        <span className="block text-[11px] text-slate-500 font-mono mt-1">
                          {arrTime}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Booking actions & pricing */}
                  <div className="flex flex-row md:flex-col justify-between md:justify-center items-center md:items-end border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6 shrink-0 gap-4">
                    <div className="text-left md:text-right">
                      <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                        Per Passenger
                      </span>
                      <span className="text-2xl font-black font-sans text-slate-900">
                        ${flight.price}
                      </span>
                      <div className="flex items-center gap-1.5 mt-0.5 font-mono text-[10px]">
                        <span className="font-extrabold text-emerald-600">
                          {flight.availableSeats}
                        </span>
                        <span className="text-slate-400">/ {flight.totalSeats} Cabin Seats</span>
                      </div>
                    </div>

                    <button
                      onClick={() => onSelectFlight(flight)}
                      disabled={flight.availableSeats <= 0 || flight.status === 'Cancelled'}
                      className={`font-sans font-bold text-xs px-5 py-2.5 rounded-lg shadow-sm transition-all pointer-events-auto ${
                        flight.availableSeats <= 0 || flight.status === 'Cancelled'
                          ? 'bg-slate-100 text-slate-400 border border-slate-250 cursor-not-allowed'
                          : 'bg-slate-900 hover:bg-slate-800 text-white hover:shadow group-hover:bg-sky-500 group-hover:text-slate-950 group-hover:shadow-sky-500/10'
                      }`}
                    >
                      {flight.status === 'Cancelled' ? 'Cancelled' : flight.availableSeats <= 0 ? 'Sold Out' : 'Select Seat ✈'}
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
