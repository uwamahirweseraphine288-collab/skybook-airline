import React, { useState } from 'react';
import { bookingsApi } from '../utils/api.js';
import { ArrowLeft, CreditCard, ShieldAlert, CheckCircle, Ticket, Download } from 'lucide-react';
import { motion } from 'motion/react';

export default function Payment({ booking, onPaymentSuccess, onBack }) {
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [errorP, setErrorP] = useState('');
  const [success, setSuccess] = useState(false);

  const flight = typeof booking.flight === 'object' ? booking.flight : null;

  const handleCardNumberChange = (e) => {
    const val = e.target.value.replace(/\D/g, '');
    const formatted = val.match(/.{1,4}/g)?.join(' ') || val;
    setCardNumber(formatted.slice(0, 19));
  };

  const handleExpiryChange = (e) => {
    const val = e.target.value.replace(/\D/g, '');
    let formatted = val;
    if (val.length > 2) {
      formatted = `${val.slice(0, 2)}/${val.slice(2, 4)}`;
    }
    setExpiry(formatted.slice(0, 5));
  };

  const handlePay = async (e) => {
    e.preventDefault();
    if (!cardNumber || cardHolder.trim().length === 0 || !expiry || !cvv) {
      setErrorP('Please fill out all visual billing credit card inputs.');
      return;
    }
    if (cardNumber.replace(/\s/g, '').length < 16) {
      setErrorP('Credit card number must contain exactly 16 registration digits.');
      return;
    }
    setErrorP('');
    setLoading(true);
    try {
      await bookingsApi.pay(booking.id, {
        cardNumber: cardNumber.replace(/\s/g, ''),
        cardHolder: cardHolder.trim(),
        expiry,
        cvv
      });
      setSuccess(true);
    } catch (err) {
      console.error(err);
      setErrorP(err.response?.data?.message || 'Payment simulation did not write success. Retrying.');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="max-w-md mx-auto my-12 text-center space-y-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4 }}
          className="bg-white p-8 rounded-2xl border border-slate-205 shadow-xl space-y-6"
        >
          <div className="h-14 w-14 bg-emerald-105 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10">
            <CheckCircle className="h-8 w-8 stroke-[2.5]" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-bold font-sans text-slate-900">Payment Processed Successfully</h1>
            <p className="text-slate-500 text-sm">Your ticket is fully issued and seat assignment locked.</p>
          </div>

          <div className="border border-dashed border-slate-200 bg-slate-50 p-4 rounded-xl text-left space-y-2 font-mono text-xs">
            <h4 className="font-bold border-b border-slate-100 pb-2 text-slate-705">SKYBOOK ELECTRONIC RECEIPT</h4>
            <div className="flex justify-between text-slate-500">
              <span>Booking Ref:</span>
              <span className="font-bold text-slate-800">{booking.id?.substring(0, 8).toUpperCase()}</span>
            </div>
            {flight && (
              <>
                <div className="flex justify-between text-slate-500">
                  <span>Flight Code:</span>
                  <span className="font-bold text-slate-800">{flight.flightNumber}</span>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>Route:</span>
                  <span className="font-bold text-slate-800">{flight.origin} ➔ {flight.destination}</span>
                </div>
              </>
            )}
            <div className="flex justify-between text-slate-500">
              <span>Seating:</span>
              <span className="font-bold text-slate-800 font-mono">Seat {booking.seatNumber}</span>
            </div>
            <div className="border-t border-slate-100 pt-2 flex justify-between text-slate-900 font-extrabold text-sm">
              <span>Charged Total:</span>
              <span>${booking.price}</span>
            </div>
          </div>

          <button
            onClick={onPaymentSuccess}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer font-sans"
          >
            <Ticket className="h-4 w-4" />
            <span>Go to My Bookings</span>
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 max-w-4xl mx-auto">
      <div className="flex items-center space-x-3 border-b border-slate-200 pb-4">
        <button
          onClick={onBack}
          className="p-2 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors border border-slate-200"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h1 className="text-xl font-bold font-sans text-slate-900">Flight Checkout Portal</h1>
          <p className="text-xs text-slate-500">Authenticate payment on reservation hold. Funds are securely locked inside SkyBook escrows.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        {/* Dynamic credit card mockup and form */}
        <div className="md:col-span-7 bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
          <span className="block border-b border-slate-100 pb-3 text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">
            💳 Credit/Debit Card Details
          </span>

          {errorP && (
            <div className="bg-rose-50 border border-rose-100 text-rose-750 text-xs p-3.5 rounded-xl flex items-start gap-2.5 animate-pulse">
              <ShieldAlert className="h-4.5 w-4.5 text-rose-500 mt-0.5 shrink-0" />
              <p className="leading-relaxed">{errorP}</p>
            </div>
          )}

          <form onSubmit={handlePay} className="space-y-4">
            {/* Cardholder Name input */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
                Cardholder Name
              </label>
              <input
                type="text"
                required
                value={cardHolder}
                onChange={(e) => setCardHolder(e.target.value)}
                placeholder="CHARLOTTE MILLER"
                className="block w-full px-3 py-2 text-sm bg-slate-50/50 border border-slate-205 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white uppercase tracking-wider font-mono font-medium"
              />
            </div>

            {/* Card digits */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
                Card Number
              </label>
              <input
                type="text"
                required
                value={cardNumber}
                onChange={handleCardNumberChange}
                placeholder="4000 1234 5678 9010"
                className="block w-full px-3 py-2 text-sm bg-slate-50/50 border border-slate-205 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white font-mono tracking-widest font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {/* Expiry */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
                  Expiry Date
                </label>
                <input
                  type="text"
                  required
                  placeholder="MM/YY"
                  value={expiry}
                  onChange={handleExpiryChange}
                  className="block w-full px-3 py-2 text-sm bg-slate-50/50 border border-slate-205 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white font-mono text-center font-medium"
                />
              </div>

              {/* CVV */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
                  CVV Code
                </label>
                <input
                  type="password"
                  required
                  maxLength={3}
                  placeholder="•••"
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
                  className="block w-full px-3 py-2 text-sm bg-slate-50/50 border border-slate-205 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white font-mono text-center font-medium"
                />
              </div>
            </div>

            {/* Simulated Payment note */}
            <p className="text-[10px] text-slate-400 leading-normal">
              💳 This uses a mock financial engine. No actual credit transactions occur. Safe to click simulate.
            </p>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-400 text-white font-bold py-2.5 rounded-xl text-xs transition-colors shadow shadow-slate-900/10 active:scale-95 font-sans flex items-center justify-center gap-1 cursor-pointer"
            >
              <span>{loading ? 'Authorizing Transactions...' : `Submit Payment Simulation • $${booking.price}`}</span>
            </button>
          </form>
        </div>

        {/* Right Side: Virtual credit card and pricing table */}
        <div className="md:col-span-5 space-y-6">
          
          {/* Card Mockup Graphic */}
          <div className="relative h-44 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 shadow-xl border border-slate-850 flex flex-col justify-between overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(14,165,233,0.15),transparent_60%)]" />
            
            {/* Design header */}
            <div className="flex items-center justify-between relative z-10">
              <span className="text-xs uppercase tracking-widest font-mono font-extrabold text-sky-400">
                SkyBook Titanium
              </span>
              <div className="h-6 w-9 rounded-md bg-slate-700/60 flex items-center justify-center text-[10px] font-semibold text-slate-300 border border-slate-600/30 font-mono">
                Liner
              </div>
            </div>

            {/* Number display */}
            <div className="relative z-10 bg-transparent py-1 text-base tracking-widest font-mono font-bold text-slate-200">
              {cardNumber || '•••• •••• •••• ••••'}
            </div>

            {/* Footer data */}
            <div className="flex items-end justify-between relative z-10 text-xs">
              <div>
                <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-mono">Card Holder</span>
                <span className="font-mono font-semibold tracking-wide uppercase text-slate-100">
                  {cardHolder || 'CHARLOTTE MILLER'}
                </span>
              </div>
              <div className="text-right">
                <span className="block text-[8px] uppercase tracking-wider text-slate-400 font-mono">Expires</span>
                <span className="font-mono font-semibold text-slate-100">
                  {expiry || 'MM/YY'}
                </span>
              </div>
            </div>
          </div>

          {/* Fare pricing metrics card */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3 font-sans">
            <span className="block border-b border-slate-100 pb-2 text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">
              📋 Invoice breakdown
            </span>
            <div className="flex justify-between text-xs text-slate-500">
              <span>Standard Flight Fare:</span>
              <span className="font-bold text-slate-800 font-mono">${booking.price}</span>
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>Aero Taxes & VAT:</span>
              <span className="font-bold text-slate-800 font-mono">$0.00 (Inclusive)</span>
            </div>
            <div className="flex justify-between text-xs text-slate-500">
              <span>Fuel/Luggage surcharge:</span>
              <span className="font-bold text-slate-800 font-mono">$0.00 (Waived)</span>
            </div>
            <div className="border-t border-slate-100 pt-2 flex justify-between text-sm font-extrabold text-slate-900">
              <span>Checkout Total:</span>
              <span className="font-mono">${booking.price}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
