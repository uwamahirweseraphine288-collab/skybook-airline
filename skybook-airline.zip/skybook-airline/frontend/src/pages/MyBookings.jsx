import React, { useState, useEffect } from 'react';
import { bookingsApi } from '../utils/api.js';
import { Calendar, Plane, CreditCard, XCircle, Clock, ShieldCheck, Download, AlertCircle, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

export default function MyBookings({ onPayForBooking, onRefreshTrigger }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errMs, setErrMs] = useState('');
  const [actionLoading, setActionLoading] = useState(null);

  const fetchBookings = async () => {
    setLoading(true);
    setErrMs('');
    try {
      const data = await bookingsApi.getMyBookings();
      // Sort: latest bookings first
      setBookings(data.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch (err) {
      console.error(err);
      setErrMs("Failed to retrieve booking records. Connect a local storage instance or verify server availability.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, [onRefreshTrigger]);

  const handleCancel = async (id) => {
    if (!window.confirm("Are you sure you want to cancel this airline booking? Seats will be immediately re-allocated.")) {
      return;
    }
    setActionLoading(id);
    try {
      await bookingsApi.cancel(id);
      await fetchBookings();
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to cancel flight booking.');
    } finally {
      setActionLoading(null);
    }
  };

  const formatDateTime = (isoString) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }) + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return isoString;
    }
  };

  // Render direct printable boarding pass alert/sim
  const printPass = (booking) => {
    const flight = typeof booking.flight === 'object' ? booking.flight : null;
    if (!flight) return;
    
    alert(`
    ========== SKYBOOK BOARDING PASS ==========
    PASSENGER:  ${booking.passengerName.toUpperCase()}
    PASSPORT:   ${booking.passengerPassport.toUpperCase()}
    FLIGHT:     ${flight.flightNumber}
    ROUTE:      ${flight.origin} ✈ ${flight.destination}
    DEPARTURE:  ${formatDateTime(flight.departureTime)}
    SEAT ID:    ${booking.seatNumber}
    PAYMENT:    ${booking.paymentStatus.toUpperCase()}
    ===========================================
    Safe travels! Present this digital card on boarding gates.
    `);
  };

  return (
    <div className="space-y-6 pb-20 font-sans">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-905">My Booking History</h1>
          <p className="text-xs text-slate-500 font-normal">Track and manage your scheduled flights, process pending payments, and check boarding cards.</p>
        </div>
        <button
          onClick={fetchBookings}
          className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-605 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          title="Reload history data"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>Reload</span>
        </button>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-4 shadow-sm">
          <div className="animate-spin inline-block h-8 w-8 border-4 border-sky-500 border-t-transparent rounded-full" />
          <p className="text-slate-500 text-sm font-semibold">Retrieving ticketing database history...</p>
        </div>
      ) : errMs && bookings.length === 0 ? (
        <div className="bg-rose-50 border border-rose-100 text-rose-700 p-4 rounded-xl text-xs flex items-start gap-2.5">
          <AlertCircle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
          <p className="leading-relaxed font-normal">{errMs}</p>
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-4 shadow-sm max-w-lg mx-auto">
          <Calendar className="h-10 w-10 text-slate-300 mx-auto" />
          <p className="text-slate-850 text-base font-bold">No Active Flight Bookings Found</p>
          <p className="text-slate-500 text-xs leading-relaxed max-w-xs mx-auto font-normal">
            You don't have any flights reserved. Go search flights and check out standard seat options to create your first booking!
          </p>
        </div>
      ) : (
        <div className="space-y-4 font-normal text-slate-600">
          {bookings.map((booking, index) => {
            const flight = typeof booking.flight === 'object' ? booking.flight : null;
            if (!flight) return null;

            const isCancelled = booking.status === 'Cancelled';
            const isPaid = booking.paymentStatus === 'Paid';

            return (
              <motion.div
                key={booking.id || booking._id || `booking-${index}`}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
                className={`bg-white rounded-xl border p-5 shadow-sm hover:shadow-md transition-all flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6 ${
                  isCancelled ? 'border-slate-200 opacity-65 bg-slate-50' : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Flight Information */}
                <div className="flex-1 space-y-4">
                  {/* Row 1: Header tags */}
                  <div className="flex items-center space-x-3.5 flex-wrap gap-y-2">
                    <span className="text-xs uppercase font-bold text-slate-400 font-mono tracking-wider">
                      BOOKID: {booking.id?.substring(0, 8).toUpperCase() || "PENDING"}
                    </span>
                    
                    {/* Activity Status Badge */}
                    <span className={`text-[10px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                      isCancelled ? 'bg-rose-50 text-rose-700 border-rose-250' : 'bg-emerald-50 text-emerald-700 border-emerald-250'
                    }`}>
                      {booking.status}
                    </span>

                    {/* Payment Status Badge */}
                    <span className={`text-[10px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                      isPaid ? 'bg-sky-50 text-sky-700 border-sky-250' : 'bg-amber-50 text-amber-700 border-amber-250'
                    }`}>
                      {booking.paymentStatus}
                    </span>
                    
                    <span className="text-[10px] text-slate-400 font-mono">
                      Reserved on {formatDateTime(booking.createdAt)}
                    </span>
                  </div>

                  {/* Row 2: Origin and destination */}
                  <div className="grid grid-cols-12 items-center max-w-lg">
                    {/* Origin info */}
                    <div className="col-span-4 text-slate-800">
                      <span className="block text-base font-extrabold text-slate-900 leading-none">
                        {flight.origin}
                      </span>
                      <span className="block text-[11px] text-slate-500 font-mono mt-1 leading-normal font-normal">
                        {formatDateTime(flight.departureTime)}
                      </span>
                    </div>

                    {/* Direction divider Line */}
                    <div className="col-span-4 flex flex-col items-center justify-center text-center">
                      <span className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest mb-0.5">
                        {flight.flightNumber}
                      </span>
                      <div className="w-full h-0.5 bg-slate-200 relative">
                        <Plane className="h-3 w-3 text-sky-500 absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 -rotate-45 bg-white px-0.5" />
                      </div>
                      <span className="text-[10px] text-slate-500 font-bold font-sans mt-0.5 whitespace-nowrap">
                        {flight.airline}
                      </span>
                    </div>

                    {/* Destination info */}
                    <div className="col-span-4 text-right text-slate-800">
                      <span className="block text-base font-extrabold text-slate-900 leading-none">
                        {flight.destination}
                      </span>
                      <span className="block text-[11px] text-slate-500 font-mono mt-1 leading-normal font-normal">
                        {formatDateTime(flight.arrivalTime)}
                      </span>
                    </div>
                  </div>

                  {/* Row 3: Passenger core info */}
                  <div className="border-t border-slate-100 pt-3 mt-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <span className="block text-[9px] font-mono uppercase text-slate-400 font-bold">Passenger Name</span>
                      <span className="text-xs font-bold text-slate-700 uppercase">{booking.passengerName}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono uppercase text-slate-400 font-bold">Passport Number</span>
                      <span className="text-xs font-bold text-slate-700 uppercase font-mono">{booking.passengerPassport}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] font-mono uppercase text-slate-400 font-bold">Assigned Cabin Seat</span>
                      <span className="text-xs font-bold text-sky-600 font-mono">{booking.seatNumber}</span>
                    </div>
                  </div>
                </div>

                {/* Vertical Payment Breakdown & Action panel */}
                <div className="flex flex-row md:flex-col justify-between md:justify-center items-center md:items-end border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-6 shrink-0 gap-4">
                  <div className="text-left md:text-right">
                    <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                      Ticket Cost
                    </span>
                    <span className="text-xl font-black font-sans text-slate-900">
                      ${booking.price}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Option 1: Checkout payment for pending bills */}
                    {!isCancelled && !isPaid && (
                      <button
                        onClick={() => onPayForBooking(booking)}
                        className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold py-2 px-3.5 rounded-lg text-xs transition-colors shadow shadow-sky-500/15 flex items-center gap-1 hover:shadow-lg hover:shadow-sky-500/20 active:scale-95 pointer-events-auto cursor-pointer"
                      >
                        <CreditCard className="h-3.5 w-3.5" />
                        <span>Pay Bill</span>
                      </button>
                    )}

                    {/* Option 2: Print/Download flight pass for paid status */}
                    {!isCancelled && isPaid && (
                      <button
                        onClick={() => printPass(booking)}
                        className="bg-slate-105 border border-slate-202 hover:bg-slate-200 text-slate-800 font-bold py-2 px-3.5 rounded-lg text-xs transition-colors flex items-center gap-1 active:scale-95 pointer-events-auto cursor-pointer"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Boarding Card</span>
                      </button>
                    )}

                    {/* Option 3: Cancellation alert */}
                    {!isCancelled && (
                      <button
                        onClick={() => handleCancel(booking.id || booking._id)}
                        disabled={actionLoading === (booking.id || booking._id)}
                        className="border border-slate-200 hover:border-rose-200 hover:bg-rose-50 text-slate-500 hover:text-rose-600 p-2 rounded-lg text-xs transition-colors duration-200 pointer-events-auto cursor-pointer"
                        title="Cancel ticket booking"
                      >
                        <XCircle className="h-4.5 w-4.5" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
