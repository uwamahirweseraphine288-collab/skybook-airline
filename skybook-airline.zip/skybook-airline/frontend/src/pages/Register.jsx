import React, { useState } from 'react';
import { Mail, Lock, ShieldAlert, ArrowRight, UserCheck, Plane, User } from 'lucide-react';
import { authApi } from '../utils/api.js';
import { motion } from 'motion/react';

export default function Register({ onRegisterSuccess, onNavigateToLogin }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('passenger');
  const [loading, setLoading] = useState(false);
  const [errorR, setErrorR] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setErrorR('Please fill in all standard registration inputs.');
      return;
    }
    setErrorR('');
    setLoading(true);
    try {
      const data = await authApi.register(name.trim(), email.trim(), password, role);
      onRegisterSuccess(data.user);
    } catch (err) {
      console.error(err);
      setErrorR(err.response?.data?.message || 'Failed to complete registration. Email may already be associated.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto my-12 font-sans">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white p-8 rounded-2xl border border-slate-200 shadow-xl shadow-slate-100/50 space-y-6"
      >
        {/* Logo header */}
        <div className="text-center space-y-2">
          <div className="mx-auto bg-sky-500 text-slate-950 p-2.5 rounded-xl w-fit shadow-md">
            <Plane className="h-5 w-5 transform -rotate-45" />
          </div>
          <h2 className="text-xl font-bold text-slate-905">Register on SkyBook</h2>
          <p className="text-xs text-slate-400 font-normal">Join our flight network for free and book tickets immediately.</p>
        </div>

        {errorR && (
          <div className="bg-rose-50 border border-rose-100 text-rose-700 text-xs p-3.5 rounded-xl flex items-start gap-2.5">
            <ShieldAlert className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
            <p className="leading-relaxed font-normal">{errorR}</p>
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          {/* User Name input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Full Legal Name
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <User className="h-4 w-4" />
              </span>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Charlotte Miller"
                className="block w-full pl-9 pr-3 py-2 text-sm bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-909 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          {/* Email input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Mail className="h-4 w-4" />
              </span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="passenger@skybook.com"
                className="block w-full pl-9 pr-3 py-2 text-sm bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-909 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          {/* Password input */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Access Password
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
                <Lock className="h-4 w-4" />
              </span>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="block w-full pl-9 pr-3 py-2 text-sm bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-909 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all font-medium"
              />
            </div>
          </div>

          {/* Role Check Selection */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider font-mono">
              Aviation Account Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label className={`border rounded-xl p-3 flex flex-col cursor-pointer transition-all ${
                role === 'passenger' 
                  ? 'border-sky-500 bg-sky-50/50 text-sky-950 ring-2 ring-sky-500/10' 
                  : 'border-slate-202 hover:border-slate-300 bg-white text-slate-700'
              }`}>
                <input
                  type="radio"
                  name="role"
                  value="passenger"
                  checked={role === 'passenger'}
                  onChange={() => setRole('passenger')}
                  className="sr-only"
                />
                <span className="text-xs font-bold font-sans">Passenger</span>
                <span className="text-[10px] text-slate-550 mt-0.5 leading-normal">Explore & book local/global flight tickets</span>
              </label>

              <label className={`border rounded-xl p-3 flex flex-col cursor-pointer transition-all ${
                role === 'admin' 
                  ? 'border-sky-500 bg-sky-50/50 text-sky-950 ring-2 ring-sky-500/10' 
                  : 'border-slate-202 hover:border-slate-300 bg-white text-slate-705'
              }`}>
                <input
                  type="radio"
                  name="role"
                  value="admin"
                  checked={role === 'admin'}
                  onChange={() => setRole('admin')}
                  className="sr-only"
                />
                <span className="text-xs font-bold font-sans">Administrator</span>
                <span className="text-[10px] text-slate-550 mt-0.5 leading-normal">Schedule flights, read stats & supervise bookings</span>
              </label>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 rounded-xl text-sm transition-all shadow shadow-slate-900/10 hover:shadow-lg hover:shadow-slate-900/10 font-sans active:scale-[0.98] inline-flex items-center justify-center space-x-2 cursor-pointer"
          >
            <span>{loading ? 'Creating Account Profile...' : 'Complete Registration'}</span>
            {!loading && <ArrowRight className="h-3.5 w-3.5" />}
          </button>
        </form>

        {/* Action Toggle */}
        <div className="border-t border-slate-100 pt-4 text-center">
          <p className="text-xs text-slate-500">
            Already have an active profile?{' '}
            <button
              onClick={onNavigateToLogin}
              className="font-semibold text-sky-600 hover:text-sky-700 hover:underline inline-flex items-center gap-0.5 cursor-pointer"
            >
              Sign In Here
            </button>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
