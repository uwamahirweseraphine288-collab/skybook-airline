import React, { useState } from 'react';
import { PlaneTakeoff, PlaneLanding, Calendar, Search, ShieldCheck, MapPin, Compass } from 'lucide-react';
import { motion } from 'motion/react';

const POPULAR_AIRPORTS = [
  { city: 'New York', code: 'JFK', country: 'United States' },
  { city: 'Los Angeles', code: 'LAX', country: 'United States' },
  { city: 'London', code: 'LHR', country: 'United Kingdom' },
  { city: 'Dubai', code: 'DXB', country: 'United Arab Emirates' },
  { city: 'Paris', code: 'CDG', country: 'France' },
  { city: 'Tokyo', code: 'HND', country: 'Japan' },
  { city: 'Singapore', code: 'SIN', country: 'Singapore' },
  { city: 'Sydney', code: 'SYD', country: 'Australia' },
];

export default function Home({ onSearch }) {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [errorForm, setErrorForm] = useState('');

  const [originFocused, setOriginFocused] = useState(false);
  const [destFocused, setDestFocused] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!origin.trim() || !destination.trim()) {
      setErrorForm('Please select both origin and destination airports.');
      return;
    }
    if (origin.trim().toUpperCase() === destination.trim().toUpperCase()) {
      setErrorForm('Origin and destination cannot be the same city.');
      return;
    }
    setErrorForm('');
    onSearch({ origin: origin.trim(), destination: destination.trim(), date });
  };

  const selectOrigin = (code) => {
    setOrigin(code);
    setOriginFocused(false);
  };

  const selectDest = (code) => {
    setDestination(code);
    setDestFocused(false);
  };

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Header Section */}
      <div className="relative overflow-hidden bg-slate-950 text-white rounded-3xl py-16 px-6 sm:px-12 shadow-2xl border border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(14,165,233,0.15),transparent_40%)]" />
        <div className="absolute top-10 right-10 bg-slate-800/10 h-72 w-72 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl space-y-6">
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center space-x-2 bg-sky-500/10 border border-sky-500/20 px-3 py-1 rounded-full text-sky-400 text-xs font-semibold uppercase tracking-wider font-mono"
          >
            <Compass className="h-3.5 w-3.5" />
            <span>Discover your next destination</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-sans tracking-tight text-white leading-tight"
          >
            Smarter Bookings,<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-sky-300">
              Smoother Journeys.
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-slate-400 text-base sm:text-lg max-w-xl font-normal leading-relaxed"
          >
            Reserve non-stop or connection routes on elite aircraft. Access verified status alerts, seat customization, and instant transaction checkouts.
          </motion.p>
        </div>
      </div>

      {/* Flight Search Console Component */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="bg-white rounded-2xl shadow-xl shadow-slate-100/50 p-6 sm:p-8 border border-slate-100 max-w-5xl mx-auto -mt-20 relative z-20"
      >
        <span className="block border-b border-slate-100 pb-4 mb-6 font-sans text-sm font-semibold text-slate-800 uppercase tracking-wider">
          💡 Flight Search Engine
        </span>

        {errorForm && (
          <div className="bg-rose-50 border border-rose-200 text-rose-700 text-sm p-4 rounded-xl mb-6">
            {errorForm}
          </div>
        )}

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-5 items-end">
          {/* FROM */}
          <div className="md:col-span-4 relative group">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
              Leaving From
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none group-focus-within:text-sky-500 transition-colors">
                <PlaneTakeoff className="h-5 w-5" />
              </span>
              <input
                type="text"
                placeholder="Airport Code or City"
                value={origin}
                onChange={(e) => setOrigin(e.target.value.toUpperCase())}
                onFocus={() => { setOriginFocused(true); setDestFocused(false); }}
                className="block w-full pl-11 pr-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
              />
            </div>

            {originFocused && (
              <div className="absolute z-30 left-0 right-0 mt-2 bg-white rounded-xl shadow-2xl border border-slate-150 py-2 max-h-52 overflow-y-auto">
                <div className="px-3 py-1 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Select Departure Airport
                </div>
                {POPULAR_AIRPORTS.filter(ap => 
                  ap.city.toLowerCase().includes(origin.toLowerCase()) || 
                  ap.code.toLowerCase().includes(origin.toLowerCase())
                ).map(ap => (
                  <button
                    key={`orig-${ap.code}`}
                    type="button"
                    onClick={() => selectOrigin(ap.code)}
                    className="w-full text-left px-4 py-1.5 hover:bg-slate-50 transition-colors flex justify-between items-center"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-800">{ap.city} ({ap.code})</div>
                      <div className="text-[10px] text-slate-400 font-normal">{ap.country}</div>
                    </div>
                    <MapPin className="h-3.5 w-3.5 text-slate-300" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* TO */}
          <div className="md:col-span-4 relative group">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
              Going To
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none group-focus-within:text-sky-500 transition-colors">
                <PlaneLanding className="h-5 w-5" />
              </span>
              <input
                type="text"
                placeholder="Airport Code or City"
                value={destination}
                onChange={(e) => setDestination(e.target.value.toUpperCase())}
                onFocus={() => { setDestFocused(true); setOriginFocused(false); }}
                className="block w-full pl-11 pr-4 py-3 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
              />
            </div>

            {destFocused && (
              <div className="absolute z-30 left-0 right-0 mt-2 bg-white rounded-xl shadow-2xl border border-slate-150 py-2 max-h-52 overflow-y-auto">
                <div className="px-3 py-1 text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  Select Destination Airport
                </div>
                {POPULAR_AIRPORTS.filter(ap => 
                  ap.city.toLowerCase().includes(destination.toLowerCase()) || 
                  ap.code.toLowerCase().includes(destination.toLowerCase())
                ).map(ap => (
                  <button
                    key={`dest-${ap.code}`}
                    type="button"
                    onClick={() => selectDest(ap.code)}
                    className="w-full text-left px-4 py-1.5 hover:bg-slate-50 transition-colors flex justify-between items-center"
                  >
                    <div>
                      <div className="text-xs font-semibold text-slate-800">{ap.city} ({ap.code})</div>
                      <div className="text-[10px] text-slate-400 font-normal">{ap.country}</div>
                    </div>
                    <MapPin className="h-3.5 w-3.5 text-slate-300" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* DATE */}
          <div className="md:col-span-2 group">
            <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
              Departure
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-400 pointer-events-none group-focus-within:text-sky-500 transition-colors">
                <Calendar className="h-4 w-4" />
              </span>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="block w-full pl-11 pr-3 py-3 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
              />
            </div>
          </div>

          {/* SUBMIT BUTTON */}
          <div className="md:col-span-2">
            <button
              type="submit"
              className="w-full bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold py-3.5 px-4 rounded-xl inline-flex items-center justify-center space-x-2 shadow-lg shadow-sky-500/20 transition-all transform active:scale-95 text-sm"
            >
              <Search className="h-4 w-4 stroke-[3px]" />
              <span>Search</span>
            </button>
          </div>
        </form>
      </motion.div>

      {/* Featured Travel Perks Section */}
      <div className="space-y-6">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold font-sans tracking-tight text-slate-900">
            Why Fly with SkyBook?
          </h2>
          <p className="text-slate-500 text-sm max-w-md mx-auto leading-relaxed">
            Leading airline services matching luxury, security, and top performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {/* Card 1 */}
          <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
            <div className="space-y-4">
              <div className="bg-sky-100/60 p-3 rounded-xl w-fit text-sky-600">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Guaranteed Protection</h3>
              <p className="text-slate-500 text-xs leading-relaxed">
                Zero security friction. Real-time boarding protocols, compliant flight protection, and verified digital passports.
              </p>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
            <div className="space-y-4">
              <div className="bg-emerald-100/60 p-3 rounded-xl w-fit text-emerald-600">
                <PlaneTakeoff className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Elite Modern Fleets</h3>
              <p className="text-slate-500 text-xs leading-relaxed">
                Cruise at optimal altitudes inside cutting-edge Dreamliners and Airbus flagships engineered for premium travel.
              </p>
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
            <div className="space-y-4">
              <div className="bg-sky-100/60 p-3 rounded-xl w-fit text-sky-600">
                <MapPin className="h-6 w-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">Direct Connections</h3>
              <p className="text-slate-500 text-xs leading-relaxed">
                Unlock instant access to central global hubs without multi-leg stopovers. Spend less time in transit, more time exploring.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
