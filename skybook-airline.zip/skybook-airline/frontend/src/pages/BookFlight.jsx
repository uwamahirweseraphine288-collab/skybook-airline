import React, { useState } from 'react';
import { bookingsApi } from '../utils/api.js';
import { ArrowLeft, User, ShieldAlert, CheckCircle, Plane, Armchair, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

// Generate rows and columns for seat map viz
const SEAT_ROWS = [1, 2, 3, 4, 5];
const SEAT_COLS = ['A', 'B', 'C', 'D', 'E', 'F'];

export default function BookFlight({ selectedFlight, onBookingSuccess, onBack }) {
  const [passengerName, setPassengerName] = useState('');
  const [passengerAge, setPassengerAge] = useState('');
  const [passengerPassport, setPassengerPassport] = useState('');
  const [selectedSeat, setSelectedSeat] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [errorB, setErrorB] = useState('');

  // Setup simple deterministic simulated occupied seats
  const isSeatOccupied = (row, col) => {
    // Occupied if row + numerical ASCII of col is divisible by 3 or 5
    const code = col.charCodeAt(0);
    return (row + code) % 3 === 0 || (row * code) % 5 === 0;
  };

  const handleBookingSubmit = async (e) => {
    e.preventDefault();
    if (!passengerName || !passengerAge || !passengerPassport) {
      setErrorB('Please complete all passenger registration inputs.');
      return;
    }
    if (!selectedSeat) {
      setErrorB('Please select an available ticket seat from the interactive cabin layout below.');
      return;
    }
    setErrorB('');
    setLoading(true);
    try {
      const data = await bookingsApi.create({
        flightId: selectedFlight.id || selectedFlight._id || '',
        passengerName: passengerName.trim(),
        passengerAge: parseInt(passengerAge),
        passengerPassport: passengerPassport.trim().toUpperCase(),
        seatNumber: selectedSeat,
        price: selectedFlight.price,
      });
      onBookingSuccess(data);
    } catch (err) {
      console.error(err);
      setErrorB(err.response?.data?.message || 'We could not write your flight booking ticket. Sign in as Passenger.');
    } finally {
      setLoading(false);
    }
  };

  const selectSeatControl = (row, col) => {
    if (isSeatOccupied(row, col)) return;
    setSelectedSeat(`${row}${col}`);
  };

  return (
    <div className="space-y-6 pb-20 max-w-4xl mx-auto">
      <div className="flex items-center space-x-3 border-b border-slate-200 pb-4">
        <button
          onClick={onBack}
          className="p-2 hover:bg-slate-200 text-slate-600 rounded-lg transition-colors border border-slate-250"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div>
          <h1 className="text-xl font-bold font-sans text-slate-900">Configure Reservation</h1>
          <p className="text-xs text-slate-500">Provide legal passport credentials, passenger tags, and select cabin seating.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        
        {/* Left Side: Passenger registration form */}
        <div className="md:col-span-7 bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-6">
          <span className="block border-b border-slate-100 pb-3 text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">
            📋 Passenger Credentials
          </span>

          {errorB && (
            <div className="bg-rose-50 border border-rose-100 text-rose-700 text-xs p-3.5 rounded-xl flex items-start gap-2.5">
              <ShieldAlert className="h-4.5 w-4.5 text-rose-500 shrink-0 mt-0.5" />
              <p className="leading-relaxed">{errorB}</p>
            </div>
          )}

          <form onSubmit={handleBookingSubmit} className="space-y-4">
            {/* Passenger Name input */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
                Full Passenger Name (As in Passport)
              </label>
              <input
                type="text"
                required
                value={passengerName}
                onChange={(e) => setPassengerName(e.target.value)}
                placeholder="Charlotte Miller"
                className="block w-full pl-3.5 pr-4 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-905 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Age */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
                  Passenger Age
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  max={120}
                  value={passengerAge}
                  onChange={(e) => setPassengerAge(e.target.value)}
                  placeholder="28"
                  className="block w-full pl-3.5 pr-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-905 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
                />
              </div>

              {/* Passport */}
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 font-mono">
                  Passport Number
                </label>
                <input
                  type="text"
                  required
                  value={passengerPassport}
                  onChange={(e) => setPassengerPassport(e.target.value.toUpperCase())}
                  placeholder="US1234567"
                  className="block w-full pl-3.5 pr-3 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl leading-5 text-slate-905 focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-500 focus:bg-white transition-all text-sm font-medium"
                />
              </div>
            </div>

            {/* Selected Seat Indicator */}
            <div className="bg-slate-50 border border-slate-150 p-3 rounded-xl flex items-center justify-between">
              <div>
                <span className="block text-[10px] font-mono text-slate-450 uppercase font-bold">Assigned Seat ID</span>
                <span className="text-sm font-bold text-slate-800">
                  {selectedSeat ? `Cabin Seat ${selectedSeat}` : 'Not Selected yet'}
                </span>
              </div>
              <div className="bg-sky-100/50 text-sky-700 px-3 py-1.5 rounded-lg text-xs font-mono font-bold">
                Fare: ${selectedFlight.price}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-400 text-white font-bold py-2.5 rounded-xl text-sm transition-all shadow-md font-sans active:scale-[0.98] inline-flex items-center justify-center space-x-2 cursor-pointer"
            >
              <span>{loading ? 'Processing Hold Request...' : 'Proceed to Checkout 💳'}</span>
            </button>
          </form>
        </div>

        {/* Right Side: Interactive cabin seat visual selector */}
        <div className="md:col-span-5 bg-white p-6 rounded-xl border border-slate-205 shadow-sm space-y-4">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-widest font-mono">
              💺 Cabin Layout
            </span>
            <div className="flex items-center space-x-1.5 text-[9px] font-mono tracking-wider font-bold">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span className="text-slate-450">Available</span>
              <span className="h-2 w-2 rounded-full bg-slate-200 ml-1" />
              <span className="text-slate-450">Booked</span>
            </div>
          </div>

          <p className="text-[10px] text-slate-500 leading-relaxed text-center">
            Click on any available green seat coordinates inside our Dreamliner cabin.
          </p>

          {/* Visual airplane outline element */}
          <div className="border-2 border-dashed border-slate-200 rounded-3xl p-5 bg-slate-55 max-w-xs mx-auto space-y-4">
            <div className="h-6 w-12 bg-slate-200 rounded-t-full mx-auto" title="Cockpit Nose" />
            
            <div className="space-y-2">
              {/* Seat Coordinates Column Letters header */}
              <div className="grid grid-cols-6 gap-2 text-center text-[10px] font-mono font-bold text-slate-400">
                {SEAT_COLS.map(c => <span key={`head-c-${c}`}>{c}</span>)}
              </div>

              {/* Rows */}
              {SEAT_ROWS.map((row, idx) => (
                <div key={`row-${row}`} className="grid grid-cols-6 gap-2 items-center">
                  {SEAT_COLS.map(col => {
                    const seatId = `${row}${col}`;
                    const occupied = isSeatOccupied(row, col);
                    const isSelected = selectedSeat === seatId;
                    
                    return (
                      <button
                        key={`seat-${seatId}`}
                        type="button"
                        onClick={() => selectSeatControl(row, col)}
                        className={`aspect-square p-0 flex items-center justify-center rounded-md border text-[9px] font-mono font-bold transition-all relative ${
                          occupied 
                            ? 'bg-slate-200 text-slate-400 border-slate-200 cursor-not-allowed' 
                            : isSelected
                              ? 'bg-sky-500 text-slate-950 border-sky-650 ring-2 ring-sky-550/30 font-black scale-105'
                              : 'bg-emerald-55/60 hover:bg-emerald-100 text-emerald-850 border-emerald-200 hover:border-emerald-350 cursor-pointer'
                        }`}
                        title={`Seat ${seatId} - ${occupied ? 'Occupied' : isSelected ? 'Your Selection' : 'Available'}`}
                        disabled={occupied}
                      >
                        <Armchair className={`h-3.5 w-3.5 ${
                          occupied ? 'text-slate-300' : isSelected ? 'text-slate-905' : 'text-emerald-500'
                        }`} />
                      </button>
                    );
                  })}
                </div>
              ))}
            </div>

            <div className="h-3 w-16 bg-slate-205 rounded-b-md mx-auto" title="Galley Tail" />
          </div>

          <div className="text-center">
            <span className="text-[10px] font-mono text-slate-450 leading-normal">
              Airplane Specs: **Boeing 787 Elite Liner**
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
