import React, { useState, useEffect } from 'react';
import { adminApi, flightsApi } from '../utils/api.js';
import { 
  Users, Calendar, Landmark, Plane, Plus, Trash2, Edit3, 
  BarChart3, RefreshCw, Layers, ShieldCheck, Ticket, CalendarDays, Search 
} from 'lucide-react';
import { motion } from 'motion/react';

export default function AdminDashboard({ onRefreshTrigger }) {
  const [activeSubTab, setActiveSubTab] = useState('overview');
  const [stats, setStats] = useState(null);
  const [flights, setFlights] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers] = useState([]);
  
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  // Flight Add/Edit state
  const [flightNumber, setFlightNumber] = useState('');
  const [airline, setAirline] = useState('');
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [departureTime, setDepartureTime] = useState('');
  const [arrivalTime, setArrivalTime] = useState('');
  const [price, setPrice] = useState('');
  const [totalSeats, setTotalSeats] = useState('150');
  const [status, setStatus] = useState('Scheduled');
  const [editingFlightId, setEditingFlightId] = useState(null);
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [formErr, setFormErr] = useState('');
  const [formSubmitting, setFormSubmitting] = useState(false);

  const fetchAllAdminData = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      // Parallel retrieval for snappy UX
      const [statsData, flightsData, bookingsData, usersData] = await Promise.all([
        adminApi.getDashboardStats(),
        flightsApi.getAll(),
        adminApi.getAllBookings(),
        adminApi.getUsers()
      ]);

      setStats(statsData);
      setFlights(flightsData);
      setBookings(bookingsData);
      setUsers(usersData);
    } catch (err) {
      console.error(err);
      setErrorMsg("Failed to read secure corporate airline databases. Ensure database configuration values are accurate.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAllAdminData();
  }, []);

  const handleCreateOrUpdateFlight = async (e) => {
    e.preventDefault();
    if (!flightNumber || !airline || !origin || !destination || !departureTime || !arrivalTime || !price) {
      setFormErr('Please complete all flight credentials input areas.');
      return;
    }
    setFormErr('');
    setFormSubmitting(true);
    
    const flightObj = {
      flightNumber: flightNumber.trim().toUpperCase(),
      airline: airline.trim(),
      origin: origin.trim().toUpperCase(),
      destination: destination.trim().toUpperCase(),
      departureTime,
      arrivalTime,
      price: parseFloat(price),
      totalSeats: parseInt(totalSeats),
      availableSeats: parseInt(totalSeats),
      status
    };

    try {
      if (editingFlightId) {
        await flightsApi.update(editingFlightId, flightObj);
      } else {
        await flightsApi.create(flightObj);
      }
      
      // Cleanup inputs
      resetForm();
      await fetchAllAdminData();
      if (onRefreshTrigger) {
        onRefreshTrigger(); // Signals parent components
      }
    } catch (err) {
      setFormErr(err.response?.data?.message || 'Transaction registry block. Ensure unique flight code keys.');
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleEditInit = (f) => {
    setFlightNumber(f.flightNumber);
    setAirline(f.airline);
    setOrigin(f.origin);
    setDestination(f.destination);
    setDepartureTime(f.departureTime.split('.')[0]); // Truncate ISO millis for inputs
    setArrivalTime(f.arrivalTime.split('.')[0]);
    setPrice(f.price.toString());
    setTotalSeats(f.totalSeats.toString());
    setStatus(f.status);
    setEditingFlightId(f.id || f._id);
    setShowAddForm(true);
  };

  const handleDeleteFlight = async (id) => {
    if (!window.confirm("CRITICAL ADMIN WARNING: Are you sure you want to delete this flight Connection permanently? All associated bookings will be flagged.")) {
      return;
    }
    try {
      await flightsApi.delete(id);
      await fetchAllAdminData();
      if (onRefreshTrigger) {
        onRefreshTrigger();
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Access Denied deleting flight records.');
    }
  };

  const resetForm = () => {
    setFlightNumber('');
    setAirline('');
    setOrigin('');
    setDestination('');
    setDepartureTime('');
    setArrivalTime('');
    setPrice('');
    setTotalSeats('150');
    setStatus('Scheduled');
    setEditingFlightId(null);
    setShowAddForm(false);
  };

  const formatDateTime = (isoString) => {
    try {
      const d = new Date(isoString);
      return d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="space-y-6 pb-20 font-sans">
      
      {/* Upper Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-905 flex items-center gap-2">
            <span>Corporate Admin Command</span>
            <span className="text-[10px] bg-slate-905 text-sky-400 font-mono tracking-widest uppercase font-bold py-0.5 px-2.5 rounded-full border border-slate-800">
              System Supervisor
            </span>
          </h1>
          <p className="text-xs text-slate-505 font-medium leading-relaxed font-normal">Coordinate flights schedule CRUD databases, monitor total ticket sales, and supervise passenger billing records.</p>
        </div>
        
        {/* Operations command buttons */}
        <div className="flex items-center space-x-2">
          <button
            onClick={fetchAllAdminData}
            title="Reload backend catalog telemetry"
            className="p-2 border border-slate-202 hover:bg-slate-100 text-slate-650 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold cursor-pointer"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Telemetry Reload</span>
          </button>
          
          <button
            onClick={() => { resetForm(); setShowAddForm(true); }}
            className="bg-sky-505 hover:bg-sky-450 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold py-2 px-4 rounded-lg text-xs transition-colors shadow-lg shadow-sky-500/15 flex items-center gap-1.5 cursor-pointer leading-none"
          >
            <Plus className="h-3.5 w-3.5 stroke-[3]" />
            <span>Schedule Flight</span>
          </button>
        </div>
      </div>

      {loading && !stats ? (
        <div className="bg-white rounded-xl p-12 text-center border border-slate-200 space-y-4 shadow-sm">
          <div className="animate-spin inline-block h-8 w-8 border-4 border-sky-500 border-t-transparent rounded-full" />
          <p className="text-slate-500 text-sm font-semibold">Re-authenticating corporate telemetry lines...</p>
        </div>
      ) : (
        <>
          {/* Bento Statistics Grid Tab */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Cell 1: Total Users */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Rostered Users</span>
                <span className="text-2xl font-black text-slate-905 block font-mono">
                  {stats?.totalUsers || users.length}
                </span>
              </div>
              <div className="bg-sky-50/60 p-2.5 rounded-xl text-sky-600">
                <Users className="h-5 w-5" />
              </div>
            </div>

            {/* Cell 2: Total Bookings */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Total Bookings</span>
                <span className="text-2xl font-black text-slate-905 block font-mono">
                  {stats?.totalBookings || bookings.length}
                </span>
              </div>
              <div className="bg-sky-50/60 p-2.5 rounded-xl text-sky-600">
                <Ticket className="h-5 w-5" />
              </div>
            </div>

            {/* Cell 3: Total Flights */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Active Planes</span>
                <span className="text-2xl font-black text-slate-905 block font-mono">
                  {flights.length}
                </span>
              </div>
              <div className="bg-emerald-50/60 p-2.5 rounded-xl text-emerald-600">
                <Plane className="h-5 w-5" />
              </div>
            </div>

            {/* Cell 4: Cumulative Revenue */}
            <div className="bg-white border border-slate-200 p-5 rounded-xl shadow-sm flex items-center justify-between">
              <div className="space-y-1">
                <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Total Revenue</span>
                <span className="text-2xl font-black font-sans block text-emerald-600 font-mono">
                  ${stats?.totalRevenue || 0}
                </span>
              </div>
              <div className="bg-emerald-50/60 p-2.5 rounded-xl text-emerald-600">
                <Landmark className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* CRITICAL Form MODAL: Add/Edit Flight Schedule */}
          {showAddForm && (
            <div className="bg-white p-6 rounded-xl border border-sky-200 shadow-xl shadow-sky-500/5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
                  <Plane className="h-4 w-4 text-sky-500" />
                  <span>{editingFlightId ? 'Amend Scheduled Flight Metadata' : 'Initiate New Airline Connection'}</span>
                </span>
                <button 
                  onClick={resetForm}
                  className="text-slate-400 hover:text-slate-600 text-xs font-semibold cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              {formErr && (
                <div className="bg-rose-50 border border-rose-100 text-rose-700 p-3.5 rounded-xl text-xs font-normal">
                  {formErr}
                </div>
              )}

              <form onSubmit={handleCreateOrUpdateFlight} className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Flight ID Code</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="SK-700" 
                    value={flightNumber} 
                    onChange={(e) => setFlightNumber(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 uppercase tracking-widest font-mono font-medium"
                  />
                </div>

                <div className="sm:col-span-6 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Airline Brand Provider</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="SkyBook Dreamliner Jet" 
                    value={airline} 
                    onChange={(e) => setAirline(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-medium"
                  />
                </div>

                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">Flight Condition</label>
                  <select 
                    value={status} 
                    onChange={(e) => setStatus(e.target.value)}
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-905 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-semibold"
                  >
                    <option value="Scheduled">Scheduled</option>
                    <option value="Delayed">Delayed</option>
                    <option value="Cancelled">Cancelled</option>
                    <option value="Completed">Completed</option>
                  </select>
                </div>

                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Departure Airport</label>
                  <input 
                    type="text" 
                    required 
                    maxLength={3} 
                    placeholder="LHR" 
                    value={origin} 
                    onChange={(e) => setOrigin(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 uppercase font-mono text-center font-bold"
                  />
                </div>

                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Destination Airport</label>
                  <input 
                    type="text" 
                    required 
                    maxLength={3} 
                    placeholder="DXB" 
                    value={destination} 
                    onChange={(e) => setDestination(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 uppercase font-mono text-center font-bold"
                  />
                </div>

                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Ticket Cost ($ USD)</label>
                  <input 
                    type="number" 
                    required 
                    placeholder="450" 
                    value={price} 
                    onChange={(e) => setPrice(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-mono font-bold"
                  />
                </div>

                <div className="sm:col-span-3 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Aircraft Seat Capacity</label>
                  <input 
                    type="number" 
                    required 
                    placeholder="150" 
                    value={totalSeats} 
                    onChange={(e) => setTotalSeats(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-mono"
                  />
                </div>

                <div className="sm:col-span-6 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Leaving Date / Clock Hour</label>
                  <input 
                    type="datetime-local" 
                    required 
                    value={departureTime} 
                    onChange={(e) => setDepartureTime(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-mono font-medium"
                  />
                </div>

                <div className="sm:col-span-6 space-y-1">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono font-mono">Arrival Date / Clock Hour</label>
                  <input 
                    type="datetime-local" 
                    required 
                    value={arrivalTime} 
                    onChange={(e) => setArrivalTime(e.target.value)} 
                    className="block w-full px-2.5 py-1.5 text-xs bg-slate-50/50 border border-slate-202 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-sky-500/10 font-mono font-medium"
                  />
                </div>

                <div className="sm:col-span-12 flex items-center justify-end space-x-2 pt-2">
                  <button 
                    type="button" 
                    onClick={resetForm}
                    className="px-4 py-2 border border-slate-200 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Close Dialog
                  </button>
                  <button 
                    type="submit" 
                    disabled={formSubmitting}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shadow-sm cursor-pointer"
                  >
                    {formSubmitting ? 'Amending Records...' : editingFlightId ? 'Amend Connection ✈' : 'Launch Connection ✈'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Sub Navigation controls */}
          <div className="flex border-b border-slate-200 font-bold overflow-x-auto">
            <button
              onClick={() => setActiveSubTab('overview')}
              className={`px-4 py-2.5 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeSubTab === 'overview' 
                  ? 'border-sky-500 text-sky-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-700'
              }`}
            >
              📊 Flights Capacity Usage
            </button>
            <button
              onClick={() => setActiveSubTab('flights')}
              className={`px-4 py-2.5 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeSubTab === 'flights' 
                  ? 'border-sky-500 text-sky-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-700'
              }`}
            >
              ✈ Manage Flight Schedules
            </button>
            <button
              onClick={() => setActiveSubTab('bookings')}
              className={`px-4 py-2.5 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeSubTab === 'bookings' 
                  ? 'border-sky-500 text-sky-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-705'
              }`}
            >
              🎫 Customer Bookings Catalog
            </button>
            <button
              onClick={() => setActiveSubTab('users')}
              className={`px-4 py-2.5 text-xs font-bold font-mono uppercase tracking-wider border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                activeSubTab === 'users' 
                  ? 'border-sky-500 text-sky-600' 
                  : 'border-transparent text-slate-400 hover:text-slate-705'
              }`}
            >
              👥 Customer Profiles Registry
            </button>
          </div>

          {/* Sub Navigation tab contents */}
          <div className="bg-white rounded-xl border border-slate-205 py-5 px-6 shadow-sm min-h-64">
            
            {/* 1. OVERVIEW GRAPH CAPACITY REPORT LIST */}
            {activeSubTab === 'overview' && (
              <div className="space-y-6">
                <span className="block text-xs font-bold text-slate-850 uppercase tracking-widest font-mono border-b border-slate-100 pb-2">
                  Occupancy Report Summary
                </span>

                {stats?.flightsReport && stats.flightsReport.length > 0 ? (
                  <div className="space-y-4 font-normal text-slate-655">
                    {stats.flightsReport.map((fRep, iIdx) => (
                      <div key={`rep-${iIdx}`} className="space-y-1.5">
                        <div className="flex justify-between items-end text-xs font-semibold">
                          <div>
                            <span className="text-slate-900 font-extrabold">{fRep.flightNumber}</span>
                            <span className="text-slate-400 font-mono text-[10px] ml-1.5 uppercase tracking-wider">
                              ({fRep.route})
                            </span>
                          </div>
                          <span className="font-mono text-[10px] text-slate-500">
                            Occupancy: <span className="text-sky-600 font-black">{fRep.occupancy}%</span> • {fRep.seatsBooked}/{fRep.seatsTotal} seats Booked
                          </span>
                        </div>
                        {/* Progress Bar */}
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-150">
                          <div 
                            className="bg-sky-500 h-2 rounded-full transition-all duration-500" 
                            style={{ width: `${Math.min(fRep.occupancy, 100)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center text-slate-400 py-10 text-xs font-normal">
                    No bookings logged yet to calculate capacity usages. Create user bookings to review reports.
                  </div>
                )}
              </div>
            )}

            {/* 2. FLIGHTS SCHEDULER CRUD TABLE */}
            {activeSubTab === 'flights' && (
              <div className="space-y-4">
                <span className="block text-xs font-bold text-slate-800 uppercase tracking-widest font-mono border-b border-slate-100 pb-2">
                  Scheduled Airlines Rosters
                </span>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 uppercase font-mono text-[9px] font-bold">
                        <th className="py-2.5 font-bold">Flight Code</th>
                        <th className="py-2.5 font-bold">Route</th>
                        <th className="py-2.5 font-bold">Timing Schedules</th>
                        <th className="py-2.5 font-bold">Fare</th>
                        <th className="py-2.5 font-bold">Seats Status</th>
                        <th className="py-2.5 font-bold">Condition</th>
                        <th className="py-2.5 text-right font-bold">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-101 text-slate-700 font-normal">
                      {flights.map((f) => (
                        <tr key={f.id || f._id} className="hover:bg-slate-50/50">
                          <td className="py-3 font-mono font-bold text-slate-900">{f.flightNumber}</td>
                          <td className="py-3 font-bold font-sans">{f.origin} ➔ {f.destination}</td>
                          <td className="py-3 leading-normal font-mono text-[10px]">
                            <span className="text-slate-800 block">Dep: {formatDateTime(f.departureTime)}</span>
                            <span className="text-slate-400 block font-normal">Arr: {formatDateTime(f.arrivalTime)}</span>
                          </td>
                          <td className="py-3 font-bold font-mono text-slate-850">${f.price}</td>
                          <td className="py-3 font-mono text-[10px]">
                            <span className="font-extrabold text-emerald-600">{f.availableSeats}</span>
                            <span className="text-slate-400">/ {f.totalSeats} seats</span>
                          </td>
                          <td className="py-3">
                            <span className={`text-[9px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                              f.status === 'Scheduled' ? 'bg-sky-50 text-sky-700 border-sky-150' :
                              f.status === 'Delayed' ? 'bg-amber-50 text-amber-700 border-amber-150' :
                              f.status === 'Cancelled' ? 'bg-rose-50 text-rose-700 border-rose-150' :
                              'bg-emerald-50 text-emerald-700 border-emerald-150'
                            }`}>
                              {f.status}
                            </span>
                          </td>
                          <td className="py-3 text-right">
                            <div className="flex items-center justify-end space-x-1">
                              <button 
                                onClick={() => handleEditInit(f)}
                                className="p-1 border border-slate-200 rounded-md hover:border-sky-400 hover:text-sky-600 transition-colors cursor-pointer"
                                title="Edit flight schedules"
                              >
                                <Edit3 className="h-3.5 w-3.5" />
                              </button>
                              <button 
                                onClick={() => handleDeleteFlight(f.id || f._id)}
                                className="p-1 border border-slate-200 rounded-md hover:border-rose-400 hover:text-rose-600 transition-colors cursor-pointer"
                                title="Delete flight connection"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {flights.length === 0 && (
                    <div className="text-center py-8 text-slate-400">No scheduled flights registered. Click "Schedule Flight" to launch.</div>
                  )}
                </div>
              </div>
            )}

            {/* 3. BOOKINGS DATA SHEET */}
            {activeSubTab === 'bookings' && (
              <div className="space-y-4">
                <span className="block text-xs font-bold text-slate-805 uppercase tracking-widest font-mono border-b border-slate-100 pb-2">
                  Customer Airplane Bookings
                </span>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 uppercase font-mono text-[9px] font-bold">
                        <th className="py-2.5 font-bold">Ref No.</th>
                        <th className="py-2.5 font-bold">Flight</th>
                        <th className="py-2.5 font-bold">Passenger Name</th>
                        <th className="py-2.5 font-bold">Seat Assigned</th>
                        <th className="py-2.5 font-bold">Fare paid</th>
                        <th className="py-2.5 font-bold">Action Status</th>
                        <th className="py-2.5 font-bold">Billing</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-101 text-slate-700 font-normal">
                      {bookings.map((bIdx, bNo) => {
                        const flObj = typeof bIdx.flight === 'object' ? bIdx.flight : null;
                        
                        return (
                          <tr key={bIdx.id || bIdx._id || bNo} className="hover:bg-slate-50/50">
                            <td className="py-3 font-mono font-bold text-slate-900 uppercase">
                              {bIdx.id?.substring(0, 8) || bIdx._id?.substring(0,8) || "PENDING"}
                            </td>
                            <td className="py-3 leading-normal font-mono text-[10px]">
                              <span className="text-slate-850 block font-bold">{flObj?.flightNumber || "UNASSIGNED"}</span>
                              <span className="text-slate-400 block font-normal">{flObj?.origin}➔{flObj?.destination}</span>
                            </td>
                            <td className="py-3 leading-normal">
                              <span className="text-slate-800 block font-bold uppercase text-[11px] font-sans">{bIdx.passengerName}</span>
                              <span className="text-slate-400 block text-[9px] font-mono leading-none font-normal">{bIdx.passengerPassport}</span>
                            </td>
                            <td className="py-3 font-mono font-bold text-sky-600">{bIdx.seatNumber}</td>
                            <td className="py-3 font-bold font-mono text-slate-800">${bIdx.price}</td>
                            <td className="py-3">
                              <span className={`text-[9px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                                bIdx.status === 'Cancelled' ? 'bg-rose-50 text-rose-700 border-rose-150' : 'bg-emerald-50 text-emerald-700 border-emerald-150'
                              }`}>
                                {bIdx.status}
                              </span>
                            </td>
                            <td className="py-3">
                              <span className={`text-[9px] uppercase font-bold tracking-wider font-mono py-0.5 px-2 rounded-full border ${
                                bIdx.paymentStatus === 'Paid' ? 'bg-sky-50 text-sky-700 border-sky-150' : 'bg-amber-50 text-amber-700 border-amber-150'
                              }`}>
                                {bIdx.paymentStatus}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {bookings.length === 0 && (
                    <div className="text-center py-8 text-slate-400">No active bookings registered in SkyBook reservoirs.</div>
                  )}
                </div>
              </div>
            )}

            {/* 4. PASSENGER SIGNUP USERS TAB */}
            {activeSubTab === 'users' && (
              <div className="space-y-4">
                <span className="block text-xs font-bold text-slate-800 uppercase tracking-widest font-mono border-b border-slate-100 pb-2">
                  Customer Accounts Directory
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {users.map((usr) => (
                    <div key={usr.id || usr._id} className="border border-slate-150 p-4 rounded-xl flex items-center justify-between bg-slate-55 flex-row">
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-slate-850 uppercase font-sans">{usr.name}</h4>
                        <span className="text-[10px] text-slate-400 font-mono block font-normal">{usr.email}</span>
                      </div>
                      <span className={`text-[9px] uppercase font-mono tracking-wider font-bold py-0.5 px-2 rounded border ${
                        usr.role === 'admin' ? 'bg-sky-900/55 text-sky-305 border-sky-700' : 'bg-slate-200 text-slate-700 border-slate-300'
                      }`}>
                        {usr.role}
                      </span>
                    </div>
                  ))}
                </div>
                {users.length === 0 && (
                  <div className="text-center py-8 text-slate-400">No registered users present. Refresh connections.</div>
                )}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
