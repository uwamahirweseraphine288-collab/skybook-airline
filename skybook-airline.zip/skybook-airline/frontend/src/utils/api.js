import axios from 'axios';

const API_BASE = '/api';

export const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Axios Request Interceptor automatically attaches authorization header
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('skybook_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Axios Response Interceptor clears local credentials if token expires or is rejected
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response && [401, 403].includes(error.response.status)) {
      // Clear token and user details to avoid infinite login mismatch blocks
      localStorage.removeItem('skybook_token');
      localStorage.removeItem('skybook_user');
      
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('skybook_auth_error'));
      }
    }
    return Promise.reject(error);
  }
);

// Unified Authentication Service
export const authApi = {
  register: async (name, email, password, role = 'passenger') => {
    const { data } = await api.post('/auth/register', { name, email, password, role });
    localStorage.setItem('skybook_token', data.token);
    localStorage.setItem('skybook_user', JSON.stringify(data.user));
    return data;
  },

  login: async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('skybook_token', data.token);
    localStorage.setItem('skybook_user', JSON.stringify(data.user));
    return data;
  },

  logout: () => {
    localStorage.removeItem('skybook_token');
    localStorage.removeItem('skybook_user');
  },

  getCurrentUser: () => {
    const userStr = localStorage.getItem('skybook_user');
    if (!userStr) return null;
    try {
      return JSON.parse(userStr);
    } catch {
      return null;
    }
  },

  getToken: () => {
    return localStorage.getItem('skybook_token');
  },
};

// Flights Service
export const flightsApi = {
  getAll: async (params) => {
    const { data } = await api.get('/flights', { params });
    return data;
  },

  getById: async (id) => {
    const { data } = await api.get(`/flights/${id}`);
    return data;
  },

  create: async (flightData) => {
    const { data } = await api.post('/flights', flightData);
    return data;
  },

  update: async (id, flightData) => {
    const { data } = await api.put(`/flights/${id}`, flightData);
    return data;
  },

  delete: async (id) => {
    const { data } = await api.delete(`/flights/${id}`);
    return data;
  },
};

// Bookings Service
export const bookingsApi = {
  create: async (bookingData) => {
    const { data } = await api.post('/bookings', bookingData);
    return data;
  },

  getMyBookings: async () => {
    const { data } = await api.get('/bookings');
    return data;
  },

  cancel: async (id) => {
    const { data } = await api.put(`/bookings/${id}/cancel`);
    return data;
  },

  pay: async (id, paymentDetails) => {
    const { data } = await api.post(`/bookings/${id}/pay`, paymentDetails);
    return data;
  },
};

// Admin Service
export const adminApi = {
  getDashboardStats: async () => {
    const { data } = await api.get('/admin/dashboard');
    return data;
  },
  
  getUsers: async () => {
    const { data } = await api.get('/admin/users');
    return data;
  },

  getAllBookings: async () => {
    const { data } = await api.get('/admin/bookings');
    return data;
  }
};
